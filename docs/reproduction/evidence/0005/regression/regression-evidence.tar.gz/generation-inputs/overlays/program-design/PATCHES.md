# Program Design 0.2.0 本地差异清单

基准为 PWF v3.17.0、`0d21b6c4aa5f2c5bdd3d042e7473ee09f7fae9e7`。原始归档保持逐字节不变；下列差异由 `scripts/build-plugin.py` 和本目录生成，不能在平台副本单独修改。来源清单见 `vendor/planning-with-files/inventory.json`；文件路径列使用上游原路径或相同类别的全部副本。

| ID | 上游位置 | 本地变更及原因 | 回归入口 |
| --- | --- | --- | --- |
| PD-P01 | manifest、package.json/lock、commands、平台脚本和测试中的产品/Skill身份 | 产品 `program-design`、主 Skill `project-docs`、`pd-` 命令、`pd_` OpenCode tools；保留来源链接、`PWF_*`/`PLAN_ID`/磁盘协议。覆盖反斜杠、编码的 Windows launcher、原生注册及 fallback | 原始/迁移 pytest、Pi/OpenCode；本地身份与 Windows 命令解码契约 |
| PD-P02 | 各平台/语言 `SKILL.md`、普通/自主/analytics templates | 插入 `workflow.md` 与本地证据/显式控制；保留上游主体和特定平台能力披露。语言变体只显式加载，Codex 只保留一个自动主入口；模板追加不增加 parser phase/status/checkbox token | Skill/链接检查、模板解析对照、真实维护与冷读 |
| PD-P03 | `.gemini/hooks/*.sh`、`.mastracode/hooks.json` | 给缺少关闭入口的旧适配添加 `PLANNING_DISABLED=1` 早退，分别保留 `{}` 或空输出协议。没有实现自然语言只读识别或给旧适配增加 named-plan 能力 | 9 个实际 hook 命令关闭后无注入/项目写入；原始/迁移回归 |
| PD-P04 | 各平台 `hooks/*.sh` 中的内联 Python `-c`/stdin 片段 | 增加 `-I`，避免 JSON 序列化/协议处理意外导入 cwd 中的同名模块或 `PYTHONPATH` 内容；不对依赖包内 sibling imports 的脚本入口批量加隔离参数 | cwd 同名 `json.py` 可观察副作用测试；上游解释器隔离与适配回归 |
| PD-P05 | 所有 `scripts/plan-doctor.sh` | 附加 `doctor-overlap.sh`，只检查已知原 PWF 目录并告警；目录存在不证明 hooks 正在运行，不执行旧脚本、不卸载 | 旧目录内放置可观察脚本，确认仅诊断、不执行 |
| PD-P06 | 部分平台及语言 Skill 目录、Codex/Claude catalog、Pi/OpenCode `files` | standalone Skill 补齐 canonical scripts/templates/reference/examples 与本地证据，保留已有平台副本；每个独立复制边界携带 MIT/UPSTREAM；Codex ZIP 自带本地 catalog，包不依赖子模块或个人缓存 | 14 包清单/逐文件摘要/相对链接；真实 Codex 注册、缓存核对和卸载 |
| PD-P07 | `tests/test_hermes_first_class.py::test_shell_hook_bridge_translates_inject_and_gate` | 补齐 Hermes 资产后，无效显式路径仍可找到合法包内 fallback。迁移测试先确认这个行为，再将 bridge 复制到没有脚本的隔离位置保留原 silent-noop 断言；不改变运行时 fallback 语义 | 定向 Hermes 测试与完整迁移 pytest；首轮失败保留 |

测试中的身份变化只对应实际新接口，不删除上游功能断言。PD-P07 是分发完整性改变引起的 fixture 适配，原始 baseline 仍执行未经修改的测试。本轮结果及失败处理以 `docs/reproduction/0005-pwf-based-plugin.md` 为准；这里登记设计，不预先宣称每层宿主测试通过。
