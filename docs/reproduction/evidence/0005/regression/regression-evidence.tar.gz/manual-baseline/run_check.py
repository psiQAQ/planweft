#!/usr/bin/env python3
import argparse, subprocess, pathlib, time, os, json
p=argparse.ArgumentParser(); p.add_argument('name'); p.add_argument('cwd'); p.add_argument('command',nargs=argparse.REMAINDER); a=p.parse_args()
out=pathlib.Path('/tmp/program-design-02-baseline-results'); env=os.environ.copy(); env['npm_config_cache']='/tmp/program-design-02-npm-cache'; env['UV_CACHE_DIR']='/tmp/program-design-02-uv-cache'; env['UV_PYTHON_INSTALL_DIR']='/tmp/program-design-02-python'; env['PYTHONDONTWRITEBYTECODE']='1'; env['PATH']='/tmp/program-design-02-baseline-venv/bin:'+env['PATH']; env['XDG_CACHE_HOME']='/tmp/program-design-02-baseline-cache'
started=time.time()
with (out/(a.name+'.log')).open('w') as f:
 f.write('cwd: '+a.cwd+'\ncommand: '+repr(a.command)+'\n'); f.flush()
 r=subprocess.run(a.command,cwd=a.cwd,stdout=f,stderr=subprocess.STDOUT,env=env)
result={'name':a.name,'cwd':a.cwd,'command':a.command,'exit_code':r.returncode,'duration_seconds':round(time.time()-started,3),'log':str(out/(a.name+'.log'))}
(out/(a.name+'.json')).write_text(json.dumps(result,indent=2)+'\n'); print(json.dumps(result)); print('\n'.join((out/(a.name+'.log')).read_text(errors='replace').splitlines()[-12:])); raise SystemExit(r.returncode)
