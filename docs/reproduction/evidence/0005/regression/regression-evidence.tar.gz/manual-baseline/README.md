# PWF v3.17.0 upstream baseline

The source commit was verified as `0d21b6c4aa5f2c5bdd3d042e7473ee09f7fae9e7`. The immutable clone is `/tmp/program-design-pwf-317-source`; all tests ran on `/tmp/program-design-02-baseline-source`.

`environment.json` records runtime versions and isolation. Each check has a `.json` command record and `.log` output; pytest also emits JUnit XML.

## Environment adjustments

- Initial `uv venv` used the user's read-only default cache; redirected `UV_CACHE_DIR` and Python installation to `/tmp`. Download required sandbox network escalation.
- Initial npm installs in restricted mode were cancelled when network remained unavailable. Upgraded installs used the original lockfiles. Attempts to run in separate steps initially could not resolve `vitest`; the accepted Pi and OpenCode runs install and test in one process. One offline diagnostic hit `esbuild spawnSync EPERM` under sandbox restrictions. No upstream source edits were made.
- The first pytest invocation used the venv executable but retained the system PATH and default HOME cache. It reported 20 failures. Some tests invoke bare `python`, absent from system PATH, and shell injection exits silently when `~/.cache/pwf-snapshots` cannot be created. The accepted rerun adds the venv to PATH and sets writable `XDG_CACHE_HOME` under `/tmp`.
- OpenCode npm emits an engine warning for transitive `ini@7.0.0`: Node 22.22.1 is one patch below its declared 22.22.2 floor. Its typecheck, build and tests passed on this actual runtime.
- Pi does not define an upstream typecheck/build command or tsconfig; only its upstream test command was executed.

Windows/macOS and actual interactive hosts were not run by this baseline subtask. PowerShell and platform-specific skips must remain explicit.
