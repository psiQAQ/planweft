import importlib.util,unittest,sys,json,os,traceback,shutil
from pathlib import Path
source=Path(sys.argv[1]); destination=Path(sys.argv[2]); count=int(sys.argv[3]);destination.mkdir(parents=True,exist_ok=True)
spec=importlib.util.spec_from_file_location('phase_lock_tests',source/'tests/test_phase_status_locking.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
process_output=[]
original_popen=m.subprocess.Popen
class CapturingPopen(original_popen):
 def __init__(self,args,*a,**kw):
  if len(sys.argv)>4 and sys.argv[4]=='trace' and args[0]==m.SH:args=[args[0],'-x',*args[1:]]
  super().__init__(args,*a,**kw)
 def communicate(self,*a,**kw):
  outputs=super().communicate(*a,**kw)
  process_output.append({'pid':self.pid,'args':self.args,'returncode':self.returncode,'stdout':outputs[0],'stderr':outputs[1]})
  return outputs
m.subprocess.Popen=CapturingPopen
class Recorder(unittest.TextTestResult):
 def addFailure(self,test,err):
  failure={'test':str(test),'plan':test.plan_file.read_text(),'lock_exists':test.lock_dir.exists()};t=err[2]
  while t:
   if t.tb_frame.f_code.co_name=='test_concurrent_distinct_phase_updates_are_not_lost':
    failure['process_output']=t.tb_frame.f_locals.get('results')
   t=t.tb_next
  target=destination/('failure-'+str(len(self.failures)+1));shutil.copytree(test.tmp,target);(target/'details.json').write_text(json.dumps(failure,indent=2));super().addFailure(test,err)
suite=unittest.TestSuite(m.ShellPhaseStatusLockTests('test_concurrent_distinct_phase_updates_are_not_lost') for _ in range(count))
with (destination/'repeat.log').open('w') as stream: result=unittest.TextTestRunner(stream=stream,verbosity=2,resultclass=Recorder).run(suite)
(destination/'all-process-output.json').write_text(json.dumps(process_output,indent=2))
summary={'source':str(source),'iterations':count,'failures':len(result.failures),'errors':len(result.errors),'success':result.wasSuccessful()};(destination/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary));sys.exit(not result.wasSuccessful())
