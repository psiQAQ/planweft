// No models, credentials, network or project writes. Exercise actual Cordis readiness.
import {Context} from '/var/tmp/planweft-040/dsh-cli/node_modules/@deepseek-ai/cordis/lib/index.js';
import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
const sdk='/var/tmp/planweft-040/dsh-cli/node_modules/@deepseek-ai/cordis';
const results=[];
for(const separateProviderFiber of [false,true]) {
  const ctx=new Context();ctx.provide('shell',{});
  let bridge,provider,called=false;
  const outer=ctx.plugin({name:'outer',inject:['shell'],apply(parent){
    const scoped=parent.isolate('shell');
    const mount=local=>{
      local.provide('shell',{});
      bridge=local.plugin({name:'bridge',inject:['shell'],apply(){called=true;}});
    };
    if(separateProviderFiber) provider=scoped.plugin({name:'private-provider',apply:mount});
    else mount(scoped);
  }});
  await outer;
  if(provider) await provider;
  await Promise.resolve();await Promise.resolve();
  results.push({separateProviderFiber,called,outerState:outer.state,bridgeState:bridge?.state,providerState:provider?.state??null});
  await outer.dispose();
}
assert.equal(results[0].called,false);assert.equal(results[0].bridgeState,0);
assert.equal(results[1].called,true);assert.equal(results[1].bridgeState,2);
console.log(JSON.stringify({status:'Passed',kind:'actual Cordis service-readiness causal fixture; no model',sdkVersion:JSON.parse(readFileSync(sdk+'/package.json')).version,sdkSourceSha256:createHash('sha256').update(readFileSync(sdk+'/lib/index.js')).digest('hex'),results},null,2));
