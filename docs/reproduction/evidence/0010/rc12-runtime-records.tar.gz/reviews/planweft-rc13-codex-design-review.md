# RC13 Codex doctor 结构化豁免设计独立审查

结论：按 receipt、原生配置结构和 managed registry 摘要进行精确豁免，比全局字符串删去安全且足以解决已复现误报。实施前应明确下面四项边界：严格 UTF-8 解码、完整记录缺失原生配置的拒绝、局部 key/value 扫描方式、部分失败恢复策略。本次为设计及解析器离线审查，不表示实现或真实宿主已通过。

## 解析器实际核查

工作区没有已安装的 `toml`。独立 reviewer 只读取得[锁定 npm 4.3.0 归档](https://registry.npmjs.org/toml/-/toml-4.3.0.tgz)到临时目录，核对其 SHA-512 与现有 lock 完全一致，再检查包内源码并直接调用其 parser；没有 npm install、依赖声明变更或仓库文件修改。公开源码项目为 [BinaryMuse/toml-node](https://github.com/BinaryMuse/toml-node)。

| 离线输入/源码边界 | 实际结果与影响 |
| --- | --- |
| quoted/literal table keys、inline table、dotted keys | 均解析，适合结构定位；不用逐行 section 正则 |
| 重复普通 key、重复 table、重复 inline key | 均抛错，不能捕获后 fallback 为字符串豁免 |
| `__proto__` table、`constructor` key | null-prototype 容器，无原型污染；调用方仍应用 `Object.hasOwn`，不用对象自带 `hasOwnProperty` |
| 单个开头 BOM | parser 接受；这是 parser 行为，不额外宣称固定 Codex 对 BOM 的 native 接受性 |
| Buffer 中非法字节 `0xff` | `index.js` 调用 `input.toString()`，替换为 U+FFFD 后仍解析成功；**调用方必须先 fatal UTF-8 解码** |
| 64-bit 最大整数 | 默认返回超出 safe 范围的 Number，而非 BigInt；包 README 明列这一精度限制 |

建议读取 Buffer 并用 `TextDecoder('utf-8', {fatal:true})` 解码，再传字符串到 parser。不要以是否出现 U+FFFD 代替严格解码，合法输入本身可含该字符。解析失败输出固定诊断及必要行列，避免把整段配置或可能带敏感值的 parser 原始报错打印到公开日志。

默认 parser 对大整数的近似不应影响规划身份识别：仅解码后的字符串/key及所需的严格字段类型参与豁免，绝不写回解析对象。若选择整体 fail-closed 拒绝不安全整数，需要清楚记录这是额外兼容限制；不应误称已经按 BigInt 精确解析。扫描器遇实际 BigInt、未知对象或不能安全遍历的类型应有显式策略，不能因 JSON.stringify 抛错而吞掉整个检测。

## 最小实现边界

1. 精确自有身份：仅 Codex，global/full integration，旧 receipt 的 `catalog===this.catalog('codex')`、`nativeId==='planweft@'+catalog`、marketplace-add 已完成，且 managed 路径来自当前 installer 派生值。registry/payload 实际存在、非意外链接，摘要与 receipt 一致；不能以字段存在代替完整核对。
2. 解析后 `marketplaces`、该 catalog 值和 `plugins` 应为预期 table 类型（排除 array/null/primitive）。要求自有 `source_type==='local'`；`source` 必须是绝对路径字符串，与派生 registry 经本机路径语义规范化后相等。不要把 relative path 按 reviewer/installer cwd 猜成自有，也不要通过 realpath 将任意 foreign alias 合并为自有来源。
3. 完整安装记录缺少 `config.toml`、自有 marketplace、source/type 或精确 owned plugin 条目时，明确报原生注册缺失/变更。否则旧代码跳过不存在文件后会把缺失与“没有重复”混淆。用户将 source 改为不含品牌的其他目录同样失败，不依赖最终品牌正则发现它。
4. 建议直接递归扫描解析后的 key 和 string value，并按完整路径仅跳过：自有 marketplace 的键身份、其已校验 source 值、自有 plugin 的键身份。**自有 plugin 的 value 全部继续扫描**，不删除整个 plugin/table。不要通过把 key 重命名为 `''` 等占位键构造对象，避免已有同名键被覆盖；不通过 JSON.stringify/parse 克隆而丢失类型。
5. 自有 marketplace 其余字段继续检测，其他 catalog 的键和值全部保留。另一普通名称 catalog 即使恰好复用自有 registry source 仍必须拒绝；自有 `nativeId` 出现在另一个位置也不能被全局豁免。没有旧 receipt 时不按可预测 catalog 名字自动豁免。
6. plugin `enabled=false` 由用户管理，不能在 doctor 中恢复 true。应单独如实报告禁用状态，或明确当前检查只负责重复注册；不要把结构化消除重复误报当成启用状态证明。

## 部分失败与完成态

仅完整 receipt 获得豁免是保守策略，但可能影响“marketplace-add 已完成，native-install 失败”后的继续安装。需要明确选择：

- 拒绝 add/update 自动续跑，提供现有精确 remove 撤销后重装，并保留失败记录；测试 remove 能处理这种 receipt。
- 或者按步骤分别验证自有 marketplace 与 plugin，允许已确认完成步骤的有限豁免来继续未完成步骤；doctor 仍必须因 overall status 非 installed 报失败。

不能一边要求 `native-install=done/status=installed` 才看见自有 marketplace，一边宣称所有部分安装都能 update 续跑。此处不是要求扩大功能，而是保持已批准的继续或撤销语义可用。

## 必须回归的反例

- 正常自有配置，多种合法 TOML 表达，doctor/update dry-run 字节不变、没有原生命令。
- 另一个无品牌名称 catalog 指向相同 source；同表额外字段、自有 plugin.value 或其他位置再出现规划标识。
- source 换为普通无品牌路径、git type、相对路径、缺字段/错类型、整个文件/表/插件被删除；均不能获自有豁免。
- 无 receipt、wrong catalog/nativeId、incomplete steps；摘要缺失/变动、payload 缺失或链接变动。
- 非法 UTF-8；重复 TOML 定义；合法含 U+FFFD；Windows 路径、JSON/TOML 转义、中文空格与 CRLF。
- 不安全整数/非有限数/时间类型不造成漏扫；foreign key 为 `''`、`__proto__`、`constructor` 不被占位键处理覆盖。
- marketplace 已注册但 plugin 安装失败：按所选恢复策略继续或精确撤销；不误记安装成功。

固定 Codex [ff29a443 config schema](https://github.com/openai/codex/blob/ff29a44391deccde0aba0f8390337d7f3c319ea4/codex-rs/core/config.schema.json)已确认 marketplace 的原生结构。即将取得的真实配置 projection 应另存摘要；不把新场景内容写作此前 RC12 容器原配置。后续还需用准确修改包重新验证实际无模型原生生命周期。

本次未运行容器、模型或安装命令。锁定归档的下载仅用于公开源码审查；依赖声明仍待用户批准/主 Agent 实施，不是本次已交付修改。

## 审查来源摘要

| 对象 | SHA-256 |
| --- | --- |
| `toml-4.3.0.tgz` | `e5afcf7b9fbe965c9a5985d69b7cba5e139cdacc9afbfec18885e1cc98e981b8` |
| 包内 `index.js` | `a852aecec75bb4bebabe9c0c7e72fb9c76bba5fc243779f8f55cfe941447be1a` |
| 包内 `lib/compiler.js` | `57bc506a200d23601dede27466de58382b16f0efe611e92419dcc168a6df481d` |
| 包内 `lib/parser.js` | `d17b974a0c453d8fab1ec1d7966f211b0004bd89a9456615c61bfc488db8b759` |
| 固定 Codex schema | `affe54cce9b9945ffd32d322415ff4cc844c62068c1190be6355580be4ca9350` |

实际 tarball SHA-512 与 lock 的 `sha512-lVb8X9BsPVuH0M4BKeS91tXAmJvCjQ5UIyAbQFaxkKGyUFK2RPkhwaFSQH8vbpl1d23eu/IBH+dwVMHWaq9A5A==` 完全一致。
