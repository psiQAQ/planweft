# RC12 Codex doctor 重复注册误报：独立定位

结论：**新增路径正则会误报自有 Codex marketplace 来源，已用官方结构的合成配置复现。** RC12 真实 preflight/lifecycle 的日志与此机制吻合，但所属容器 HOME 已清理，未保留实际 `config.toml`，因此尚不能断言真实配置中究竟哪一段字节触发匹配。原始两项 Failed 应保留，不能直接重新标记 Passed。

## 已确认事实

- 两场 Codex 0.149.1 的 `installer-add` 均返回 0：原生输出明确注册 CLI 自有 marketplace 的持久目录，并安装 PlanWeft 0.4.0-rc.12。
- 原生插件 294 文件检查 Passed。随后的 doctor 在配置重复检测处失败，stderr 为空，controller 为 `installer-doctor failed`；没有进入模型，也未取得本轮完整 lifecycle 证据。
- RC12 准确包声明 SHA 为 `7830a636cf5c36bca51883704abf8feeaf5c5a15f9583b9f8966db48da289dc3`。
- `lib/installer.mjs` 的 Codex native 分支记录 `catalog`、`nativeId`、registry/payload 摘要，实际传给 marketplace add 的目录为 `path.join(this.base, 'registries', 'codex')`；没有设置用于字符串豁免的 `nativeSource`。
- `detectDuplicates` 删去自有 catalog/nativeId 后，保留 marketplace 的来源目录。提交 `6267299` 新增的 `[/\\]planweft(?:[/\\"']|$)` 因此会匹配持久来源中间的 `/planweft/`。

先前 `/tmp/planweft-codex149-source` 主要存 hooks、app-server protocol，不包含 marketplace config 结构。本次额外核对固定版本 `rust-v0.149.1` 对应提交 `ff29a44391deccde0aba0f8390337d7f3c319ea4` 的[官方 config schema](https://github.com/openai/codex/blob/ff29a44391deccde0aba0f8390337d7f3c319ea4/codex-rs/core/config.schema.json)。其 `marketplaces` 按名称映射，`MarketplaceConfig` 包含 `source` 和 `source_type`（`local`/`git`），并允许更新时间、revision/ref 等字段。这证明以下合成输入符合原生字段结构，不证明已看到失败容器的配置序列化字节。

## 最小合成复现

在独立临时目录写入以下配置，直接调用当前 `Installer.prototype.detectDuplicates`，提供匹配的旧 `catalog`/`nativeId`；没有原生 CLI、模型或 Docker。临时文件已清理。

```toml
[marketplaces.planweft-cli-codex-fixture]
source_type = "local"
source = "/home/agent/.local/share/planweft/registries/codex"

[plugins."planweft@planweft-cli-codex-fixture"]
enabled = true
```

实际返回 `Another planning registration may be active in <fixture>/config.toml`。这是代码级误报复现；路径使用容器约定，不能当作提取出的真实配置附件。

## 最小安全修复建议

只对 Codex 的**精确自有结构字段**构造检测视图：

1. 先识别 TOML 中唯一的 `marketplaces[old.catalog]`，限定本次 receipt 的自有身份；没有旧 receipt、旧 marketplace 步骤未完成或身份不符时不豁免。安装记录与 managed registry 的摘要/路径应通过现有所有权规则核对，不能让自报 catalog 成为任意豁免权。
2. 仅当该表 `source_type` 确为 `local` 且其解码 `source` 精确对应派生的自有 registry 目录时，在内存检测视图中去除**这一处 source 值**。保留同表其他值，继续检测其他 catalog、插件条目和 hook 配置。来源被用户改为另一路径，即使新路径不含品牌，也应报自有注册不一致，而非仅依赖末端品牌正则。
3. TOML 需要正确处理 quoted/literal key、inline table、dotted key、注释、转义及重复定义；不要用“处于某个 section 直到下一行 header”的宽泛字符串删除绕过解析歧义。无法识别的形式应明确失败，不能默默放行。可复用可靠解析器；目前 `toml` 仅是传递依赖，若选择它须把运行依赖契约显式化，而非假定总会被提升到根。
4. 不全局删除 registry 路径、不删除整个 marketplace 表，也不要仅因来源目录存在就视为自有。`marketplaces.backup.source` 指向同一目录仍是另一注册；全局删字符串会使这种外来条目消失。
5. 实际配置未归档的缺口应在下一次无模型隔离场景补齐：导出仅 marketplace/plugin 相关字段、原生 list 及其来源摘要，避免保存模型供应商配置或凭据。保留此轮原始失败，不把下一次配置当成上一轮原件。

## 必须保留的反例

- 只有精确自有 local marketplace 及插件：doctor、update dry-run 应通过，配置字节不变。
- 同一目录再次出现在另一个普通名称 catalog（不含 `planweft`）：必须拒绝；不能靠 catalog 品牌侥幸检出。
- 其他来源的 PlanWeft catalog/plugin、原版 PWF hooks：仍拒绝。
- 自有 catalog 的 source/type 改变、缺失 source、无 receipt 或 incomplete registration：不豁免。
- 同表额外值含第二项规划来源：不得通过删除整个表隐藏。
- 单引号、双引号转义、Windows 分隔符、中文空格、CRLF、inline/dotted 表达、重复 TOML key：正确解析或明确拒绝；不声称 Linux 合成测试替代 Windows 原生测试。
- doctor/update dry-run 不改配置、receipt、项目三文件，不调用原生命令。

## 证据摘要

| 对象 | SHA-256 |
| --- | --- |
| `lib/installer.mjs` | `fbfb7cd0292250a2fd753a1acfc7458fff30b0d70d8e45a4548b58b971d8d375` |
| 固定官方 `config.schema.json`（本地 `/tmp/planweft-codex149-config-schema.json`） | `affe54cce9b9945ffd32d322415ff4cc844c62068c1190be6355580be4ca9350` |
| preflight 与 lifecycle `installer-doctor.stdout`（相同） | `ca9b1a7a417bec1ecf089aa77c59044c40b3a672a631d4fe2f2b54b8db1cfcdd` |
| preflight `installer-add.stdout` | `74da38994fc072c69cfdb121318649a60d4c1df32d649676163bc71e21c426bd` |
| lifecycle `installer-add.stdout` | `8c3bf1a4540a831f8749264c577028f3c14b008651cb22089dd289ae1e7867c1` |
| preflight `controller.json` | `a456baa52dabc70085a6b41987dfcffa051133f5bb6fd40886f7c82d46456ac1` |
| lifecycle `controller.json` | `e9a5d3cd6e10073a8c66470f0569384becd13b8192a39387b050fc055d9ff4a1` |
| 两场 `installed-content.json`（相同） | `e28912512c84bf3f4918881597bc966b354922d7a664fe4a3146bcf3bf9d3d25` |

本次未修改仓库源码、原始证据或正在执行的场景，未运行容器/模型。仅诊断、公开固定源码读取及无网络合成函数调用。真实原始 config 内容仍为未取得证据，不将这一限制隐藏在“已确证”结论中。
