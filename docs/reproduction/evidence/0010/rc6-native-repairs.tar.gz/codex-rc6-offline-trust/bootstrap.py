import os,subprocess,tarfile,sys,json
from pathlib import Path
sys.path.insert(0,"/runner")
from codex_trust_probe import trust_hooks
os.environ.update(HOME="/home/agent",CODEX_HOME="/home/agent/.codex",OPENAI_API_KEY="synthetic-no-network-key")
with tarfile.open("/input/package.tgz") as t:t.extractall("/tmp/pkg")
for name,cmd in [("marketplace",["codex","plugin","marketplace","add","/tmp/pkg/package"]),("plugin",["codex","plugin","add","planweft@planweft"])]:
 r=subprocess.run(cmd,input="y\ny\n",capture_output=True,text=True,timeout=60)
 Path("/results/"+name+".stdout").write_text(r.stdout)
 Path("/results/"+name+".stderr").write_text(r.stderr)
 assert r.returncode==0,name
result=trust_hooks("gpt-5.6-terra",Path("/workspace"),Path("/results/ui.log"),30,sanitize=lambda x:x)
Path("/results/summary.json").write_text(json.dumps(result,indent=2))
