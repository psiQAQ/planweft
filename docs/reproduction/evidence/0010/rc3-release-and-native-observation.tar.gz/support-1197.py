import hashlib,importlib.util,json,os,pathlib,subprocess,sys
sys.path.insert(0,'/runner')
from gate_process_trace import attributed_gate_reads,TRACE_SYSCALLS
plan='# Task Plan\n\n### Phase 1: External approval\n- **Status:** in_progress\n'
files={'task_plan.md':plan,'.mode':'autonomous gate\n','.plan-attestation':hashlib.sha256(plan.encode()).hexdigest()+'\n','.stop_blocks':'1\n','.gate_last_ledger':'0\n','ledger-owner.jsonl':'{"observation":"advanced"}\n'}
for name,value in files.items(): pathlib.Path(name).write_text(value)
os.environ.update(HOME='/tmp',XDG_CACHE_HOME='/tmp/cache',PWF_GATE_CAP='1')
command=['strace','-f','--decode-pids=comm','-s','4096','-e','trace='+TRACE_SYSCALLS,'-e','raw=read','-o','/tmp/private.trace','bash','/plugin/scripts/check-complete.sh','--gate']
p=subprocess.run(command,input='{"stop_hook_active":false}',text=True,capture_output=True)
raw=pathlib.Path('/tmp/private.trace').read_text()
result=attributed_gate_reads(raw,hashlib.sha256(pathlib.Path('/plugin/scripts/check-complete.sh').read_bytes()).hexdigest())
pathlib.Path('/results/synthetic-gate.trace').write_text(raw)
print(json.dumps({'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'trace':result},indent=2))
