# Claude 无模型原生 trace 的有界解析细化审查

结论：所审源码未发现阻塞错误。同一无认证、无网络 startup trace 的旧 Incomplete 与新 Complete 已由 reviewer 独立离线重算重现。Complete 仅指所声明边界内的进程／stdout 字节归因，不代表模型收到提醒、两回合去重或正式版 gate Passed。原始 trace/controller 与旧报告未修改。

## 三项证明边界

**close/socketpair 重分配**：仅已占用且旧 binding 在初始及未缩短区间的保守二遍重放中均已知的 FD，成功 close 与另一共享表线程唯一 socketpair 写入严格嵌套，才缩短 close 写 footprint。表身份和 FD 交集限制有效；任何相交第三 read/write/snapshot 或无可靠 footprint 的初遍错误都阻止证明。旧 binding 不从缩短后的第三遍反向证明，避免循环自证。Linux 的槽位释放早于 filp_close 返回，使该观察可解释为“同FD已被新socketpair合法分配”；不证明 close 在 socketpair syscall entry 前已经释放。没有第三观察者时缩短是观测等价的解析措施，不能推广到一般并发。依据：[Linux v7.0 fs/file.c](https://raw.githubusercontent.com/torvalds/linux/v7.0/fs/file.c) 的 file_close_fd_locked/close_fd。

**inotify 未完成 read**：只接受已观测 native host 创建并仍精确绑定的 inotify FD，正请求长度、精确未知返回标记，并保留整个 read 区间 footprint。该资源曾映射 stdout、后续缺少相应 pid/generation exit、复用/共享表竞态或 hook 自己的未知 read 仍拒绝。辅助记录不伪造 read 字节或 EOF，不计入 hook stdout。

**NETLINK_ROUTE recvmsg**：局限 native host、非 hook、精确 AF_NETLINK/NETLINK_ROUTE、flags=0 与已知无竞态绑定。协议特定的辅助读取不作为 hook 消费；其他 UNIX/未知 ancillary 仍拒绝。独立读取固定 [netlink_recvmsg 源码](https://raw.githubusercontent.com/torvalds/linux/v7.0/net/netlink/af_netlink.c) 确认 scm_cookie 清零仅设置 credentials，调用 scm_recv；[scm.c](https://raw.githubusercontent.com/torvalds/linux/v7.0/net/core/scm.c) 的通用分支只有非空 fp 才安装 rights，pidfd 安装位于 unix 特定分支。本审查没有把“任何 NETLINK 版本/任何宿主”扩大为通用免检查。

## 离线验证

- 现有 test_claude_hook_trace.py：36 tests Passed（0.125s）。包括 occupied/empty/unknown、第三 read、close、dup、allocation、close_range、clone snapshot、unshare/import、保守旧binding竞态、严格嵌套、inotify复用/CLOEXEC/退出/stdout别名及 netlink域/协议/flags/竞态负例。
- reviewer 额外5个对抗轨迹全部拒绝产生 close 证明：第三成功 write、失败 write、exec snapshot、fcntl duplicate、socketpair早于close开始。未修改测试或实现。
- 对原无认证 trace，baseline ddb1af4 源摘要9afb30b4…与新d730a178…分别重算。旧完整性false，新true；同trace SHA，原6项错误与摘要报告完全一致。新唯一 FD14证明区间 close2159..2163、allocation2160..2162；startup hook 1038写/1038读+EOF，user-prompt hook1042写/1042读+EOF。inotify与netlink是辅助范围，不从它们生成 hook evidence。

## 限制

任意未观察 filesystem symlink→FD别名仍依赖固定隔离布局的 caller前提，本修改没有证明它。真实二轮Claude模型提醒投递及去重仍待独立绑定；无模型startup不能替代。调用者提供的解释器路径列表不是独立二进制认证，固定只读镜像与已保留二进制/脚本摘要仍承担其依据。没有执行Docker、模型或认证操作；仅读取公开固定内核源码与明确的无认证本地样本。

## 摘要
- `tests/claude_hook_trace.py`: `d730a1781a51dfccd9ac3088f1e940a8252783d129cc13d5658cea20aff16b50`
- `tests/test_claude_hook_trace.py`: `ec80f02ea5ef340cb8e56c4b71b0fa83049e6b34e37941851c785393f6856b48`
- `tests/gate_process_trace.py`: `bfdfb93206538ea41dbb8137feccc28b0611ca3ed5aa0e1fd5f4d788cb392954`
- `/tmp/planweft-rc13-claude-offline-v2-parser-reassessment.json`: `4e9baa4bdd905f7eab3837a904c518415aa209427df01c5604a614e270a0fa17`
- `/var/tmp/planweft-040/rc13-claude-offline-trace-v2/no-auth-private.trace`: `b3bef43a7cfa1aea45579b500a40814bd7455b229e8b97c42fd4f6220d413acb`
- `/var/tmp/planweft-040/remote-planweft-0.4.0-rc.13.tgz`: `793e3f2c4d5f7e6e8f180494e1f05ea07db2ddd30426edf6c837b6b775e09bda`
