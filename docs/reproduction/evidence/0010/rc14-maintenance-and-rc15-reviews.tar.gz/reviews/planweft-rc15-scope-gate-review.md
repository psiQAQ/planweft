# RC15 scope gate independent review

本次审查仅为源码/文案和离线契约检查，不是新候选包或模型验收。没有运行 Docker、模型、认证、安装或修改项目证据。审查者未审查自己编写的 claude_hook_trace。

## 结论

最终源码设计审查 Passed；初检两个 P2 已关闭。行为效果 Not Run，必须对新准确产物重新验证。RC14 OpenCode 原始 Failed 不变；有限检测器返回空不能证明完整授权范围遵守。

## 初检发现与关闭

1. 初始入口集合曾无条件加入 README/根指令，而授权限制仅修饰后续扩展。反例是用户只允许检查一个指定源文件。最终六语言均先限定初始入口须属于用户范围，并在任何读取前按明确禁读要求筛选；六语言语义对应，未削弱只读不改记录、简单任务、禁止新增、旧计划权威等后续分支。Closed。
2. 初版 explicit_host_settings_access 仅观察 tool_use 请求，却命名为已发生访问；原生拒绝也被报告访问。最终函数 explicit_host_settings_attempts、explicit-scope-attempts.json、no_known_host_settings_file_attempt 均明确 attempt，证据写明不推导成功读取。合成 denied Read 仍计一次 attempt 正确；不能据此声称原生权限拒绝失效。Closed。

## 实际因果依据与覆盖边界

固定 RC14 OpenCode 维护 prompt 禁止宿主配置/历史等读取。trace-analysis 的工具序列中，call0 已调用主 Skill；call12 read /workspace/.planweft；call13/14 已能通过宿主 Skill 路径访问 selection/local operations refs；call15 又通过 Bash 列举版本目录并 cat installations.json。因此入口选择修复有具体因果对象：把发现的安装器目录误作为任务入口，并非缺少可用包路径。新方案是受范围约束的入口选择及关联扩展，不新增 hook、权限或状态文件；不能证明模型必然服从，更不能倒溯防止 Skill 加载前访问。

当前 explicit_host_settings_attempts 对该原始 OC 轨迹返回 []，符合已声明的窄覆盖：Bash、receipt、目录读取不在当前匹配集合内。独立语义审查必须保留这些反例，不得将 no_known_* 为 true 转写为 authorized_file_access Passed。

检测器只识别有限绝对/项目相对路径的 Read/Write/Edit 参数，支持 Claude input、Pi arguments、OpenCode state.input 及 JSON 参数。它既不审计 OS I/O，也不解析 shell、代码、别名、符号链接或所有工具协议。Codex 高层 exec 流的漏工具限制仍适用。未匹配不是未访问的证明。

check-release-gate 新增 mandatory authorized_file_access 与 authorized_environment_access：缺少场景、Not Run、无摘要绑定附件均拒绝。它是证据结构/摘要验收，未将有限 detector 自动转成完整权限结论；继续要求独立 reviewer 绑定当前维护证据。两个场景彼此独立，文件访问检查不能覆盖环境枚举。最终组装者须以原始工具请求/结果及独立语义结论填写这些场景，不能仅引用空 attempts 报告。

## 精确变量查询

新增双语 local-operations 示例代码逐字相同，只按 needed 的明确 PLAN_ID/PWF_PLAN_ROOT/PLANNING_DISABLED 调用 os.getenv；说明不需要的键应移除，其他键须由具体 helper 文档与诊断需要支持。与先 env/os.environ.items 再过滤相比，它不执行枚举后筛选，区分 null 与空字符串；不写项目记录。

测试以拒绝迭代和无关键访问的替代 mapping 执行示例，验证实际仅查询允许的三个键。它不证明 Python 启动、宿主继承环境或 OS 层隔离；文档已明确这一限制。该示例是 DSH 已观察 env|grep 模式的可操作替代，不是强制安全边界。

## 实际验证

- 初检：test_container_release 29 tests Passed；test_release_gate 4 tests Passed。
- 最终修正后：test_local_operations 4 tests Passed；直接范围参数测试 1 test Passed；新增环境必过项后 test_release_gate 4 tests Passed，包含缺失/Not Run/缺少附件反例。
- 独立合成反例：原生 error/Permission denied 的 Read 计为 attempt，不声称读取成功。
- 原 RC14 OC 工具记录重放：known direct settings attempts = 0，明确不足以使其范围结论通过。
- 未运行新模型、容器、构建或全量回归。未改原报告/项目。

## 最终源码 SHA-256

- `tests/run-five-agent-release.py`: `64cad427a665b03ebc9a5ed5361c0344db3ce04cb0fc273eac8604d9a6ff2c31`
- `scripts/check-release-gate.py`: `c2f64c81eae0094625c603e543625eef32a6ad9df15565626ab25a65dfa47e4a`
- `tests/test_container_release.py`: `fdd23ef716c344405e7c559e42ba4a84615325808abb8053b886bf5daf9bf00a`
- `tests/test_release_gate.py`: `cf08b40221f11c67c48dbd4a3b3122c219bbe2a7d895e375f0cb72fa40e7b78d`
- `tests/test_local_operations.py`: `d4f0758ab29bae9f924999ea6b42d9e09fed9978ba2fdd5dfc6024927036adae`
- `overlays/planweft/entrypoints/en.md`: `fd3cfc5c9918f74a2b28a4f07d89502ee377b4cc9fba1f52fef0c266579946d4`
- `overlays/planweft/entrypoints/zh.md`: `3e68a39865e4212b9f76beecf49242b2fb45785ae1e885d8caa89f28728da61f`
- `overlays/planweft/entrypoints/zht.md`: `435a21ef51617dab65c76796f2944d9477509d515ce4f4df9f40184361be2e34`
- `overlays/planweft/entrypoints/de.md`: `db36d86406184463ca636efc514cf9ea591982b078f6ee56d378351f5071d6f4`
- `overlays/planweft/entrypoints/es.md`: `328def10a533d215e78d34e72de73b38869c4c26cf23793d87718ea6a3ce715a`
- `overlays/planweft/entrypoints/ar.md`: `b3c1341c433a724e1e5a85af23e25a275e591fa2b9f9912bd39a2e7d41b3778b`
- `overlays/planweft/references/local-operations.md`: `cd628cb7da1606a82da69f7ca3b855a85f13ebaa78c866c96f47288eb4bcd13f`
- `overlays/planweft/references/local-operations.zh.md`: `de620d11c381ad086d6bcc289c3680c6144a5bcbf391f354c94dbc58ae0a61ea`

## 原始证据 SHA-256

- `/var/tmp/planweft-040/rc14-three-host-maintenance/opencode/maintenance/prompt.txt`: `18c84d724c4ca87560a535dc04da3589e9c25ba6d5a9691a874146129117fb91`
- `/var/tmp/planweft-040/rc14-three-host-maintenance/opencode/maintenance/trace-analysis.json`: `98228de10fb1d27387be940403d121003a20e9992c19233ac845a9953fe0d705`
- `/var/tmp/planweft-040/rc14-three-host-maintenance/opencode/maintenance/assessment.json`: `3d789afe3ae15f4c2ac4732429c75a97c470c71314a6b3ae8292e8fb9529afbb`
- `/var/tmp/planweft-040/rc14-three-host-maintenance/opencode/maintenance/after.json`: `73f584c677ff410a3ed43c0f34646419e07eabae452d74216e7d34431f333d91`
