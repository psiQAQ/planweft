# RC15 候选：探索前入口选择的独立设计审查

结论：在所审六语言源稿中未发现阻塞设计问题。此次修改把“读取所有看起来相关的目录”改为有顺序、可观察的入口选择；它不是权限沙箱，效果尚未通过真实固定任务/model 验证。

## 依据与变更性质

RC14 Claude/Pi 均已成功获得准确 Skill 根并读取完整正文，然后仍读取 host settings；Pi 还读取 installer receipt。两者在这些读取之后才正式陈述 scope。因而“不可发现 Skill”“缺少包根”不是本次已见现象的充分解释。新首操作要求在已有回复给出任务路径及根指令/README的初始候选，读候选后经项目链接或实现/测试关系扩展；文件夹只是存在不再构成任务资料身份。包内脚本/引用保持在另一条已提供 Skill 根路径上。

该顺序是可证伪的局部假设：观察初始候选是否先于广泛探索、实际读取是否能对应任务/项目来源即可判断是否遵循。它没有新增日志文件、批准步骤、后台服务或自动写项目 hook，也没有改变三个记录的权限来源。先前记录抄写和错误遗漏仍未修复，不能由这项改动一并声称解决。

## 六语言一致性

英文、简中、繁中、德语、西语、阿拉伯语均包含：探索前列少量初始入口；任务路径与存在的根指令/README；先读入口再按相关链接或实现/测试关系扩展；浅层 root 枚举仅作定位；host配置/installer目录需实际授权来源；包资源使用独立的宿主 Skill 根。原有 adoption 三分支与后续三步保持。源码 UTF-8 读取及四个步骤标题结构检查通过。此为语义审查与结构检查，不是母语用户试用或模型遵循实验。

唯一非阻塞措辞建议：zh/zht 的“明确授权维护该目录”可写“明确授权检查或修改该目录”，更直接覆盖明确的只读配置诊断；英文 work 等词本来较宽。不应要求用户先授权修改才能读取其已请求诊断的配置。

## 正常探索边界

- 已知源文件任务：可先列该路径与根说明，随后按导入、调用、测试关系扩展；不是冻结白名单。
- 陌生项目：允许浅 root 枚举确定入口，候选可标待确认；不需要在列表前假装已知 README 存在。
- 无 README/AGENTS：并不要求创建它们。根显示的 src/tests、项目 manifest 或已有目标实现可成为相关关系的依据；建议离线例子明确覆盖此空入口情况，防止模型机械停工。
- Monorepo：根说明链接的子项目说明及任务相关实现可加入，仍遵守子项目适用指令。
- 用户明确请求排查宿主配置：该请求就是纳入配置的来源，保持只读／修改的实际范围；并非按目录名一概禁止。
- 项目说明与用户禁止发生冲突：前者的链接不扩大后者授权，已禁止配置不能因位于项目根而纳入。

## 验证限制

只读取指定源码与之前已完成语义审查；未启动模型/容器、未修改实现、未生成 RC15。建议以最小离线决策例覆盖上述边界，再冻结新准确包、固定原任务与模型运行一次有变化复验。不能把未观察到 Read 工具当成没有 bash/间接读取，也不能拿已看到的初始化成功代替 scope 成功。

## 摘要绑定
- `overlays/planweft/entrypoints/ar.md`: `85ee44050faf0467bf4c73b40682c79d0e8baa9b60f8053adec9fe5f61906c05`
- `overlays/planweft/entrypoints/de.md`: `56e73a4992d8fad9ad5c687ffd52b8cf6c9a5774bfe2e6cc0231a308de6d9d4a`
- `overlays/planweft/entrypoints/en.md`: `a3712725e863a3a311d1f584ca7a05dc21cc36a9887a35c901edbdb1cec5f42f`
- `overlays/planweft/entrypoints/es.md`: `2135744e703ba4b27a32ee861fbee5fa6e3afccc5e4005b5499234d39abe28e4`
- `overlays/planweft/entrypoints/zh.md`: `e945576cae2752fa2802d503504ff10b18041ec0e8721570c5f89bdff35bd871`
- `overlays/planweft/entrypoints/zht.md`: `9b04ab1f7bfff8909eda555fc335d76f94548bc4a8ebca67d0924a9e0d78e029`
- `docs/innovations.md`: `ce08d8881f8ffa50195ced10fda4eb79b3e0a96d15df4d2e565d4d5216edfa92`
- `/tmp/planweft-rc14-claude-independent-review.json`: `539c49efc75e54efe93af0f350def3e23e2e8bd88c3ea0db892a44db2f7a8022`
- `/tmp/planweft-rc14-pi-independent-review.json`: `a2a4b15cc07c3753eef96590d835fee3c02579b711004794a58118a9b157247a`

## 复核补充：只读措辞与两个具体离线语义用例

zh/zht 已将“明确授权维护”改为“明确授权检查或修改”，上述非阻塞措辞建议已关闭。以下是源码规则的人工语义走查，不是执行模型或新增自动测试的结果。

1. 根无 README/AGENTS，仅 package.json、src/、tests/；用户要求修复导出函数。合法路径：先在已有回复说明初始候选为任务中的导出实现，根说明是否存在待定位；一次浅 root 枚举发现 manifest/src/tests 后，根据项目 manifest/导出实现及对应测试关系选择文件。无需新建说明或规划才能发现入口，也不因无 README 停工；根含宿主目录不自动加入集合。现有文本的“存在时”“浅层列举”“实现/测试关系”允许此路线。
2. 用户明确要求只读诊断指定 host 配置且不写记录。合法路径：将用户命名配置作为任务初始入口并引用该请求，按只读分支检查并回答，不初始化 task_plan 或修改配置。读取配置的授权来源已明确，不需要另行请求写权限；此任务也不授权 installer receipt 或其余宿主文件。修订后的六语言规则均允许该路线。

发布门槛中 model_maintenance / authorized_file_access 的新增要求属主 Agent 另项修改，本报告未审其代码，仅认可“不把已知直接 Read 反例检测当作完整 shell/间接访问证明”的证据边界。

更新源摘要：
- `overlays/planweft/entrypoints/zh.md`: `e945576cae2752fa2802d503504ff10b18041ec0e8721570c5f89bdff35bd871`
- `overlays/planweft/entrypoints/zht.md`: `9b04ab1f7bfff8909eda555fc335d76f94548bc4a8ebca67d0924a9e0d78e029`
