findings.md approved
