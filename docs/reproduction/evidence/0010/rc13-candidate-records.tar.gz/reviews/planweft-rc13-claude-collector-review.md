# RC13 Claude reminder collection 独立审查

结论：在“仅采集诊断，不计发布去重门槛”的限定范围内，未发现阻塞错误。8 项离线测试 Passed，真实 Claude collection 与提醒去重均未由本次审查执行。未运行容器、模型、网络或读取认证；未修改源码。

## 事件与串行边界

- 仅启动一个 start_new_session=True 的 Claude 子进程，以 stream-json stdin 连续发送 A/B。B 的发送由 A 原生 result success 驱动，且已核对两个独立 Write 的 call/result id、路径、内容以及实际文件字节；先处理当前读取批次内全部事件再发送 B。
- Protocol 同时阻止 B 预排队、重复/并发/额外工具、错误目标、失败结果、缺少原生 Write metadata、改变 session、重复初始化、第二回合 SessionStart 以及 compaction/reset 类事件。每轮还要求两个成功 Write 之后存在实际 assistant response。
- 回放的用户消息仅在 isReplay、UUID 和正文匹配 sent journal 时计作输入 echo。未识别的 Skill/system 合成 user 内容仅保留原始流，不冒充用户回合或工具成功。
- 这仍是采集器：只保留 hook_started/hook_response 元数据，不将其与每次 Write 强行配对，不以 debug 字符串数量、模型复述或后台 marker 读取推断上下文送达。SessionStart 初始活动前的所有细粒度排序也没有成为去重证明；原始流留给后续依据固定宿主协议分析。

## 状态隔离

- 完整采集成功时 collection_status=Passed、status=Not Run、reminder_deduplication=Not Run、diagnostic_only=true。CompletedProcess rc0 仅代表采集完整，调用方不得仅凭 rc0 提升 reminder_deduplication 门槛。
- 原生观测字段缺失或 debug 为空采用 ObservationGap -> collection_status=Not Run；工具失败、非法并发、截断、超限、超时、项目记录变化和清理失败均不能返回采集成功。
- 因而本代码可以接入单独 reminder-collection 诊断；不能并入 reminder-dedup 发布验收作为 Passed。主 runtime/runner 尚在集成，未纳入这份两文件审查的源码绑定。

## 资源与隐私边界

- 参数、目标不存在、完成态计划、安装资源字节及单一 Write|Edit dispatcher 在启动进程/创建本探针输出前检查。原生日志路径不得位于项目或证据目录，mkdtemp 创建 0700 私有子目录；debug 原文仅存在其中。
- stdout/stderr 按通道字节、单行与聚合预算检查。输出先按完整行脱敏再写入证据；中断的尾部不导出。脱敏异常会输出固定省略信息并使采集失败；膨胀的脱敏输出与报告另有预算。
- debug 在进程结束后增量读取、脱敏导出，拒绝不安全的截断行；finally 删除唯一私有 debug 文件及其所属目录，删除失败明确 Failed。报告记录导出附件摘要，不把私有字节偏移误当脱敏后偏移或 hook 投递关系。
- stop_owned 针对新建进程组的记录 PID，关闭 stdin，等待后 TERM/KILL，关闭所有 pipe；没有按名称终止进程。测试确认其他进程组存活。
- 原生 debug 文件上限属于轮询检测后终止，不能宣称瞬时写入绝不会短暂越过阈值；实际运行仍须依赖调用方既有容器内存、磁盘/tmpfs和总场景时限。该模块继承调用方环境，只添加 verbose debug 级别，故认证/模型路线隔离由已授权调用方负责，模块没有扫描或提取认证。

## 验证与保留限制

执行：PYTHONPATH=tests python3 -m unittest tests/test_claude_reminder_probe.py -v

结果：8 tests Passed（约 6.5 秒，包含多组 subtests）。覆盖完整同进程串行、失败/截断/额外工具/会话重置、输出及总量限制、脱敏失败/膨胀、超时、私有清理、参数先验以及 TERM 无效后 KILL。假进程测试中的 Write metadata、输入 replay、session/result schema 不能替代固定真实 Claude 的行为；若真实字段不同，应保留 Not Run 和原始脱敏流进行分析。

明确限制：该采集器没有证明 hook 空输出、PostToolUse handler 与 Write 一对一或实际模型上下文投递；没有测试 OS 权限拒绝；prompt 对额外工具的禁止由采集器在观测到后判错，实际工具执行权限仍由调用方宿主策略决定，不能将检测等同于预先阻断。四个新建目标文件保留作诊断证据，三个既有计划记录必须原字节不变。

## 源码 SHA-256

- `tests/claude_reminder_probe.py`: `3ce3c12b9b2d66aa36691e478828e11c6e280e4f00882c6f5b022c865d2f2884`
- `tests/test_claude_reminder_probe.py`: `42458ca38ad1e1c80c6cf3cbf28a464df95e1e22c14cbf49424683bed824ebfb`

## 集成层补充审查

补查范围：run-five-agent-release.py、five_agent_runtime.py、test_container_release.py 的本次未提交 diff。独立运行 python3 -m unittest discover -s tests -p 'test_container_release.py' -v，22 tests Passed（约 1.3 秒）。没有真实模型或容器运行。

- 参数验证在归档读取和资源操作之前拒绝非 Claude reminder-collection；与仅 Codex reminder-dedup 分开。
- collector 文件复制到证据组后计算 SHA，并把该冻结文件只读挂载到 /runner；runtime 从 /runner 导入同一模块。证据 source digest 没有仅指向会继续变化的工作区文件。
- 预置 fixture 三文件均为完成态；既有 reminder-a/b 保持不变，唯一允许新文件为四个 A/B Write 目标。最终快照严格对象相等还检查其他文件不变。
- runtime 保留 collector 的脱敏 native stdout/stderr，复制到通用 model.stdout/stderr 供统一解析；原始探针日志仍保留、已有摘要不被覆盖。probe rc0 可使 controller 的 model_session Passed，但 case 必定经 reminder_collection_assessment 改为 Not Run，同时 reminder_deduplication 固定 Not Run。总 summary 仅允许所有 case Passed 才 Passed，因此成功 collection 仍使总 summary Incomplete；没有发现由诊断误放行去重门槛的路径。

P2 / 待关闭：model-invocation.json 的 argv 仍在调用探针前由普通 model_command 生成，遗漏实际探针所需 --input-format stream-json、--replay-user-messages 和私有 --debug-file。同一场 model.json 已使用 process.args 保存实际命令，因此两份 invocation 元数据互相不一致。建议在专用分支用 process.args 更新通用 model-invocation.json 并标明 diagnostic_only，或明确区分 planned/actual；不要把普通命令留作实际执行声明。已通知主 Agent，本报告保留首次发现。

非阻塞资源说明：通用 model.stdout/stderr 是探针日志副本，额外占用至多 24 MiB；探针的 48 MiB 聚合预算仅约束自身前缀文件，不是整个 raw 目录总量。本次改动仍有明确总上界和外层容器限制；不要对整个证据目录宣称严格 48 MiB。

集成源码绑定（首次审查）：

- `tests/run-five-agent-release.py`: `185f2a55722109d16a135a4ce6ea91a0dd0f2cf53e8ff0c2efbecb51cb6a069f`
- `tests/five_agent_runtime.py`: `6ddf7e25d49319cd0150208e4007df9f1af5c823320e5a07c100f6cfc9b53af6`
- `tests/test_container_release.py`: `331680c17d5b32e952861c1527c6106fd62f2324f213e7c862e07f7a69162c94`

### 集成发现关闭复核

P2 invocation 元数据问题已关闭。当前专用分支在 run_probe 返回后将 model-invocation.json 覆盖为 process.args，并明确 transport 为 native stream-json / same process two serial turns、diagnostic_only=true；model.json 同样使用 process.args。正常采集和探针返回的失败结果均使用实际命令，不再混淆普通预生成命令。首次发现及原摘要继续保留。此修复不改变 collection 与 gate 状态隔离；最终有界实现没有遗留阻塞发现。修复后主 Agent 报告 22 项离线测试 Passed；独立 reviewer 核对最终改动为该元数据写入，先前亲自运行的 22 项结果另见上节，未再重复无关测试。

最终五文件绑定：

- `tests/claude_reminder_probe.py`: `3ce3c12b9b2d66aa36691e478828e11c6e280e4f00882c6f5b022c865d2f2884`
- `tests/test_claude_reminder_probe.py`: `42458ca38ad1e1c80c6cf3cbf28a464df95e1e22c14cbf49424683bed824ebfb`
- `tests/run-five-agent-release.py`: `185f2a55722109d16a135a4ce6ea91a0dd0f2cf53e8ff0c2efbecb51cb6a069f`
- `tests/five_agent_runtime.py`: `6ddf7e25d49319cd0150208e4007df9f1af5c823320e5a07c100f6cfc9b53af6`
- `tests/test_container_release.py`: `331680c17d5b32e952861c1527c6106fd62f2324f213e7c862e07f7a69162c94`
