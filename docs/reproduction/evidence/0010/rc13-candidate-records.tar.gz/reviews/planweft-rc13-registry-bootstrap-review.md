# RC13 registry CLI bootstrap 独立审查

结论：当前有界改动没有发现阻塞问题。23 项离线回归 Passed；这不是远端安装或真实宿主验收。未运行 Docker、模型、npm 安装或联网下载；未修改实现。

## 核查范围与依据

- 新增直接 toml 依赖后，不能继续运行裸解包的 bin/planweft.mjs。bootstrap_cli 在任何 npm 调用前重新核对准确归档 SHA，将归档通过 npm install --ignore-scripts --omit=dev 安装到当前独立 output 下 cli-bootstrap/<version>，并要求目标是新目录。npm 的正常运行依赖解析在该持久目录中完成。
- 每份安装后的 PlanWeft 文件对照独立解包内容逐文件核对字节和可执行位；dist 文件集合还执行严格相等检查。该检查不宣称 npm 依赖目录等同于发布包源码，也不宣称锁定了 registry 上所有传递依赖的长期状态。
- packages 保持准确归档的解包内容；cli_packages 单独持有 npm 安装后的可执行入口。主安装生命周期、回退 CLI 和 OpenCode Skill 配对都使用相应版本的 cli_packages；原生内容核对仍使用 packages，不会把待检实际安装目录当作自身预期。direct_npm_lifecycle 的兼容默认参数仅供现有离线 fixture 使用，main 始终传入 bootstrap 映射。
- 清理新增 run/cli-bootstrap，与 run/npm-cache 同属明确管理的可重建目录。只有 worker Passed、版本/归档/执行器绑定一致且所属容器确认已删除后才会删除；失败、未核对清理、意外目录链接均保留。其他 profile、归档、源码解包和日志未被新增清理覆盖。没有全局 prune。
- 容器入口的资源阈值、2 CPU / 3 GiB / 256 PID / 512 MiB tmpfs、总时限、冻结执行器、逐宿主串行、标签绑定清理保持不变。新的安装成本仍由既有整场上限承接。

## 回归结果和边界

执行：python3 -m unittest discover -s tests -p 'test_registry_*.py' -v

结果：23 tests Passed。新增测试验证摘要不符时不调用 npm、已存在目标拒绝、实际 CLI 字节变化拒绝、依赖安装命令参数与非解包入口，以及两个缓存必须在成功且已移除容器之后共同清理。既有原生升降级序列、唯一 Skill/Extension、错误版本、OpenCode 卸载残留与用户配置保护反例仍通过。

注意：新增测试中的 npm 安装是显式 fake；它证明执行器接线和拒绝条件，不能证明真实 npm 成功解析 toml。准确 RC13 远端五宿主运行需由主 Agent 串行执行，模型会话仍为单独门槛。当前 verify_native_package 的整个包检查是逐预期文件，只有 dist 同时禁止额外文件；本次新目录 bootstrap 不复用旧目录，未引入旧文件残留路径。

## 审查绑定

- `tests/run-registry-smoke.py` SHA-256 `f14d9b18232b2e31c2013caed794f844c009e73040252447052e0de458d4be56`
- `tests/run-registry-containers.py` SHA-256 `df9e7abb0d60685df78a26e8b80bc15c797cf291b797f1c5aca3f2f5f37b892e`
- `tests/test_registry_native_lifecycle.py` SHA-256 `dca790027d156473f1102a0c1ca13524880e6ce317c763ec30fd7c822bda923d`
- `tests/test_registry_containers.py` SHA-256 `bbc32748cc1e22b1ff97239bcc34fda616efc6422a2e0cd5b31c0cd41e4798a5`
