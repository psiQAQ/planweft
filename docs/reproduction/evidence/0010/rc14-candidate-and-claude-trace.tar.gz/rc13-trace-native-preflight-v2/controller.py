
import hashlib,json,os,subprocess,sys,tarfile
from pathlib import Path
sys.path.insert(0,'/runner')
from claude_hook_trace import analyze_trace,TRACE_SYSCALLS,RAW_SYSCALLS
with tarfile.open('/input/package.tgz') as t:t.extractall('/tmp')
work=Path('/tmp/project');work.mkdir();home=Path('/tmp/home');home.mkdir()
for name,lines in {'task_plan.md':['# Task Plan','','## Goal','Complete synthetic fixture','','### Phase 1','- **Status:** complete'],'findings.md':['# Findings'],'progress.md':['# Progress']}.items():(work/name).write_text(chr(10).join(lines)+chr(10))
native=Path('/tmp/package/dist/claude/planweft')
driver=Path('/tmp/driver.py')
driver.write_text('''import json,os,subprocess\nfrom pathlib import Path\nroot=Path("/tmp/package/dist/claude/planweft")\nresults=[]\nfor n,event in enumerate(["session-start","user-prompt-submit","post-tool-use","post-tool-use","user-prompt-submit","post-tool-use","post-tool-use"]):\n payload={"cwd":"/tmp/project","session_id":"synthetic-preflight","tool_name":"Write","tool_use_id":"synthetic-"+str(n)}\n p=subprocess.run(["sh",str(root/"hooks/claude-hook.sh"),event],input=json.dumps(payload),text=True,capture_output=True,cwd="/tmp/project")\n assert p.returncode==0,(event,p.returncode)\n results.append({"event":event,"bytes":len(p.stdout.encode()),"output_sha256":__import__("hashlib").sha256(p.stdout.encode()).hexdigest()})\nPath("/output/driver.json").write_text(json.dumps(results,indent=2)+"\\n")\n''')
trace=Path('/tmp/private.trace');command=['strace','-f','-ttt','--decode-pids=comm','-s','4096','-e','trace='+TRACE_SYSCALLS,'-e','raw='+RAW_SYSCALLS,'-o',str(trace),'--','python3',str(driver)]
try:
 p=subprocess.run(command,env={**os.environ,'HOME':str(home),'CLAUDE_PLUGIN_ROOT':str(native)},cwd=work,capture_output=True,text=True,timeout=60)
 Path('/output/driver.stderr').write_text(p.stderr)
 assert p.returncode==0,'Native driver failed'
 raw=trace.read_text();assert len(raw.encode())<16*1024**2
 resources={key:hashlib.sha256((native/key).read_bytes()).hexdigest() for key in ['hooks/claude-hook.sh','scripts/inject-plan.py']}
 result=analyze_trace(raw,native,resources,max_bytes=16*1024**2)
 import re,collections
 inventory=collections.Counter(re.findall(r'(?m)^\d+(?:<[^>]+>)?\s+[0-9.]+\s+(\w+)\(',raw))
 result['syscall_inventory']=dict(sorted(inventory.items()))
 result.update(scope='Offline actual Shell/Python dispatcher under fixed strace; not a Claude model session',source_sha256=hashlib.sha256(Path('/runner/claude_hook_trace.py').read_bytes()).hexdigest(),strace=subprocess.check_output(['strace','--version'],text=True).splitlines()[0])
 Path('/output/observation.json').write_text(json.dumps(result,indent=2)+'\n')
finally:
 trace.unlink(missing_ok=True)
