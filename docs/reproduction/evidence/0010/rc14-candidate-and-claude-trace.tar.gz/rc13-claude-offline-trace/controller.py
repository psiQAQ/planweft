
import json,os,resource,signal,subprocess,tarfile,time
from pathlib import Path
with tarfile.open('/input/package.tgz') as archive:archive.extractall('/tmp')
work=Path('/tmp/project');work.mkdir();home=Path('/tmp/home');home.mkdir()
for name in ['task_plan.md','findings.md','progress.md']:(work/name).write_text('# Synthetic no-model diagnostic\n')
env={**os.environ,'HOME':str(home),'ANTHROPIC_API_KEY':'SYNTHETIC_NO_NETWORK','ANTHROPIC_BASE_URL':'http://127.0.0.1:9','DISABLE_TELEMETRY':'1'}
plugin='/tmp/package/dist/claude/planweft'
from sys import path
path.insert(0,'/frozen')
from claude_hook_trace import TRACE_SYSCALLS,RAW_SYSCALLS
command=['strace','-f','-ttt','--decode-pids=comm','-s','4096','-e','trace='+TRACE_SYSCALLS,'-e','raw='+RAW_SYSCALLS,'-o','/output/no-auth-private.trace','--','claude','-p','--no-session-persistence','--plugin-dir',plugin,'--model','deepseek-v4-flash','--output-format','stream-json','--verbose','Reply OK. Use no tools.']
resource.setrlimit(resource.RLIMIT_FSIZE,(16*1024**2,16*1024**2))
os.umask(0o077)
with open('/output/stdout','w') as stdout,open('/output/stderr','w') as stderr:
 p=subprocess.Popen(command,cwd=work,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
 timedout=False
 try:p.wait(timeout=25)
 except subprocess.TimeoutExpired:timedout=True
 finally:
  for sig in [signal.SIGTERM,signal.SIGKILL]:
   try:os.killpg(p.pid,sig)
   except ProcessLookupError:pass
   try:p.wait(timeout=2)
   except subprocess.TimeoutExpired:pass
Path('/output/native-result.json').write_text(json.dumps({'exit_code':p.returncode,'timed_out':timedout,'scope':'No authentication, no network, synthetic placeholder only; startup diagnostic is not model acceptance'}))
