# Claude 实际 marketplace payload 绑定独立审查

本次只读检查指定四文件与既有脱敏原生事件，未读取认证、启动容器或模型，未修改实现。

## 依据与结论

真实 RC13 traced reminder 的 native stdout 第 5 与 218 条 init 均列出 planweft 插件根 `/workspace/.planweft/registries/claude/payload`，同一受管 marketplace source 和 RC13 版本。旧验证器仅核对 version cache，不能等同于此实际执行路径。新 verify_files 同时核对 exact package、持久 package、cache 及 managed payload；固定 registry catalog 名与 receipt、一条 planweft source=`./payload`，并把 payload 保存为 native_root、cache 另留 cache_root，修复有直接运行依据。Protocol 新增 init plugin.path 精确核对，路径不符 fail closed，双回合仍要求一致 metadata。

这些变更不会把历史 trace identity/result 失败改判 Passed，亦未建立 hook->tool 投递或提醒去重。必须使用新冻结执行器重采诊断；旧 raw trace 已销毁，不能离线臆造重算成功。

## P2：payload 内部同字节 symlink 尚能通过

根路径/catalog 的 resolve 比较只能排除其自身祖先链接。逐 manifest 文件仍用 is_file/read_bytes/stat，会跟随内部 symlink。独立最小 fixture 将 payload/hooks/hook.sh 改为指向外部同内容普通文件的链接，verify_files 仍保存 installed-content Passed。这与此次“无 symlink 的已核对执行资源”边界不符。建议逐文件再检查 resolve 与 absolute 相同，同时覆盖最终文件和中间目录链接，补两个负例；无需扩大为全局文件系统扫描。

## 验证

- test_claude_reminder_probe.py：13 tests Passed（8.433s），含 wrong-plugin-path。
- test_container_release.py：28 tests Passed（1.364s），含 mutated payload 与 foreign source。
- 独立同字节外部文件 symlink 反例：复现错误 Passed，待修。

## 来源绑定

- `tests/five_agent_runtime.py`: `3d9f6db957f676023a756d2388bb0b0f33da1ecabd88bce5764a4cfb77428144`
- `tests/claude_reminder_probe.py`: `1a5a7548530f386897d3ea73236c0c36dd5131ae5481315b7c7181ef843ea8ff`
- `tests/test_container_release.py`: `5b0f83e9314fdfcab8e02c6ef33ef3fddd705cd55a87164532d2a6eb56237621`
- `tests/test_claude_reminder_probe.py`: `d295dda9f0f53a746271e277197f24bc8b8325583f84078bc60eeed258bbcbc1`
- 实际 native stdout: `d0f3bb91bcdb33cfd82e86b7715d21f487758d846f886b94991fa53ce48b0603`

## P2 修复复核：已关闭

保留上述原始复现。当前 verify_files 对 Claude 的 payload、cache、持久 package 每个 manifest 路径，在读取内容前检查 `p.resolve() == p.absolute()`，因此最终文件与任意中间目录的 symlink 都被拒绝。同字节 file symlink 和 hooks 目录 symlink 已转为永久负例，二者要求明确的 RuntimeError，恢复后继续验证 foreign source 拒绝。独立重跑 test_container_release.py：28 tests Passed。修改只加强 Claude 资源验证，未改 hook parser 或历史证据。

已冻结运行沿用原执行器摘要；本修复不追认历史 snapshot 的 symlink 验证，必要时只读补核其已保存实际 payload，并明确派生核查来源。

复核文件摘要：
- `tests/five_agent_runtime.py`: `0f74ab7ba27d5ba693f04dea81311e77f4ba1d7ee56dcfedc8fdd158fd2dd3e2`
- `tests/test_container_release.py`: `b9c04611cbbe8f680c23db78a4541eef3ff3c41a8a1afe4312058a83b11fc63e`
- `tests/claude_reminder_probe.py`: `1a5a7548530f386897d3ea73236c0c36dd5131ae5481315b7c7181ef843ea8ff`
- `tests/test_claude_reminder_probe.py`: `d295dda9f0f53a746271e277197f24bc8b8325583f84078bc60eeed258bbcbc1`
- 独立离线测试日志: `281b87090ddc6048aabec13b336acdbee7d692c2f43cb92e4b6168c1320c932c`
