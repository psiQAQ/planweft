# RC13 Claude 私有 trace 采集接入审查

结论：当前接入发现两项 P2 阻塞，应在真实模型采集前修复。原有 13 项离线测试 Passed，但不能覆盖新增结果路径交换和导出阶段中断。未审查仍由另一个 worker 完善的 `claude_hook_trace` 归因实现，以下仅针对采集／导出／生命周期接入。

## P2：新增 trace 元数据路径可覆盖非自有目标

`export_private_trace()` 使用 `paths['trace'].write_text(...)`；初始 validate 只证明调用前不存在。运行期间如果该位置出现指向 foreign 文件的符号链接，write_text 跟随链接覆盖 foreign 文件，随后 artifacts 哈希还会跟随该路径读取。私有 raw FD 的 inode 检查无法保护这个独立输出目标。

离线最小反例复用了 `ClaudeReminderTest.fixture` 及真实合成 Python 子进程，以 mock Popen 在运行期间为 `claude-reminder-trace-observation.json` 建立指向 fixture 外侧 foreign.log 的链接；mock analyzer 返回固定数字／空列表元数据。结果：`foreign_changed=true`、foreign 含 trace 元数据、returncode=0、collection_status=Passed，私有目录正常清理。未使用 Docker、模型或认证。

最小修复：输出使用排他创建（例如 open('x')，或持有 O_EXCL|O_NOFOLLOW 创建的 FD），拒绝运行中出现的目标；最终 artifacts 也拒绝非自有／符号链接目标，不能为了报告失败去读取 foreign 内容。增加负例要求 foreign 字节保持、collection Failed、私有清理成功且不导出 foreign 内容。既有 report 的通用写入并非本次新增路径；可复用一致的拥有权策略，但不要无界扩大实现。

## P2：trace 导出中断跳过私有清理

`finally` 中的 trace 导出在后续 debug 导出 try/finally 之外，且仅捕获 Exception。解析过程中 KeyboardInterrupt 会直接跳过 trace_fd/debug_fd/debug_parent_fd 关闭、私有目录删除和最后报告。

离线反例：同一合成 fixture，mock analyze_trace 抛出 KeyboardInterrupt。结果：中断向外传播、剩余 1 个私有目录、3 个额外开放 FD、无 observation report。子进程已经由 stop_owned 正常清理。复现后 reviewer 显式关闭这三个自有 FD，并由临时目录清理释放文件，无资源遗留。

最小修复：把 trace 与 debug 导出都纳入不可跳过的统一资源 finally；捕获普通错误及 KeyboardInterrupt，记录限长类型信息，保持 Failed并完成关闭／精确清理／结果落盘。新增相同负例，不把中断记录成 observation_complete 或 collection Passed。

## 已确认正确的接入边界

- trace_hooks 默认 False、严格 bool 校验在创建输出或启动进程前；旧模式不启用 strace。runner 的开关只允许 Claude reminder-collection，且要求锁文件 strace6.1，在认证、创建输出和 Docker 前拒绝无效范围。两个 tracing 开关无法组合成合法但互相矛盾的场景。
- 冻结并只读挂载独立 trace parser；manifest 记录摘要。准确 npm 包不被修改，trace 是外部执行器观察。
- 私有 raw 与 debug 同处 mkdtemp 私有目录，0600 文件通过 O_EXCL|O_NOFOLLOW 创建并持有 FD；每次尺寸检查核对目录、命名项及打开文件的 dev/inode/uid，拒绝交换文件／链接。raw 只从已验证 FD 读取，最大读取 TRACE_LIMIT+1，必须完整 UTF-8及末尾换行。
- strace 不使用 read=/write= 数据转储，数据 syscall 采用 raw 指针／计数格式。仍可能出现私有 exec argv；因此 raw 不导出，先以调用方已知秘密检查整段文本，发生脱敏变化时失败，而不是脱敏后算解析通过。analyzer 抛出的错误只记录类型，不导出其 argv 文本。
- raw trace 16 MiB、debug 8 MiB、stdout16 MiB、stderr8 MiB，并受合计48 MiB检查；trace元数据与主报告分别32 KiB，留有64 KiB预算。文件大小是轮询检查，可能在下一次轮询前短暂超限，并非内核精确16 MiB限额；外层容器tmpfs512 MiB和内存3 GiB提供额外总量边界。parser内部内存／复杂度由其独立review负责，本次不代证。
- 两回合继续使用同一进程、A真实成功后才送B；trace observation完整只写独立布尔值，不把它当上下文实际投递。collection_status可以Passed，status和reminder_deduplication仍Not Run，runner总结果Incomplete；不修改gate门槛。
- 正常／异常停止只处理所属进程组，绝不按进程名清理。发现的中断窗口发生在进程关闭之后的私有文件生命周期，不能以“容器最终会移除”代替修复本地collector的资源保证。

## 验证

`PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s tests -p 'test_claude_reminder_probe.py' -v`：13 tests Passed，8.159 秒。两个上述额外离线负例复现 Failed safety behavior；没有编辑测试或实现文件。完整／不完整／秘密／截断／私有交换链接／限额／普通解析异常七子场景在现有新增测试中已覆盖；其中不完整归因仍可为 collection Passed但 observation_complete=false，这是采集与归因分离，不是提醒门槛放行。

真实 Claude、strace进程、模型、认证及容器：本次 Not Run。私有 trace parser 的语义审查：由另一 worker负责，不重复审查或背书。主 Agent 收到两项明确发现并在处理；本报告保留首次复现，不覆盖历史结果。

## 审查时 SHA-256

- `tests/claude_reminder_probe.py`: `a8b3798de7594e9dc449cfbe9ee1ba77bc4ac753f8fbefca71dd2cc77ecc21b7`

- `tests/test_claude_reminder_probe.py`: `053589fc90c09b282e9b4978681f5563348b092b38740c6a956f05f1bf3bfdfa`

- `tests/run-five-agent-release.py`: `dd599fb901bc5524b9607c03b7fbaf8b560f62088161326c79e05e11040c7757`

- `tests/five_agent_runtime.py`: `d64ba3007be00645911617da3ed280fb1a324e559e6d41149e647582a1fbce8a`

## 修复后独立复验：两项 P2 已关闭

主 Agent 将 trace 元数据改为排他 `open('x')`，最终 report 同样排他创建；artifacts 避开符号链接，不再沿复现链接读取 foreign 文件内容。trace 及 debug 导出捕获 `(Exception, KeyboardInterrupt)`，记录 Failed 后继续描述符关闭和精确私有目录清理。原始两项发现与失败结果保留在上文。

Reviewer 没有修改实现，重新使用原两种故障注入独立复现：

| 原反例 | foreign 字节 | 返回码／状态 | 私有目录剩余 | FD 泄漏 | 最终报告 | trace artifact |
| --- | --- | --- | ---: | ---: | --- | --- |
| 运行时输出 symlink | 不变 | 1／Failed | 0 | 0 | 存在 | 未导出 |
| analyzer KeyboardInterrupt | 不变 | 1／Failed | 0 | 0 | 存在 | 未导出 |

全量定向 `test_claude_reminder_probe.py` 再运行：13 tests Passed，8.206 秒；永久测试已增加 output-symlink、interrupted 两个子场景。私有 trace 原字节不出现在公开结果，foreign 链接未被当自有文件删除。无容器／模型／认证操作，合成子进程及临时文件均已清理。

当前在本次限定采集接入范围内无剩余阻塞。结论不扩张为对恶意进程持续并发交换整个 results 目录的 OS 沙箱保证，亦不承诺 SIGKILL 下 Python finally 能运行；外层隔离与所属容器清理边界继续适用。归因模块仍需独立审查，完整 trace 仍仅诊断 Not Run，未获得真实提醒去重 Passed。

最终源码绑定：

- `tests/claude_reminder_probe.py`: `a8b3798de7594e9dc449cfbe9ee1ba77bc4ac753f8fbefca71dd2cc77ecc21b7`

- `tests/test_claude_reminder_probe.py`: `053589fc90c09b282e9b4978681f5563348b092b38740c6a956f05f1bf3bfdfa`

- `tests/run-five-agent-release.py`: `dd599fb901bc5524b9607c03b7fbaf8b560f62088161326c79e05e11040c7757`

- `tests/five_agent_runtime.py`: `d64ba3007be00645911617da3ed280fb1a324e559e6d41149e647582a1fbce8a`
