# RC13 Claude hook stdout 归因器独立审查

当前结论：初始冻结版本的 18 个离线测试 Passed，但独立对抗轨迹暴露后代信号退出、exec 读取代次、未支持搬运调用的 FD 并发及 Linux FD 别名四项阻塞；根进程与解释器身份也需要收紧或明确外部约束。发现已交实现 worker 修复，下面保留首次结果，后续修复复验另行追加。本报告不等同于真实 Claude 去重通过。

初始绑定：`tests/claude_hook_trace.py` SHA-256 `f0aefdd76fc07ffcc6eb9101db783407dbda78209c694510b092f3015799d1de`，`tests/test_claude_hook_trace.py` SHA-256 `7a7855b2c6cdd79017a0865c130031ef9c3c5be0d81b4da5eba1d38b6ada6260`。依据 `/tmp/planweft-rc13-claude-dedup-next-design.md`；只读代码与离线合成测试，不执行原生模型、容器、认证或联网。

## 初始发现与反例

| 问题 | 最小反例与实际错误结果 | 必须保持的边界 |
| --- | --- | --- |
| 后代 signal 退出 | 标准空输出 fixture 的 Python 子进程 exit0 改为 SIGKILL，dispatcher仍exit0；observation_complete=true。 | 设计明确 signal／不完整相关后代不能算正常空输出；标为不完整，保留原始信号事实。 |
| 缺 exec 代次区间 | 同一 PID 成功 Python exec两次，仅第二次实际读取 injector脚本；两个exec都被后一次read覆盖并complete=true。 | script read必须位于对应exec到下一exec／退出的区间，不能仅检查同PID generation及sequence大于exec。 |
| 搬运调用 FD footprint遗漏 | 宿主 tee(fd9,fd12,8) unfinished期间CLONE_FILES线程dup2(hook stdout读端3,9)；旧9是无关pipe。初始判定conflict_count=0且complete=true。 | 真实FD参数必须进入footprint；第二遍unknown搬运FD仍须按历史绑定拒绝相关歧义，不能endpoint(UNKNOWN)==None就当无关。 |
| Linux FD 导入别名遗漏 | hook通过/dev/stdout新FD写8字节；宿主通过/proc/self/task/100/fd/3新FD读8字节；原pipe后续真实EOF0。complete=true且stdout_empty=true。 | 不能把FD别名open一律当普通文件；至少拒这些已知别名，不让非零stdout从计数消失。 |
| 根／解释器仅名称假设 | root claude改cat、dispatcher/bin/sh改/untrusted/sh仍complete=true。 | 调用者固定镜像／准确路径／可执行字节是必要保证；basename或host标志本身不证明native执行身份。 |

合成轨迹 `/tmp/planweft-trace-tee-race.synthetic` 和 `/tmp/planweft-trace-fd-alias.synthetic` 保留原始复现，无秘密。前三个替换反例可由现有 `Fixture.add(child=True)` 直接构造，已发送给实现 worker，未编辑其源码或测试。

另一个源码边界：当前观察集缺少 `unshare`，但成功 CLONE_FILES／CLONE_FS unshare会改变所建模的共享关系；建议纳入观察并先以不支持失败，不必立即实现新共享状态算法。这是观察覆盖缺口，未运行真实 syscall。

## 已核对有效的部分

- 两遍重放复用进程世代／syscall完成区间；clone快照区间在实际子事件之前收紧，shared FD／cwd保留资源对象，exec去除确定CLOEXEC项。原有共享同FD冲突负例和无关FD正例通过。
- pipe单向、AF_UNIX SOCK_STREAM双向各建通道；dup／fork继承同资源，fd号复用创建新资源；内部命令替换pipe不计入原dispatcher stdout。
- 用户提出的EOF问题已有有意义负例：read／recvfrom请求长度必须大于0且实际返回0；raw readv=0不能推断EOF；EAGAIN/EINTR与EOF区别保留。MSG_PEEK、MSG_TRUNC等不支持接收标志拒绝；允许flags0和DONTWAIT。
- 宿主消费只认原root及CLONE_THREAD线程；hook子树自读不计宿主消费，foreign writer非零字节拒绝。晚于dispatcher退出的后代写入仍被累计；所有已记录进程必须有退出记录。
- argv／资源路径精确绑定与实际read要求使普通数据读取、错误脚本路径、额外event参数失败；两个dispatcher共享同stdout拒绝。脚本只读取调用者提供的两个固定资源，不按trace中任意路径读取磁盘。
- read/write系列必须使用raw数字／指针；decoded SECRET缓冲区负例只输出固定错误，不泄露payload。大小／行长限额先于资源读取，输出含固定枚举、数字、摘要而非argv。io_uring、相关不支持搬运、SCM_RIGHTS／未知非网络ancillary默认不完整。
- `proof_scope` 明确只证明命令身份及stdout字节／EOF，不证明模型投递或去重。四次hook数量、Native Write及additionalContext关联必须由外层另证；模块不能自行把模式N,0,N,0当完整发布验收。

## 调用者身份增强初查

主 Agent 随审查新增 `native_executable_identity()`，仅trace=true时调用；从固定只读镜像的which取得claude与shell/python，记录文件SHA，解释器允许列表仅加which、resolve及/bin／usr/bin／usr/local/bin下samefile别名；默认false不变。校验在输出创建和进程启动之前，哈希分块读取，不触碰auth或项目配置。

允许列表只是传入的已核对路径集合，独立二进制来源由完整固定镜像ID、只读部署与调用者记录的SHA承担；parser不应声称自己认证了解释器文件内容。真实固定Claude入口是否为wrapper及实际exec路径是否一致，需要原生trace验证；不应为了通过静默接受未知替换exec。

## 首轮执行结果与范围

`PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s tests -p 'test_claude_hook_trace.py' -v`：18 tests Passed，0.048秒。上述独立对抗例呈现错误complete=true，须修复后再复算。没有实际模型／容器／认证，也未修改源文件。

任意外部进程持续替换路径、未观察symlink将普通路径转为FD别名等不属于目前已证明能力；若宣称通用完整stdout归因，必须补充相应观察而不能仅扩大已知路径黑名单。本轮应坚持固定镜像、固定准确包、受限四Write场景的有界证据，保留无法归因项为不完整。

## 二次冻结后的独立复核：初始发现已关闭

最终模块增加必需 `expected_host_executable` 与 shell/python 绝对解释器路径集合；缺省／错误绑定均不完整。只认初次实际root exec为该路径，此后宿主root／线程任何新exec清除host身份并拒绝，不让后续cat等进程继承native消费资格。解释器不再仅按basename匹配。调用者固定镜像、which/samefile和实际文件SHA提供其外部来源保证，模块按明确接口验证路径；不是模块自行认证任意传入的允许列表。

每个Python fast-path记录exec_generation、起止sequence及退出方式；新exec终结前一个execution并标exec-replaced失败，读取匹配该具体区间／代次。hook子树出现signal termination明确失败；没有放宽正常空输出判据。

TRANSFER_FDS统一规定真实FD参数，加入共享资源footprint和uncertain_io历史关联；先前tee共享FD反例现在识别1个冲突并拒绝。已知/dev/std*、/dev/fd及/proc task FD别名被拒绝；unshare纳入实际观察集并保持不支持失败。未知别名／任意外部symlink仍明确是调用者隔离布局前提，不宣称通用文件系统别名解析。

已知普通file上的pread等不再仅因调用者处于hook子树而全局失败；若触及目标channel、未知hook FD或相关绑定歧义，仍失败。这个调整保留“无关读不误拒”的原设计边界；script身份依旧需要支持路径上的实际read，不以pread无关排除替代read绑定。

Reviewer 独立执行：

- 25项模块离线tests Passed，0.068秒。
- 13项collector离线tests Passed，8.272秒，包含新身份接口接入及原私有日志清理负例。
- 原始root换cat、同basename陌生解释器、Python后代SIGKILL、同PID重复Python exec只有后次read、root后续exec、tee FD竞态、两个FD别名隐藏非零输出，七项全部 observation_complete=false，原合成trace保持不变。tee竞态现在报告binding_conflict_count=1；FD别名不再误报完整空输出。

本次限定源码审查无剩余阻塞。正常输出仍仅为observation，不是模型delivery或dedup Passed；真实固定strace/Claude管道形状、每个native tool对应hook、additionalContext被接收及模型继续，必须由下一次真实诊断和独立关联补齐。原无CLAUDE_PLUGIN_ROOT／旧版本诊断记录不能改写为新模块通过。没有运行模型、Docker或读取认证；未编辑实现或提交。

### 最终源码与证据摘要

- `tests/claude_hook_trace.py`: `6ebfb00b4d35726bdac7db8db3885c689be4b476141b4778cbfd950a77d6eb4d`

- `tests/test_claude_hook_trace.py`: `f46bbbbf3eb79441092b72919d998f25c4ef0c553943af8df1ff0998a74b8ba8`

- `tests/claude_reminder_probe.py`: `feea3445af3700375d1bfb8f47ab4111ccc788e89e93a9eac47216e0a07ca0c6`

- `tests/test_claude_reminder_probe.py`: `30b9952b1b2e2f81449365df60745df0c9bbbaf32d934319a63bc74cf3a61afe`

- `tests/gate_process_trace.py`: `bfdfb93206538ea41dbb8137feccc28b0611ca3ed5aa0e1fd5f4d788cb392954`

- `tests/run-five-agent-release.py`: `dd599fb901bc5524b9607c03b7fbaf8b560f62088161326c79e05e11040c7757`

- `tests/five_agent_runtime.py`: `d64ba3007be00645911617da3ed280fb1a324e559e6d41149e647582a1fbce8a`

- `planweft-trace-tee-race.synthetic`: `19033865ed32455cb7a884f66828d62786fa957ed6f56a7f0e07e031e007d9ba`

- `planweft-trace-fd-alias.synthetic`: `172bc5a61957f69818294f611a5f5105cd8d4cd4cdd2235f71f29aff438d605f`

- `planweft-rc13-claude-dedup-next-design.md`: `864ae082d1b2460220b72424bfb2808fdf8b9b141b76cbfed5bed4e9b3e6487a`
