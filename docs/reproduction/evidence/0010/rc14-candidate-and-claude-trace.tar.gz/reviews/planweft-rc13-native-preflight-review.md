# RC13 真实无模型 trace 预检 v3 独立审查

结论：**可以进入默认限额的 Claude 真实 traced diagnostic 采集，没有新增实际采集安全阻塞。** v3证明固定strace与真实Shell/Python dispatcher的七项stdout计数能被当前归因器解析；它不是Claude模型会话，也没有证明原生hook到model的去重。未知FD别名布局前提及完整Claude管道适配继续Not Verified，不能凭observation_complete放行发布gate。

## 准确来源与冻结绑定

证据组 `/var/tmp/planweft-040/rc13-trace-native-preflight-v3`。本reviewer没有运行模型、Docker、认证或网络；只读既有附件及准确归档，另作一个临时合成离线限额反例。

- 实际保留的 `remote-planweft-0.4.0-rc.13.tgz` 独立重算SHA为 `793e3f2c4d5f7e6e8f180494e1f05ea07db2ddd30426edf6c837b6b775e09bda`；包内name/version正确。4,060成员全部普通文件／目录，没有链接、特殊文件、绝对路径或上级穿越。
- 两份 frozen 模块与 frozen-manifest及先前独立审查摘要逐项一致：hook parser `6ebfb00b4d35726bdac7db8db3885c689be4b476141b4778cbfd950a77d6eb4d`，base gate parser `bfdfb93206538ea41dbb8137feccc28b0611ca3ed5aa0e1fd5f4d788cb392954`。
- summary记录固定派生镜像 `sha256:62ba84a827202b33ddb2e69046c4a7a3cf44627d8e5894bea5aaaadf42355d1e` 与容器exit0；observation报告strace6.1、16进程及16退出、30通道、0绑定冲突。不是旧v1/v2失败结果的重命名。
- 保留的外层 `/tmp/planweft-hook-trace-preflight-v3.py` 中controller代码与证据组controller.py逐字一致。它明确network none、只读root、2CPU／3GiB无额外swap／256PID、/tmp512MiB、只挂准确包／冻结runner／结果目录；无个人HOME、auth或业务项目挂载。其root为Python driver，**不是Claude进程**。
- observation的解释器文件摘要来自实际镜像路径及samefile别名；expected_host_executable是driver的python3，属于明确的调用者绑定。镜像与二进制摘要可供后续复核，本次没有重新启动镜像来重复哈希，不能称为第二次独立镜像实测。

## 七项实际观察核对

独立比较driver.json与observation每个hook：event顺序、driver字节、全部write/read行之和相等；EOF是宿主root实际read返回0，完成序号在dispatcher exit之后；dispatcher/Python exit0、无后代signal、不同output channel，无foreign writer或非宿主消费。script_reads及fast_path_reads所绑定源码SHA与准确tar中两脚本一致。

| 次序 | event | driver／trace写／宿主读字节 | 真EOF／正常退出 |
| --- | --- | ---: | --- |
| 1 | session-start | 1075 | 是 |
| 2 | user-prompt-submit | 1079 | 是 |
| 3 | post-tool-use | 187 | 是 |
| 4 | post-tool-use | 0 | 是 |
| 5 | user-prompt-submit | 1079 | 是 |
| 6 | post-tool-use | 187 | 是 |
| 7 | post-tool-use | 0 | 是 |

两个非空PostToolUse的driver内容摘要相同；两个空输出是空字节SHA。原raw trace已按私有清理策略销毁，本reviewer不能重新从原syscall文本重放；上述是对已冻结parser及保留结构化逐行观察的交叉核查，不伪称重跑原始trace。输出内容正文没有保留，因此仅核对driver所记内容SHA，不能凭摘要重新解释additionalContext内容。

## 隔离布局与后续范围

driver只从准确无链接归档解包，构建三个普通合成记录，固定7次调用包内dispatcher，没有模型／自定义项目命令或创建任意FD别名。已知/dev/std*及/proc task FD导入由parser拒绝。这足以支持本次有界协议预检，并允许在已有安全collector下进一步观察真实Claude。

完整固定镜像中是否存在未观察的任意symlink导入FD，以及真实Claude复杂原生进程是否满足同样布局前提，本次**Not Verified**；不要把“普通open路径”普遍当作已证明不可能导入FD，也不要求为开始诊断先进行无关全盘扫描。真实诊断继续只允许合成四Write、准确包、已有隔离模型路线，原始trace私有并在结束销毁；若观察出现不支持I/O或绑定歧义，保持不完整。预检只证Python driver消费，真实Claude宿主消费与native工具／context关联必须另证。

外层使用--rm和finally精确容器名rm，controller finally删除private.trace。清理流程明确；本组未单独保留rm结果／容器剩余列表，本reviewer没有额外Docker查询，因此不把独立清理查询写成已执行。后续正式runner应继续保留现有清理证明。

## 256 KiB 元数据调整与一个非阻塞窄残留

真实observation为47,309字节，超过旧32KiB；单独提升trace结构化元数据到256KiB有实际依据，未恢复raw导出，主报告仍32KiB。新增metadata-oversized反例要求超过256KiB在写入前失败，私有源清理不变。默认48MiB总限额下，stdout／stderr／debug最大合计32MiB，加256KiB元数据仍低于总额；不阻塞此次默认限额诊断。

但导出trace时只检查256KiB，尚未扣减自定义limits.total：reviewer离线令total=128KiB、合成解析元数据约200KiB，实际总输出222,156字节，trace204,862字节，虽然最终Failed且私有目录清理成功，仍超声明总额。最小建议导出前同时检查 `min(TRACE_METADATA_LIMIT, total - 65536 - 已输出字节)`，并补小total负例；不要等debug预算分配时才发现已写超限。此处不把非默认测试限额缺口夸大为当前默认采集泄密或gate放行，也不修改实现。

## 附件摘要

- `container.stderr`: `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`

- `container.stdout`: `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`

- `controller.py`: `428545e541e6096b3a317838a7acd7d83b4a76e5b3e8da5adbc9bb8f75388fe4`

- `driver.json`: `14e57ca913f051c75d438468283f89b5fd29ac5593c32a1626346d26e5083ac9`

- `driver.stderr`: `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`

- `frozen/claude_hook_trace.py`: `6ebfb00b4d35726bdac7db8db3885c689be4b476141b4778cbfd950a77d6eb4d`

- `frozen/gate_process_trace.py`: `bfdfb93206538ea41dbb8137feccc28b0611ca3ed5aa0e1fd5f4d788cb392954`

- `frozen-manifest.json`: `cee2a2b77fcf8c973e29057ed7156625cd6735d08b2dbee6f9acf21084be9d1c`

- `observation.json`: `33a58d624d32dbf3889cfa263465feccb6573d8fec8005f3ea9c4dcd1baf2a33`

- `summary.json`: `37f09c04b0f6ffe26dd06097ba57fa978cb33fd9110e1efd08b918268c8169b6`

- `/tmp/planweft-hook-trace-preflight-v3.py`: `173a107ffcbe7cf7109a1d4b00ec5cc937d1d5f1cdbecc02c1ba36f17ea4e6b4`

- `tests/claude_reminder_probe.py`: `e08e0b3b7db411c06b5d4e98bfd73c636a90fdeb6f454150af131e01b68673f1`

- `tests/test_claude_reminder_probe.py`: `b4533861c6a0cc53d46fb36d3bd418f452376b478b336153c5dd41e904dd4726`

## 自定义总限额 P2 修复复核（已关闭）

保留上面的原始失败。当前导出先统计已有 stdout/stderr 等产物，再取 `max(0, min(TRACE_METADATA_LIMIT, limits.total - 65536 - already_written))`，超预算在创建 trace 文件前失败。reviewer 独立重放原 128KiB 总额／约 200KiB 元数据反例：总产物 17,170 字节，未创建 trace，collection Failed，私有目录清空，均符合预期。检查源码及新增 metadata-total 回归，无新的采集安全阻塞。此关闭不将真实 Claude 去重或任意 FD alias 布局改判 Passed。

复核源码 SHA-256：`e08e0b3b7db411c06b5d4e98bfd73c636a90fdeb6f454150af131e01b68673f1`；测试源码：`b4533861c6a0cc53d46fb36d3bd418f452376b478b336153c5dd41e904dd4726`。本次只执行独立定向离线复现，未启动模型、容器或读取认证。
