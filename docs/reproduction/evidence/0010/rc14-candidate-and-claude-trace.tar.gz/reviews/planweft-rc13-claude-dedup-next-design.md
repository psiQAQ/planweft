# RC13 Claude：逐 hook 去重证据的最小补齐设计

本次仅静态设计审查；没有运行模型、容器或认证，没有修改准确包或 hooks。结论：沿用已有私有 strace 采集路线可行，但需要一个独立的 pipe/FD 输出归因器。当前原生 debug 和 gate_process_trace 均不能单独证明第二次 PostToolUse 的 stdout 为零。先实现并验证离线归因，再由 owner 串行执行一次新采集；原 v1 Failed、v2 collection Passed / dedup Not Run 保留。

## 已确认事实

- 准确 RC13：`793e3f2c4d5f7e6e8f180494e1f05ea07db2ddd30426edf6c837b6b775e09bda`。
- v2 原生独立审查：`/tmp/planweft-rc13-claude-reminder-v2-review.json`，SHA-256 `df84bea98f142820d6296e36b86a6cf09ef36d5756a0b89172c8191141aeaf38`。
- v2 四次 Write 均为真正的原生调用，两个输入通过 command UUID / session / result / command completion 串行绑定。A1、B1 的原生 debug 明确接收同源 PostToolUse additionalContext（109 chars）。A2、B2 仅有泛化 plain-text parser 日志，不能由此推断空字符串、正常退出或零注入。
- 固定 Claude 2.1.241 的已有私有 ELF 抽样表明，plain-text 分支覆盖所有 trim 后不以 `{` 开头的输入，包含空和非空。匹配集合还可能含 callback/function，并按来源去重；抽样不足以辨认本次第二个 matcher。`Matched 2 unique hooks` 不能直接等同于重复 PlanWeft 安装或两个外部 dispatcher。
- `hooks/hooks.json` 对 PostToolUse Write|Edit 配置一个 command。`claude-hook.sh` 优先执行原包 `inject-plan.py -I -B --claude-event=post-tool-use`；Python stdout 直接继承，exit 0 后 shell 结束，否则才进入 fallback。不能为了便于追踪关闭 fast path。
- `inject-plan.py:1485–1500` 中 marker 已存在时返回空 bytes；主函数仍调用 stdout.write/flush 并正常退出。空 bytes 不一定产生一次 `write(...,0)` syscall，因此需要 pipe 接收侧 EOF 和完整生命周期，而不是“没见 write”这一孤立事实。

## 首选采集路线及安全边界

复用现有隔离、准确资源摘要、strace 6.1、600 秒/2 CPU/3 GiB/日志限额和私有日志清理机制。直接从启动时跟随本次 Claude 进程树，不能等 hook 出现后才 attach（会漏掉短进程的全部输出）。不改 manifest、dispatcher、Python 或 tarball；不增加产品 wrapper、LD_PRELOAD、自动 hook。

专用探针只允许四次 Write，认证仍由既有授权的隔离 env/配置注入；不打开 MCP、认证 helper 或模型 Bash。保留 execve 的 argv 是准确 event 身份所需，沿用既有私有 trace 权限即可，不需要另造 tracer。实际新增风险是误开宿主数据缓冲区解码：必须对 read/readv/write/writev 以及所采集的其他数据搬运调用使用 raw 参数；禁止 `-e read=...` / `-e write=...`，这两个选项会额外转储 payload。

原始 trace 仅写随机 0700 私有目录内的 0600、持有 FD 的文件；复用 collector 对 dev/ino/uid、symlink、上限、截断和 finally 的检查。导出前使用执行器已经持有的 secret-aware 回调检测/脱敏，不重新读取凭据，不输出 env 字典。出现已知 secret 命中即失败、仅导出固定错误及有限数字，再销毁原 trace；不能把“已知 secret 零命中”表述为任意未知秘密不存在。公开附件只含数字、枚举、摘要及包内相对资源名，不含 argv、read/write buffer 或原始 trace。中断/超限同样清理；不会通过截断 secret 再做完整字符串匹配来掩盖泄露。

strace 官方 6.1 的 [选项说明](https://raw.githubusercontent.com/strace/strace/v6.1/doc/strace.1.in) 区分 raw syscall 参数和独立的 FD payload dump。其 [execve decoder](https://raw.githubusercontent.com/strace/strace/v6.1/src/execve.c) 也表明关闭 verbose 可以隐藏 argv，但会同时失去本场景所需 event 参数，因此不是本方案的默认设置。

## 归因器的最小契约

新增独立 `claude_hook_trace.py`，复用 gate_process_trace 的参数解析、进程代次及实际 FD/cwd 冲突思想，避免修改现有停止归因。输入完整 strace 文本、准确 native_root 和资源 SHA，资源读取回调只允许包内固定脚本；输出是逐 hook 的可复核 observation，不自行宣称模型接收或整个 release gate Passed。

1. **执行身份**：successful execve 的解释器路径、精确 `[sh, <native_root>/hooks/claude-hook.sh, <允许的 event>]` argv，以及同进程实际读取该脚本的 FD/路径/摘要共同绑定。识别 Python fast path 为该 dispatcher 子进程，核对准确 Python argv 与 inject-plan.py 实际读取摘要。不能只看 basename、marker 或某进程读过脚本；外层 `sh -c` 与内层脚本执行不得重复计数。根 dispatcher 中未知/额外参数、不同路径同 basename、资源变化、未读脚本不能证明身份。
2. **输出资源**：从 pipe/pipe2 创建起建立资源对象和读/写端，追踪 fork/clone、CLONE_FILES、exec CLOEXEC、dup/dup2/dup3、fcntl、close/close_range。stdout 是该 dispatcher 启动时 fd 1 绑定的具体资源，不是所有进程中数字 1。Python 和 fallback 后代写入同一资源只累计一次；内部命令替换 pipe 不计入 hook stdout。
3. **完整终止**：输出资源的所有成功 write/writev 返回字节数、宿主 read/readv 返回字节数及真实 `read(...)=0` EOF，连同 dispatcher 正常 exit 0、相关后代/FD 关闭，一起证明结果。A2/B2 必须具有真实 EOF、读取总量 0、写入总量 0 和正常结束。EAGAIN、EPIPE、超时、signal、未完成 syscall、缺 exit、遗留 writer、FD 模糊或未知搬运方式不能算空输出成功。
4. **范围控制**：首版支持已实现 pipe 路径；socketpair、SCM_RIGHTS、splice/sendfile/tee/copy_file_range、io_uring 等如果触及相关资源而尚未建模，应报告不能证明。普通 syscall 白名单不能悄悄漏掉这些替代传输。全局有界 metadata-only 探查可确定固定 CLI 实际使用范围；未知事实保留 Not Run。与目标 FD 无关的宿主读写不能全部视为冲突，但必须能证明无关；共享表中未知 FD 变动不能被忽略。
5. **原生回合关联**：保留 v2 sent UUID/native tool id 的顺序与成功结果。各 event 的 dispatcher exec/exit 顺序与四次严格串行 Write、原生 PostToolUse matching 窗口一一对应。所需数量、先后、窗口重叠有任何歧义就 Not Run，不依靠平均延迟猜 PID。先使用已有 native 有序协议和 trace 事件，没必要立即捕获 hook stdin；若确实无法关联，再单独设计限定已验证 hook stdin 的结构字段读取，不能打开全树 decoded read。
6. **去重结论**：需要恰好四个独立 PostToolUse dispatcher，输出量模式 `N,0,N,0`，N 的内容还须由 native accepted JSON/additionalContext 与准确源码绑定；两次 UserPromptSubmit 位于正确回合边界，只有最初一次 SessionStart。输出非零只证明写给宿主，不自动证明模型收到；原生实际 additionalContext 接收和随后的模型继续仍为独立要求。

两个 matcher 若仍无法命名，报告应说“原生匹配数为 2；已完整跟踪的外部 PlanWeft dispatcher 为 1/Write；第二 matcher 类型未确定”。若观察到两个实际同源 dispatcher，不能靠去重日志自行忽略它。对于本插件执行一次/回合内抑制输出的结论，准确 command 数与完整进程树可补强；对于原生内部其他 handler 身份，不宣称已证实。

## 必要离线反例

- 完整四调用正控、stdout 真零字节 EOF，以及一次非空但非预期 reminder（不得凭计数当内容正确）。
- fd 1 被 dup/关闭/复用，后代继承 stdout；子进程在 shell 退出后写；内部 pipe 有输出但宿主 pipe 为空。
- EAGAIN 与 EOF 区分、write 失败、无 EOF、截断/unfinished、signal/非零退出、缺父 clone 和 PID 复用。
- 同 basename 不同路径/摘要、把脚本当普通数据读、额外 argv、两个 dispatcher、同 stdout 被第二候选共享。
- CLONE_FILES 同 FD 并发变动须拒绝，不同 FD 的已证无关并发不应误拒；CLONE_FS 与 exec 代次保持准确。
- 未支持的资源/搬运方式不能产出空 stdout 成功；不能把某个 FD 号的网络数据归入 hook。
- 日志上限截断 secret 前缀不导出；已知凭据出现在 exec argv 时失败并销毁私有源；异常及正常 EOF 后所属子进程、文件清理，外部进程/路径不受影响。

## 本次审查源绑定

| 文件 | SHA-256 |
|---|---|
| tests/claude_reminder_probe.py | 5ca9da57d2c8b2d9f99be9c4fd89e9d15567a47e217e88b9eeb4183e6aa8c75b |
| tests/five_agent_runtime.py | 83876a6c37c93cf93e9ef4f88e22c5ee3f883c85d0b001a8f2445513a20c574c |
| tests/gate_process_trace.py | bfdfb93206538ea41dbb8137feccc28b0611ca3ed5aa0e1fd5f4d788cb392954 |
| dist/claude/planweft/hooks/claude-hook.sh | 380f1e7675e7e93f25b7a4beb0bc8209ecbbd1291f77de80767844a6c6eeebbd |
| dist/claude/planweft/hooks/hooks.json | 6bd6f31e8e5732d017f6447e9f2db2635fcc2d8ec7ae998e03ca5c7f2b15e7d7 |
| dist/claude/planweft/scripts/inject-plan.py | 6a655aa97ddabfe2cc939a9b56a18ebf152b0f6908e1f1d8b318104410824534 |

尚未验证：新归因器对真实固定 Claude 进程管道形状、完整输出数量和逐工具绑定的适用性。这是采集方案，不是 dedup 或稳定版发布通过证据。
