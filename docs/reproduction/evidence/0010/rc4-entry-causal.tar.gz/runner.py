from pathlib import Path
import subprocess
base=Path('/var/tmp/planweft-040/opencode-entry-causal');base.mkdir()
for case in ['original','main','server','both']:
 out=base/case;out.mkdir()
 command=['docker','run','--rm','--label','planweft.run=npm-entry-'+case,'--network','none','--read-only','--user','1000:1000','--cap-drop=ALL','--security-opt=no-new-privileges','--tmpfs','/tmp:mode=1777','--tmpfs','/workspace:uid=1000,gid=1000,mode=700','--tmpfs','/results:uid=1000,gid=1000,mode=700,size=768m','--mount','type=bind,src=/var/tmp/planweft-040/rc3-registry-containers/opencode/run/profile,dst=/original-profile,readonly','--mount','type=bind,src=/tmp/planweft-opencode-entry-probe.py,dst=/probe.py,readonly','--mount','type=bind,src='+str(out)+',dst=/evidence','--workdir','/workspace','--entrypoint','python3','sha256:35d7e7989b6fdbefb83135c647cf3eefffcd843b6a6a2a6b0587ced548efeec1','/probe.py',case]
 with (out/'container.log').open('w') as log: p=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=150)
 print(case,p.returncode,flush=True)
