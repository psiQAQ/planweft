from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys
case=sys.argv[1]
assert case in ['original','main','server','both']
profile=Path('/results/run/profile');shutil.copytree('/original-profile',profile,symlinks=True)
package=profile/'.cache/opencode/packages/planweft@0.4.0-rc.3/node_modules/planweft'
manifest=package/'package.json'
def inventory():
 return {p.relative_to(package).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in package.rglob('*') if p.is_file()}
before=inventory();old=manifest.read_text();data=json.loads(old)
entry='./dist/opencode/planweft/dist/index.js'
if case in ['main','both']:data['main']=entry
if case in ['server','both']:data['exports']['./server']=entry
if case!='original':manifest.write_text(json.dumps(data,indent=2)+'\n')
Path('/workspace/opencode.json').write_text(json.dumps({'plugin':['planweft@0.4.0-rc.3']}))
env={'PATH':os.environ['PATH'],'HOME':str(profile),'USERPROFILE':str(profile),'XDG_CONFIG_HOME':str(profile/'.config'),'XDG_CACHE_HOME':str(profile/'.cache'),'XDG_DATA_HOME':str(profile/'.local/share'),'XDG_STATE_HOME':str(profile/'.local/state'),'OPENCODE_DISABLE_AUTOUPDATE':'1','OPENCODE_DISABLE_MODELS_FETCH':'1','PLANNING_DISABLED':'1','NO_COLOR':'1','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'/dev/null'}
version=subprocess.run(['opencode','--version'],env=env,text=True,capture_output=True,check=True).stdout.strip();assert version=='1.18.22'
r=subprocess.run(['opencode','debug','agent','build'],cwd='/workspace',env=env,text=True,capture_output=True,timeout=90)
Path('/evidence/stdout.json').write_text(r.stdout);Path('/evidence/stderr.log').write_text(r.stderr)
new=inventory();changed=sorted(k for k in before.keys()|new.keys() if before.get(k)!=new.get(k))
tools=json.loads(r.stdout).get('tools',{});loaded=all(tools.get(k) is True for k in ['pw_init','pw_status','pw_check'])
passed=r.returncode==0 and loaded==(case!='original') and changed==([] if case=='original' else ['package.json'])
record={'case':case,'version':version,'fixture':'Published RC3 runtime/dependencies plus only the named manifest entry patch; not accurate RC4 or remote RC4','model_calls':'Not Run; Docker network disabled','status':'Passed' if passed else 'Failed','tools':{k:tools.get(k) for k in ['pw_init','pw_status','pw_check']},'changed_files':changed,'package_inventory_before':before,'package_inventory_after':new,'manifest_before':json.loads(old),'manifest_after':data}
Path('/evidence/result.json').write_text(json.dumps(record,indent=2)+'\n');print(case,record['status']);sys.exit(0 if passed else 1)
