# Codex native Stop collection independent review

结论：停止协议判定与 transport 抽取未发现阻塞性放宽；最初发现的 P2 执行元数据不一致已最小修复并独立复核关闭。真实固定宿主执行 **Not Run**，离线通过不替代准确归档的停止验收。

## 范围与验证

只读审查新 `codex_stop_probe.py`、测试、context transport 抽取及 runtime/runner 集成。没有启动 Docker、真实模型或读取认证；没有修改源码与原始证据。

- 独立执行新 Stop unittest：9 tests Passed，2.831s。
- 独立执行 context unittest：首次旧 10 tests Passed；procfs 修复后 11 tests Passed，3.417s。后者日志 `/tmp/planweft-codex-stop-independent-context-tests.log`。
- 独立执行 container runner unittest：31 tests Passed，1.380s；其中 Docker/auth 均沿用离线 mock，参数错误输出是预期反例。
- 独立注入私有 trace parser `ValueError` 和 `KeyboardInterrupt`：异常继续抛出，所属 TemporaryDirectory 均移除，未生成 `native-stop.json` 成功报告。脚本 `/tmp/review-codex-stop-adversaries.py`。
- `git diff --check` Passed。
- 根 Agent 首轮 `/tmp/planweft-codex-stop-integration-tests.log` 为 49 Passed / 1 Failed：旧测试 `exists()` 后 procfs 消失引发 ProcessLookupError。失败日志保留。新 helper 仅把 FileNotFoundError/ProcessLookupError 判为退出；休眠进程 False、PermissionError 仍抛。复核根 v2 日志为 51 Passed / 115 subtests Passed，不把测试器竞态归因于模型或产品。

## P2：实际 traced launch 与 model-invocation 元数据不一致（Closed；保留原始发现）

controller 在调用新 helper 前将 `model-invocation.json` 的 argv 设为裸 `codex --disable memories --disable multi_agent app-server`，其 transport 仍落入 `native CLI`。实际 helper 在 `run_probe` 内启动经过 `strace ... --` 前缀包装的同一 Popen；成功返回后 `model.json.argv` 使用 `process.args` 因此正确，但原 `model-invocation.json` 没有更新，异常时也无法从该入口确认真实 launch argv。

最小修复：helper 构造已验证 prefix 后、调用 probe 前更新已有 model-invocation 的 argv 为 prefix + 实际 Codex command，并准确标注 native app-server 完整单回合与可选私有 trace。保留已存在 case、scope、route 等字段；不要把 TUI 信任前失败声称为模型已启动。这不涉及产品或 assessor 放宽。

## 已核对的关键语义

- context 原 assessor 本体未改；新增函数只抽取共同协议 transport。Stop assessor 独立，不能让原 context 接受两次回答或 HookPrompt。
- `trace_prefix` 限定绝对 `/usr/bin/strace` 或 `/bin/strace`、准确 syscall/raw=read 参数；文件必须是所属 UID、0700、新建且无 symlink 的 `/tmp` 子目录。32 MiB 上限作为真实 Popen 的 RLIMIT_FSIZE 安装到 strace 及其后代，而不只是事后观察文件大小。该限制同时约束后代其他普通文件，是明确环境限制；没有模型写工具的本场景适用。
- runtime 顺序为 native TUI `/hooks` review/trust -> 新 app-server probe -> trace 归因。原 trust helper 只有 Active 观测成功才返回 Passed，否则抛出；没有合成 trust 文件或 bypass flag。模型 thread 的 dangerFullAccess/approvalPolicy=never 是隔离探针执行权限设置，不是 hook trust bypass，也不是 permission-denial 验收。
- collector 消费 turn/completed 后继续到双流 EOF、正常进程退出，随后检查全部事件。未知 raw 工具、high-level 工具、晚到工具、异线程/回合、额外请求、截断、输出限额、未完成 item/hook 均失败；不能将普通 exec JSON 缺失工具当无工具。
- enabled 模式区分 startup context 和 stop warning；disabled 模式允许宿主仍执行但无 entries 的 hooks，任何输出失败。Stop 数量、每次 native response 完成后的 hook 位置必须符合单轮时序。
- continuation 要求第一 Stop blocked、唯一 feedback，raw user XML `hook_run_id` 与 high-level HookPrompt 的 `hookRunId`/text/id 一致，二者位于 blocked 与第二响应之间；第二 native response 独立、最后 Stop completed。仅增加第二 assistant 消息或复用 response ID 不足通过。
- native projection 只有完整 EOF/exit/case 匹配才开启 tool_observation_supported/actual_followup；runner 不再从 assistant_responses >= 2 推断 Codex 续跑。计数器仍由独立脚本摘要/读取归因与前置 disabled 负控判断，后台 watcher 不替代 hook 证据。
- runtime 的 TemporaryDirectory 上下文在 parser/save 异常时也清理 trace；独立异常反例验证无成功输出。正常时输出只保留结构化归因、完整协议和经过 sanitizer 的日志。未知完整性仍 Failed。

## 固定版本依据

独立读取 `rust-v0.149.1` 官方源码：Stop 的 blocked 反馈绑定 completed hook run ID，作为 continuation fragment；HookPrompt 的 XML 属性与类型字段一致。当前官网不替代固定镜像协议。参考 [stop.rs](https://raw.githubusercontent.com/openai/codex/rust-v0.149.1/codex-rs/hooks/src/events/stop.rs)、[items.rs](https://raw.githubusercontent.com/openai/codex/rust-v0.149.1/codex-rs/protocol/src/items.rs)、[turn.rs](https://raw.githubusercontent.com/openai/codex/rust-v0.149.1/codex-rs/core/src/session/turn.rs)。这支持绑定设计；最终真实事件顺序和模型行为仍待运行验证。

本审查不声明 generic developer 消息全部是规划注入、不声明 host 全无 I/O、不声明所有 FD 并发无歧义。Startup 插件 entries 逐一关联同序 distinct raw developer 消息；其他宿主基础上下文不因此被归属为插件。counter trace 保留原有保守错误与归因范围。

## 源码绑定（审查时）

- `tests/codex_context_probe.py`: `21f8737f1af47c2c54e55a0ab39e494fdc97e758cef38ad76d43f08e72ee607e`
- `tests/codex_stop_probe.py`: `cc674a6cdf41066e7b736ad535fa897dc33c88db39494b67acacd6a659f0998a`
- `tests/test_codex_stop_probe.py`: `80214d0727c51f1409d517ab32839a7a4bc3e102ad9b4d6228f7f9d3d509a330`
- `tests/test_codex_context_probe.py`: `2d7513e33353ae6200def399c20923dd0374d464d9a6a390b478c2a836d19655`
- `tests/five_agent_runtime.py`: `f7c339b1576d36f53e592d82a96710df4e57768f90b2d44ba60f4844b9c3aaca`
- `tests/run-five-agent-release.py`: `efdd65ff34d53a01b96311d53c3a9962974f11217081ee650a37113a9b56db0e`
- `tests/test_container_release.py`: `5a4eadb75d5a6428ada3ba04da44cdb6a441fd1329e04b999b75aa7e85f39a89`

## P2 修复复核

最终 helper 已在 run_probe 前保存实际 prefix + app-server argv，保留原 metadata，准确标注完整 native stream/EOF 和可选 private strace；trust 成功之后才记录 native TUI 信任。返回 process.args 与预记录 argv 不一致即抛错，不允许来源漂移。独立重跑两个相关集成测试 Passed（0.009s）；根 launch 日志 31 tests / 16 subtests Passed。早于模型启动的信任失败仍由原 TUI 记录，不声称已有模型执行。

最终变更源码摘要（取代上文两个旧绑定；其他摘要不变）：
- `tests/five_agent_runtime.py`: `f7c339b1576d36f53e592d82a96710df4e57768f90b2d44ba60f4844b9c3aaca`
- `tests/test_container_release.py`: `5a4eadb75d5a6428ada3ba04da44cdb6a441fd1329e04b999b75aa7e85f39a89`
