# RC15 shared trace consumer contract 独立复核

结论：一行修复恢复共享返回值兼容，未发现判定放宽。当前唯一源码 diff 是 Claude `_replay` 将 `base._events` 的三元组解包为 events/errors/_unfinished。新增第三项仅为诊断；原 errors 仍完整进入两遍重放与最终 observation_complete 判定，没有把诊断忽略等同于错误忽略。

调用点搜索确认：共享函数只由 gate_process_trace 自身的 `_replay` 与 claude_hook_trace 的 `_replay` 消费，均已使用三元组。搜索中的其他 read_events/sse_events 为不同函数。未改准确 npm 包、gate 解析器、资源匹配、channel 身份或 fail-closed 分支。

原失败属于真实集成回归：旧二元解包触发 ValueError，被外层归为 invalid resource binding；历史 CI / 本地 before 失败应保留，不是资源身份实际变更。此次修复不追认任何旧失败结果，也不改变只用 gate 模块的已冻结 cap 诊断。

独立离线验证：Claude 36 项 Passed（0.124 秒），gate 30 项 Passed（0.057 秒）。额外三个合成轨迹：有效原生 fixture 完整；追加未完成 read 后即使进程退出仍 observation_complete=false，明确保留 unfinished syscalls at EOF；未知行也失败且不泄漏附带 SECRET 文本。没有运行 Docker、模型、认证或依赖安装。

额外反例结果：

```json
[
  {
    "case": "valid",
    "observation_complete": true,
    "errors": []
  },
  {
    "case": "unfinished",
    "observation_complete": false,
    "errors": [
      "unfinished syscalls at EOF"
    ]
  },
  {
    "case": "unknown-line",
    "observation_complete": false,
    "errors": [
      "unrecognized trace line"
    ]
  }
]
```

SHA-256：

- `tests/claude_hook_trace.py`: `80567a1897232e88393489336ad8ce091df050fd137ad5a8bd98c7745b1e5b81`
- `tests/gate_process_trace.py`: `2c31ce67cbd03b464f8d4f83d32adf256e7810a63dda242b2517013738004d04`
- `tests/test_claude_hook_trace.py`: `ec80f02ea5ef340cb8e56c4b71b0fa83049e6b34e37941851c785393f6856b48`
- `tests/test_gate_process_trace.py`: `52be861380de3c5fb4b435df94d7d7071aebb57b8a87ff1b967f34391bae079f`
- `/tmp/planweft-rc15-shared-trace-contract-before.log`: `ac0418c632146661736da656ec1cbd86cf190d8ec8be9ed01b2732af106e5a48`
- `/tmp/planweft-rc15-shared-trace-contract-after.log`: `2b786c279e24aae247428f4d2e895c0d87798e8c89870e96d346313fd69551b0`
