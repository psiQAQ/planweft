approved project bytes
