FROM planweft-validation/claude-trace:0.4.0-rc.3 AS trace
FROM planweft-validation/codex-base:locked-aa46e31c
COPY --from=trace /usr/bin/strace /usr/bin/strace
COPY --from=trace /lib/x86_64-linux-gnu/libunwind*.so* /lib/x86_64-linux-gnu/
COPY --from=trace /lib/x86_64-linux-gnu/liblzma.so* /lib/x86_64-linux-gnu/
