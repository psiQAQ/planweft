# Codex reminder probe independent pre-run review

Status: Passed for the bounded offline design and regressions; actual Codex/model acceptance: Not Run.

Original blocking findings and closure:
- Non-bijective hook/edit matching accepted two hooks for A0 while A1 had no hook. Closed: bijective binding plus permanent negative test.
- UserPromptSubmit was absent from the accepted fixture. Closed: complete native reset per turn, before all relevant hooks; missing/failed/late reset counterexamples.
- Compaction could mimic reset. Closed: native compaction method, contextCompaction item and preCompact hook rejection.
- Wrong handler type/mode/source/scope passed. Closed: fixed metadata checks and regression.
- A hook could change event identity between started/completed. Closed: pair identity validation and regression.
- turn/start RPC response wait consumed prior completion notification. Closed: received-event lookup; real local synthetic JSON-RPC peer emits notifications before responses and completes both turns.
- Receive-only ordering did not prove the second user request was sent after first completion. Closed: required turn_requests bound to request/thread/turn and receive-count boundary; original journal order checked by the local peer test.
- Unbounded stderr read and unclosed subprocess stdout. Closed by source inspection: 8 MiB stderr guard/bounded extraction, pipe closure, cleanup exception recording; normal local peer exits cleanly with no ResourceWarning. Overflow and forced-kill branches were not executed by this review.

Verification: PYTHONPATH=tests python3 -m unittest test_codex_reminder_probe -q — 17 tests Passed, including local non-model subprocess and invalid-host rejection before archive/output access. No Docker, native Codex execution, model, authentication read, or package modification was performed.

Remaining limits:
- Actual fixed Codex app-server event order, plugin sourcePath, fileChange ID mapping, model provider settings and trust loading require the real isolated run. Any actual mismatch must fail and be investigated; mocks are not evidence of host support.
- HookCompleted context plus later normal assistant/turn completion relies on the reviewed fixed source connection to developer conversation items; it is not a model-obedience claim or a network request capture.
- Outer scenario/container timeout remains responsible for total wall-clock/resource termination. The helper attempts graceful server shutdown then process-group TERM/KILL.
- Existing TUI trust helper is reused. This review did not repeat its native interaction acceptance.

Reviewed file SHA-256:
- tests/codex_reminder_probe.py: d8e522d4c91efb86694fa4391f189fb7d358ea6a43cbcebe5a1de67586683092
- tests/test_codex_reminder_probe.py: 31fbfe4989caa7a0f08825c58f76ec46fb38166d9d5df198f643c7efa038a7bf
- tests/five_agent_runtime.py: 1c7772f17a96a87257841003d1076f1e52fdd4c9befeac8a3525ef5b121957d7
- tests/run-five-agent-release.py: 1c32bab865e205a3150c8aedf82e5e1edb686bd100711edb00335b569c2d234c
