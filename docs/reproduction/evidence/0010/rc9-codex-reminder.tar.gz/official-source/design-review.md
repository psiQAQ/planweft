# Codex 0.149.1 原生 reminder 去重观测设计复核

结论：固定版本源码支持用 app-server 原生 hook 通知执行同一 thread 的两回合验收；不需要把 gate counter 解析器扩展成 stdout 管道追踪器。此为源码依据通过，固定镜像实际协议/模型场景尚未运行，不能写成真实验收 Passed。

## 准确来源

- 官方 tag `rust-v0.149.1` 的 annotated tag object：`980a6d12110b110d29ec13bdcbe14011100b3566`。
- commit：`ff29a44391deccde0aba0f8390337d7f3c319ea4`；commit tree：`aced181e35eb6021a45f9d51f7706577bc6ea6da`。
- 通过 GitHub 官方 Git ref API 与 commits API 交叉核对。所有源码下载 URL 使用上述 commit，不使用浮动 main。
- 本目录 `sources.json` 逐项记录 URL、完整源码 SHA-256、字节数；未安装或执行源码。官方协议文件已拆为 `codex-rs/app-server-protocol/src/protocol/v2/` 目录，旧 `v2.rs` 返回 404 属路径变化。

## 可直接使用的 schema

完整 JSON 位于 `codex-rs/app-server-protocol/schema/json/`，包括 v1/InitializeParams 和 v2/HookCompletedNotification、ThreadStartParams/Response、TurnStartParams/Response。

- `initialize` 的 params 必需 `clientInfo`，可选 `capabilities`；初始化应保留既有 client 流程，不 opt out hook 通知。
- `thread/start` 请求可给 `cwd`、`model`、`modelProvider`、`ephemeral`、`approvalPolicy`、`sandbox`、`config`；schema 没有必需字段。仅创建一个合成 thread，沿用隔离模型配置与信任流程。
- `turn/start` 必需 `threadId`、`input`；文本 input 使用 `{"type":"text","text":"..."}`，`text_elements` 默认空。
- 一次 turn/completed 成功后才对同一 threadId 发第二次 turn/start。不能 thread/resume、thread/start、compact 或重启进程替代回合边界。
- 通知方法在 `src/protocol/common.rs:1833-1835` 注册为 `hook/started`、`hook/completed`，没有 experimental 标记。
- 通知 params：`threadId`、`turnId`（schema 可空；此验收要求非空）、`run`。
- run 字段：`id,eventName,handlerType,executionMode,scope,sourcePath,source,displayOrder,status,statusMessage,startedAt,completedAt,durationMs,entries`。
- 本场景要求 `eventName="postToolUse"`，`handlerType="command"`，`executionMode="sync"`，`scope="turn"`，`source="plugin"`，完成时 `status="completed"`；entries 元素字段为 `kind,text`，上下文 kind 是 `context`。
- `eventName` 其他边界值为 `userPromptSubmit`、`sessionStart`。不是内部 core 的 snake_case，也不是 hook JSON 的 PascalCase。

`v2/hook.rs:91-143` 对 core summary 作字段保持转换；`app-server/src/bespoke_event_handling.rs:1060-1079` 直接发出通知，没有省略 entries。

## entries 与模型上下文的连接

这里的 `context` 并非仅代表 UI 消息：

1. `hooks/src/events/post_tool_use.rs:189-210` 只在成功输出解析后，将有效 additionalContext 交给 `common::append_additional_context`。systemMessage 单独记为 warning，不可计入。
2. `hooks/src/events/common.rs:36-50` 在同一函数中同时追加 `HookOutputEntry{kind:Context,text}` 和 `additional_contexts_for_model`。
3. `post_tool_use.rs:113-122` 汇总模型上下文并经过有界 spill；短固定 reminder 不应触发 spill，但长输出不能假定模型得到全部原文。
4. `core/src/tools/registry.rs:695-723` 在成功工具执行后调用 hook，并将 outcome.additional_contexts 传给 `record_additional_contexts`。
5. `core/src/hook_runtime.rs:682-708` 将其写入 conversation items；`core/src/context/hook_additional_context.rs` 明确该 fragment 的角色为 developer。

限制：`core/src/hook_runtime.rs:300-301` 先发 HookCompleted，再由 registry 写入 conversation。因此孤立的 completed 不是模型已收到的网络确认。验收必须同时看到同一回合后续成功的模型继续处理和正常 turn completion，不能在 hook completed 后立即终止进程并宣称送达。若要求逐字证明实际上游请求消费，还需另加经过明确脱敏的请求/本次合成 history 投影；当前源码链与正常模型续行足够支持“原生宿主接受并记录到模型上下文”，不证明模型一定遵从提醒。

## 绑定与断言

- `sourcePath` 是 hook 配置来源，不是运行脚本路径。必须核验准确安装包的 manifest、脚本摘要，并匹配实际安装来源；不能只搜路径包含 planweft。
- `hooks/src/events/common.rs:97-107` 将 tool_use_id 追加到 run.id。start/completed 配对键用 `(threadId,turnId,run.id)`。UserPromptSubmit 的 run.id 可跨回合复用，不能以全局 run.id 去重。
- 每回合至少两个成功且串行的匹配原生编辑；当前 Codex matcher 包含 apply_patch/Edit/Write，Bash 修改不算。每个匹配 hook 必须有完整 start/completed 对，且每个工具只出现一个自有 dispatcher。
- 按每回合原生通知顺序：首个 PostToolUse 有一条严格等于 NUDGE 的 context；后续所有自有 PostToolUse 都没有 context。不能只统计整个回合总数，否则首个漏发、次个才发也能误过。
- 第二回合在同一 thread 观察到 UserPromptSubmit，首个 PostToolUse 再有一条 context；两回合之间无 SessionStart/compact。允许工具顺序对应的附加文档编辑，但必须把它们的 hook 纳入全量检查。
- 保存原生通知/工具 items 的行号或序号、原始附件摘要、包摘要、镜像/CLI/模型/执行器来源；任何未配对、失败、未知来源、回合歧义、截断均拒绝。
- 不读取 marker 来证明提醒；不得把 started 的空 entries、模型复述、warning、或多个 UI 输出副本计入。

## 离线负对照与实际边界

至少覆盖：首个漏发/第二个补发；重复 context；缺 started/completed；同一个完成事件重复投递；第二回合新 thread；插入 SessionStart；仅 Bash；匹配工具成功但 hook 未执行；来源变更；status=failed；warning 包含同文字；一回合与另一回合复用 run.id；hook 后模型失败/断流；额外编辑产生提醒；通知乱序歧义。

只读审查已完成，未修改仓库源码、未启动容器或模型。运行时支持必须由固定镜像实测确认；本记录不关闭 stable 准确归档的任何真实模型门槛。
