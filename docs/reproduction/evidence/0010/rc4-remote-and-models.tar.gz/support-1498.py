from pathlib import Path
import json,subprocess
root=Path('/workspace/planweft')
locks=json.loads((root/'tests/container-images.json').read_text())
base=Path('/var/tmp/planweft-040/rc4-registry-containers');base.mkdir()
results={}
for host in ['codex','claude','pi','opencode','dsh']:
 output=base/host;output.mkdir()
 command=['docker','run','--rm','--label','planweft.run=registry-rc4-'+host,'--read-only','--user','1000:1000','--cap-drop=ALL','--security-opt=no-new-privileges','--cpus=2','--memory=4g','--network=host','--tmpfs','/tmp:mode=1777','--tmpfs','/workspace:uid=1000,gid=1000,mode=700','--mount','type=bind,src='+str(root)+',dst=/source,readonly','--mount','type=bind,src='+str(output)+',dst=/results','--workdir','/workspace','--entrypoint','python3',locks['hosts'][host]['image'],'/source/tests/run-registry-smoke.py','--host',host,'--version','0.4.0-rc.4','--sha256','c6f54319befc8c43c559fd4c5af2eb6ca3d1b626e6c0b3fd65cb67c11d9d318b','--previous-version','0.4.0-rc.3','--previous-sha256','09ea0e4dceb88c9b845af851916356c44f3447071e0d1311dc38841639705060','--output','/results/run']
 with (output/'container.stdout').open('w') as stdout,(output/'container.stderr').open('w') as stderr:
  p=subprocess.run(command,stdout=stdout,stderr=stderr,timeout=1800)
 results[host]={'image':locks['hosts'][host]['image'],'exit_code':p.returncode}
 (base/'summary.json').write_text(json.dumps(results,indent=2)+'\n')
 print(host,p.returncode,flush=True)
