# RC13 后维护失败的最小修复分析

结论：不能用同一段加强提示处理四个平台。已有 Skill 已明确禁止误用旧计划例外、宿主配置查找和项目外手工 scratch；Claude 完整读到仍违反，Pi 在读取前已越界。优先修复可证明的资源解析、临时目录可观测性和判定缺陷；其余属于需要固定任务/模型验证的遵循干预，不能声称已有确定修复。此次只读使用既有独立报告、源码与固定任务，未运行模型、Docker、认证读取或修改包/测试。

## 事实分类

| 项目 | 已确认事实 | 归类及保留结论 |
| --- | --- | --- |
| Claude RC11 | 自动 Skill 实际读到完整正文和 plan-selection，仍把“沿用资料”误当旧计划必须保持权威；未初始化。还明确写三个固定 /tmp 文件。 | Skill 决策执行失败及实际范围违规；不是发现失败、正文截断或自动断言误报。既有文字已覆盖，重复前置不能作为根因修复。 |
| Pi RC11 | 在读主 Skill 前读取 .pi/settings.json，后来却声称未读宿主配置；计划采用与最终三文件基本正确。 | 前置资源发现/行为范围失败。报告不能证明宿主遗漏了准确 Skill location；须先核对真正送给模型的 discovery 元数据，不能先认定 installer 或 Pi 有定位 bug。 |
| DSH RC11 | 计划、回归、交接通过；手工 TemporaryDirectory 无 dir，输出没有实际路径；反事实源码 scratch 在计划内。 | 手工导出临时目录的范围证据不足，不等于已证明某个 /tmp 随机路径外写。 |
| OpenCode RC12 | 自动 Skill 已读取、正常初始化；一次相对链接资源地址拼错后用 readlink -f 恢复。旧 notes 仍自己写当前状态/下一步；findings 的旧测试观察仍用现在时；progress 错写“无错误”。 | 错误资源解析及实际收尾记录失败；不是插件未加载。现存 relative symlink 不能单凭模型拼错就判 installer 缺陷。 |
| OpenCode 历史断言 | 日期、Linux、手工示例、Passed、历史限定及非本次验证均保留，只改了标点和“更早”措辞。 | 精确子串断言误报已确证，只能单独修正这一项；其余维护门槛仍 Failed。 |
| 冷读 | 四份独立报告均认可主要文件隔离和当前/历史结果恢复，分别保留辅助措辞/错误遗漏限制。 | 不将冷读通过用来冲抵 owner 初始化、范围或收尾失败；无需为这些 owner 缺口改冷读预期答案。 |

## 最小可检验干预

1. **先核对资源 location，再决定是否修包。** Pi 只收集宿主原生列出的 project-docs 绝对 location/sourceInfo 和实际首次读取顺序；不读取 settings/receipt 来补模型资源路径。若 location 正确完整而模型仍先读 settings，这是遵循失败，不能归咎于安装器。OpenCode 沿已知 Skill 路径解析符号链接，只用解析后的真实 Skill 所在目录定位 references/scripts；不要手工拼 readlink 的相对 target，也不要换成全局查找或默认复制安装掩盖问题。可在现有资源说明用一条可执行的 canonical-path 示例替代抽象占位符，并用中文/空格路径及多层相对链接离线复现。该例程只解释包路径，不扩大项目访问范围。

2. **为手工 scratch 提供可执行、默认安全的操作例程。** 当前只有禁止句，缺少就地使用方法：Python 示例使用 `TemporaryDirectory(dir=<已确认的项目目录>)`，Shell 使用项目内 `mktemp -d <project>/.pw-scratch.XXXXXX`，只清理返回的自有路径；分配结果可记录非敏感相对路径和真实解析后的项目归属。这替换抽象 scratch 指令，不再追加另一段禁止文案。对新增手工复现/反事实命令验证实际路径；固定 `/tmp/...` 仍必须失败。

   固定 fixture 的既有 unittest 已使用默认 TemporaryDirectory；它不是“已证明手工临时路径受限”的正控。测试框架临时文件、模型主动创建的手工 scratch、controller 的独立反事实副本应分别归因。若调整环境，仅为明确的测试子进程设置项目内 TMPDIR 并记录该事实，不全局修改 agent CLI 的 TMPDIR：全局改动可能把宿主私有临时数据引入项目。不能以受测命令默认行为猜测旧记录的随机目录，也不能回写旧证据。

3. **Claude 的例外决定改为可观察的分支动作，而非更多强调。** 候选干预是把分散的“授权/例外/准备”文字合并为一个短决策步骤：先区分只读/简单任务；其余列出实际适用的禁止采用证据（原句+来源，或明确没有），再依据 resolver 与真实文件选择继续/修正绑定/初始化。这个短结论放在现有回复或选中计划已有 Goal，不创建额外管理文件；只有具体禁止原句才能走保留旧权威分支。禁止新增文件、显式旧计划权威和只读例外保持不变。

   这是针对可见误判的**待验证交互设计假设**，不是确定模型根因，更不能新增 hook 自动初始化或把模型 attestation 当批准。现有 prose 已经语义正确；若单一决策结构改变后仍失败，应保留失败并继续定位，而不是无变化重跑或显式调用 Skill 挑成功。

4. **OpenCode 收尾按实际字段检查，先使用既有 owner-review 闭环。** 独立 reviewer 给 owner 三个具体差异：旧 notes 的当前状态/下一步应只指向 task_plan；旧测试观察须标明修复前并链接实际修复；错误路径及恢复不能写成“无错误”。owner 实际读回这三个位置后修正，再给无旧聊天的新读者。现有 entrypoint 已要求这一步，不必为该已有反馈流程先改产品。若后续要改 Skill，应将抽象“核对记录”替换成有限的操作顺序和证据，而非增添第二份进度台账或泛化检查清单。owner 后续修订不能撤回已经发生的范围违规，也不把首次自动通过写回原 run。

5. **历史断言只消除已证实误报。** 最小证据路径是保留原自动 Failed，附绑定该最终 notes 字节的独立语义裁定，明确保留的六个事实限定；不能用“出现日期/Passed关键词”作为新充分判据。若实现自动规范化，应仅涵盖有离线正负反例证明不改变语义的标点/空白变化，缺失“非本次”或篡改日期/平台仍拒绝。本例含措辞变化，不能仅靠标点归一化就宣布完全解决。单项裁定不消除其他失败。

## 验证顺序与依据限制

- 先用离线对照证明资源 canonicalization、临时目录实际归属与历史判据的正负例；不修改固定维护 prompt、approved contract、用户文件或模型配置。
- 行为干预每次绑定具体源码/执行器差异，预先确定观察点：自动 Skill 读入在资源查找之前、例外决定所引原句、初始化在实现前、手工临时目录归属、最后实际读回的三类记录。固定任务与模型串行复验；显式 Skill 调用仅诊断，不替代自动匹配。
- 重要决策结构修改需独立依据 review：现有 PWF 三文件/选计划协议和项目明确授权规则是约束来源；“结构化分支会改善该模型”只是可检验假设，不援引高 star 或未查资料作为效果证明。
- 这些方案没有将任何旧 RC 变成 Passed，也不代替最终准确 stable tarball 的完整验收。

## 来源绑定

- `/tmp/planweft-claude-rc11-independent-review.json` SHA-256 `6c5332fe82bcddfabc43a906663e1a29649084d49435812dd0ed075898cd36d9`
- `/tmp/planweft-pi-rc11-independent-review.json` SHA-256 `eb3fc0434aafb9d014f3ddb61e21563a3911345eadc752e776384cd88b0a0b4f`
- `/tmp/planweft-dsh-rc11-independent-review.json` SHA-256 `a048ea9a4dbe8234797517f921d0fd030537bbd2e39c76fbf8075f46dc16b4ec`
- `/tmp/planweft-opencode-rc12-independent-review.json` SHA-256 `a9c0b9cfd113b25e09a9bce4b7591f489ab432b5b5d8d02bfd4138000b5410f1`
- `overlays/planweft/entrypoints/en.md` SHA-256 `7143f66c0cc5bcd5fcec12025a547efc850d2cc4f6230e672bb2a8ec55c202be`
- `overlays/planweft/workflow.md` SHA-256 `2935b0403a38d3cda0e1ce3d6d2b09d865d192569934091fcfc93f0db94f6f23`
- `tests/run-pwf-smoke.py` SHA-256 `34185c82cb4b6056f6fb8597cc4a44a513535af298738a3a8be5e9be7ee470d7`
