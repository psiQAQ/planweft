# RC13 Codex context probe 独立审查

结论：当前版本尚不可用于新的真实持久信任验收。原有 7 项离线测试 Passed，但存在正常 hook 协议误拒，以及两个已复现的脱敏/清理缺口。此次仅源码、既有合成 raw 和离线假进程；没有 Codex、模型、Docker、网络或认证读取。所有临时反例进程按记录 PID 清理。未修改实现或永久测试。

## 必须关闭的发现

1. **P1 / 正常双 context 误拒。** assess 只允许 SessionStart 带 context，要求唯一 token context 和唯一 developer 投递。实际固定 Codex 0.149.1 的 RC13 原始协议显示：SessionStart completed index15、UserPromptSubmit completed18 均输出同一个 909 字节 context；分别通过 developer raw item index16、22 送达，item ID 不同。两个文本 SHA 都是 `796693eebdc7f97ba6255f1f8078f0a9b77d50f27c6fc91c5eacc8d9beac3dcf`。因此本假 fixture 只模拟 startup 一次，不覆盖真实正常协议。

   最小修复：保留准确 source/run/thread/turn 绑定，允许 SessionStart 与 UserPromptSubmit 的每次实际 context，并按原生时序逐次绑定不同的 developer raw item；相同文本不能集合去重，一个 developer item 不能满足两个 hook。缺失第二次投递、错误来源、额外 token 来源、乱序歧义仍拒绝。不要靠禁用 UserPromptSubmit 改变待测产品。

2. **P2 / Stop advisory warning 误拒。** 目前所有 hook entries 只允许 context，且非 startup 要求为空。准确包 stop.py 将 stop.sh 的 followup_message 写为 systemMessage；固定 RC13 raw Stop completed94/175 实际对应 warning。待测 in_progress 计划按同一源码会发 Task in progress advisory，而不是空结果。仅给已绑定同源 Stop 允许原生 warning，并将它记录为 UI/停止观察；不计上下文送达，不放宽 error/control/未知条目，也不允许以 Stop 晚投递 token 冒充启动恢复。

3. **P1 / stderr 超限会泄露被截断的敏感前缀。** 使用现有 fake：`run_fake('normal', limits={'stderr':11})`。完整原文为合成 `header: SECRET\n`，sanitizer 替换完整 SECRET；采集最终 Failed 且私有目录已删除，但导出 stderr 为 `header: SEC`。原因是先按字节保存截断 raw prefix，再把整个残片交给仅匹配完整凭据的 redactor。断言“不含完整 SECRET”漏掉此问题。

   最小修复：超限、失败或中断产生的未完成 stderr 行先省略，只脱敏完整记录；导出可使用固定省略标志。补完整敏感串横跨上限与无换行中断反例，断言敏感前缀也不输出。stdout 只有完整 JSONL 才记录，不能据此假设 stderr 同样安全。

4. **P2 / 自然成功后的所属后台进程残留。** 用 fake 在正常 stdin EOF 后启动继承所属 group、三个 stdio 都指向 DEVNULL 的 sleep 子进程，再使 leader exit0。探针返回 Passed，但子进程仍存活。反例子进程已经清理。代码仅在 failure 或 leader 尚未退出时 killpg；EOF 只证明输出管道关闭，不能证明整个 group 结束。

   最小修复：无论 leader 已退出与否，结束新建且记录的所属 process group；协议仍保留真实 leader exit0 和正常 EOF，不把后续清理信号当模型异常。补成功后无管道子进程反例，保留其他 group 存活反例。

5. **P2 / 中断报告遗漏（源码确认）。** except 仅捕获 Exception。KeyboardInterrupt 经 finally 清理后会直接外抛，跳过最终 observation.json 写入。不会误报 Passed，但缺少明确失败/中断证据。建议显式捕获并记录中断类型，仍执行所属进程清理与安全导出；不输出可含敏感数据的异常正文。

## 已确认的正确边界

- 相比旧 ephemeral exec 高层 JSON，启用 experimentalRawEvents 并拒绝除 message/reasoning 外的 raw item，覆盖隐藏 code-mode custom_tool_call/output、function_call、shell/search 等；高层仅允许 user/agent/reasoning，未知 notification 也拒绝。源码 `bespoke_event_handling.rs` 将 core RawResponseItem 与 RawResponseCompleted 转发为带 thread/turn 的原生 notification，符合选用此证据的依据。
- request 响应在 collector 按三个 ID 严格配对，所有中途通知同时保留 events；assess 不应脱离这些 collector 前置约束单独当完整协议验证器使用。
- thread/start 有 ephemeral、新 sessionId、无父线程/历史 turns、固定 CLI/cwd/effective settings 核验；turn 内 raw/user/final/high-level item 配对并检查 token 未进入发送 prompt。关闭 stdin 后继续消费至 stdout/stderr EOF，检查正常 exit0，拒绝晚到工具和截断，修复旧“看到完成就不再收集”的盲点。
- 未使用模型复述或后台 counter 读取作投递证据。符合目标的证据是同源 hook context、后续 raw developer message、同 turn 对应 raw assistant final 和 response/turn 正常完成。
- 安装 resources 与准确包目录逐文件/执行位核对；公开日志经 sanitizer，私有 stderr 只由 collector 写且有字节上限。但这不消除上述残片脱敏问题。

## 离线验证

`python3 -m unittest discover -s tests -p 'test_codex_context_probe.py' -v`：7 tests Passed，3.276 秒。随后独立新增的两个临时 fake 反例分别复现敏感前缀导出与正常退出后的后台残留；未写入仓库测试文件。真实双 context 和 Stop warning 来自已保存 RC13 raw，未运行新模型。

## 首次审查绑定

- `tests/codex_context_probe.py` SHA-256 `02e66fe6c35106252f1f2319ca220f4fd2d861952221fd4133ee4c58ed24fb4a`
- `tests/test_codex_context_probe.py` SHA-256 `4272ef87e2e9c68a9fe7c82f192212141dde43b9a8f9dd085ba925d623a92dcc`
- `/var/tmp/planweft-040/rc13-codex-native-boundaries/codex/reminder-dedup/raw/reminder-protocol.jsonl` SHA-256 `90a874afd5698383d3b7e3b954684787596601215a9471c9559c679d819b8f14`
- `/tmp/planweft-codex149-source/codex-rs/app-server/src/bespoke_event_handling.rs` SHA-256 `42e46071529deee6a38789319f641ed46d39f7aab260b0c973f74341f6d74f31`

## 五项修复的独立关闭复核

最终复核结论：上述五项在此次两文件有界范围内均 Closed，未发现新的阻塞；这不是新真实 Codex 或准确包验收 Passed。原始发现与旧摘要保留，以下绑定修复后版本。

- 双 context：按事件顺序处理每个 SessionStart/UserPromptSubmit context，要求在该完成与下一 context 完成（末项在 raw final）之间有唯一、精确同文的 developer message；developer item ID 不可复用，相同内容保留两次独立注入。额外 token 消息继续拒绝。独立运行新增正控及缺第二项、复用 ID、额外 token、乱序反例全部通过。初始 SessionStart 恰一组；此探针不把“所有配置 hook 都应触发”作为无工具恢复的额外要求。
- Stop warning：仅 source/run/thread/turn 绑定的 Stop 接受 warning，分离到 stop_warnings，不加入 injections；token、context/error/control 和外来源反例拒绝。符合已观察到的 0.149.1 advisory 输出。
- stderr：未完成尾行先被省略，再导出完整记录并脱敏，同时 Failed。重做原 `stderr=11` 反例：导出 stderr 为空，记录 omitted_bytes=11，没有敏感前缀。不是仅检查完整 SECRET 消失。
- 成功后台清理：现在正常与失败都终止明确新建的所属 group，保留真实 leader exit0/正常EOF结果。除永久 DEVNULL 子进程测试外，独立再次把子进程放在 fake **收到 stdin EOF 之后**才启动；最终报告仍为正常成功，所属后台进程已不存在或已为不可运行 zombie，其他进程不受影响。反例临时文件/进程已清理。
- KeyboardInterrupt：主采集显式捕获并用固定中断文字形成 Failed observation，cleanup 和导出也受控；新增中断带合成敏感异常正文的测试证明报告保留且异常正文未泄露。

实际验证：`python3 -m unittest discover -s tests -p 'test_codex_context_probe.py' -v`，10 tests Passed，3.390 秒；另独立重做 stderr 截断和成功 EOF 后 DEVNULL 子进程两项原反例，均不再复现。未运行真实 Codex/模型、Docker、网络或认证读取。

仍保留原审查限制：assess 依赖 collector 已核验请求响应/新线程；完整原生日志仍需在下一真实运行证明与固定宿主兼容。该模块不读取历史、不改变信任、无信任绕过；三次 before/UI/after/fresh 的控制器顺序与包/项目状态绑定属于后续集成审查。

修复后源码：

- `tests/codex_context_probe.py` SHA-256 `192cc8b5b3cbb93a8a90ceb67da7caafdc5ee1465c6f48d07424c93e96988327`
- `tests/test_codex_context_probe.py` SHA-256 `872397c375dc4cefca5f5d50c66332be839fcc509256d99e3b2ab6780552c5bd`

## 三次独立会话的集成复核

补查 runtime、runner 和 container tests 的 Codex 变更，未重审 Claude 历史部分。独立运行 24 项 container unit Passed（1.259 秒）；另用明确 mock 检查 after/fresh 分别失败的序列中止、证据保留与 owner token 更新时点，均符合预期。无模型、Docker、网络或认证读取。

联合语义：

- 同一总 deadline 内严格 before -> 原生 UI -> after -> owner 替换 token -> fresh；每次 run_probe 新建 app-server、使用独立 raw 子目录，并完成 EOF/清理后才返回。before 禁止原 token且要求 NO_CONTEXT；after 要求原 token；fresh 要求新 token并禁止旧 token。token只用于本地判定，不注入模型 prompt。
- 每次 probe 必须 rc0 且 observed.status=Passed，否则立即停止并保留递增 native-trust-sessions.json；before 失败不会触发 UI，after 失败不会替换 token，fresh 失败保留失败事件与已换 token 的真实项目状态。不会回写历史成功。
- native_persisted_trust 联合三个准确答案、三次 no_model_tool_calls、三个不同 thread ID和三个不同 native PID；重复 thread 或 PID使专用 assertion失败。UI helper只有到 verified-active才返回，否则抛错；没有直接编辑信任文件或 bypass flag。PID不同是附加检查，单独不能替代 fresh-thread 元数据；主证据仍来自各probe。
- runner冻结 context模块并写SHA，只读挂到 /runner；解释器从该目录导入。新增 native_pid 是实际 Popen PID，非外部声明。最终项目快照仅允许原计划token替换，其他项目文件保持一致。
- 通用 Codex exec解析不再宣称可完整观察工具；即使context_probe_projection也不把通用 tool_observation_supported 改成True，专用已核对raw断言承担持久信任。旧 context/recovery/stop中依赖no_tools的断言现在fail-closed，需要各自原生工具证据；不可把新探针通过泛化给旧场景。simple/untrusted当前有限断言也不能被描述成完整无工具证明。

P2 / 集成失败路径 invocation 元数据待关闭：controller预先仍用旧普通 exec 命令写 model-invocation.json；只有三次probe全部完成，codex_trusted_model末尾才用真实 app-server args覆盖。任何中间失败时，保留的通用 invocation会与实际raw探针冲突。已建议主Agent在分支前改为实际app-server command或按每次调用记录实际argv。本项不构成误放行，但应在新真实失败记录产生前修复。

集成首次绑定：

- `tests/codex_context_probe.py` SHA-256 `695b3246d2106bb679d06ec82f94dbe350786c07d254607a870de9e2a7558520`
- `tests/test_codex_context_probe.py` SHA-256 `872397c375dc4cefca5f5d50c66332be839fcc509256d99e3b2ab6780552c5bd`
- `tests/five_agent_runtime.py` SHA-256 `83876a6c37c93cf93e9ef4f88e22c5ee3f883c85d0b001a8f2445513a20c574c`
- `tests/run-five-agent-release.py` SHA-256 `7e659a72f5db219647e8f88e69387fdb834af5b57ff882b0cb1b48143d3f48a1`
- `tests/test_container_release.py` SHA-256 `79e184801d1a90a528abe09a63829f73be6728d8df416ebfd5888845c08ccb3a`

### 集成 P2 最终关闭

已重新读取当前源码确认 Closed：在任何 persisted-trust 探针调用之前，controller 就把 command 设为实际 `codex --disable memories --disable multi_agent app-server`；预写 transport 明确三个新原生探针、各自 journal、失败即停止。因而 before/after/fresh 任一阶段失败也不再遗留旧 exec invocation 声明；成功末尾的实际 args 覆盖保持一致。此前报告的待关闭项已过时，以本次复核为准，首次问题记录仍保留。24 项离线测试结果如前；当前进一步修改仅是已核对的元数据和 native_pid 字段，不重跑无关测试。

最终结论：本次有界 Codex probe及三会话集成没有遗留阻塞发现；真实准确包会话仍待执行，传统高层 exec 的工具缺席仍不能作为无工具证据。

最终五文件 SHA-256：

- `tests/codex_context_probe.py`: `695b3246d2106bb679d06ec82f94dbe350786c07d254607a870de9e2a7558520`
- `tests/test_codex_context_probe.py`: `872397c375dc4cefca5f5d50c66332be839fcc509256d99e3b2ab6780552c5bd`
- `tests/five_agent_runtime.py`: `83876a6c37c93cf93e9ef4f88e22c5ee3f883c85d0b001a8f2445513a20c574c`
- `tests/run-five-agent-release.py`: `7e659a72f5db219647e8f88e69387fdb834af5b57ff882b0cb1b48143d3f48a1`
- `tests/test_container_release.py`: `79e184801d1a90a528abe09a63829f73be6728d8df416ebfd5888845c08ccb3a`
