# Claude RC13 collector v2 independent review

Status: **Failed — one reproduced P1 and one P2 evidence-contract gap remain.**

Scope: source review and isolated Python fake-CLI tests only. No Claude/model, Docker, credentials, personal sessions, or source changes. The existing failed real run remains unchanged. This report does not assess reminder delivery as Passed.

## Source and original evidence bindings

| File | SHA-256 |
| --- | --- |
| `tests/claude_reminder_probe.py` | `4782789b935c6bd258a96c7d0c5ecb3a78e2068b41c91f612b4d593a0308cc47` |
| `tests/test_claude_reminder_probe.py` | `7d49c468e8dce3ba6da9901a35896e10e1cb8982432d24003a5123bbe6ec4469` |
| First real run `raw/claude-reminder-observation.json` | `0d2d0b46c032f14030fa26376678c84d3859bc5dcceb476e014c360566f6edb5` |
| First real run `raw/claude-reminder-native.stdout.jsonl` | `31eb9183ba16af994c086c505d21549e77edb9c76887dddd923635f3f13c1851` |
| First real run `raw/claude-reminder-hooks.log` | `6572d048fec0f9d5834a1c99c98ba8e4f4656ba01b6917a53eab9d186a46aa33` |
| First real run `raw/claude-reminder-sent.jsonl` | `0624bfcaee9b5b9010ced55147aed61da66ba65252507ad2dda7f8ae19c85f13` |

Real-run root: `/var/tmp/planweft-040/rc13-claude-reminder-collection/claude/reminder-collection`.

## Findings

### P1 — safe deletion does not protect the preceding debug read/export

`debug_size()` (line 299) follows the debug file with `stat()`. Final export (lines 405–406) likewise uses `stat()` and `debug_path.open('rb')`. The new `clean_private_tree()` identity/nofollow checks execute only after that export. A symlink at `native-debug.log` can therefore make the collector read and export a file outside its private directory, while successful non-following deletion of the link makes cleanup look correct.

Reproduced with the existing fake CLI copied into a new `TemporaryDirectory`: create a sibling `foreign.log` containing only `FOREIGN_SYNTHETIC_PRIVATE_CONTENT\n`; after two otherwise normal fake user turns, replace `native-debug.log` with a symlink to that sibling. No real private data was used. Actual result:

```json
{"exit":0,"collection":"Passed","foreign_content_exported":true,"private_removed":true}
```

The external target was not deleted, but its contents were exported to `claude-reminder-hooks.log`. This falsifies the intended scope of safe native-debug collection.

Minimum repair: before **both** size observation and export, validate the originally created root identity and open the debug source using directory descriptors and `O_NOFOLLOW`; verify the regular file and its original identity with `fstat`. A changed root, symlink, or exchanged source must fail without reading the target. If the real CLI legitimately replaces its log file, that requires an explicit evidenced replacement contract rather than unrestricted path following. Retain the safe tree cleanup independently. Add exact file-symlink and root-exchange export counterexamples, checking absence of the external sentinel in all outputs as well as target preservation.

### P2 — equal init metadata can be equally incomplete or use the wrong initial model

`Protocol.accept()` lines 112–115 compares init dictionaries excluding `uuid`, but does not validate required initial fields or bind the first metadata to the invocation's requested model/cwd/version/permission mode. The normal offline fixture itself emits only `type`, `subtype`, `session_id`, and `model='fixed'`, while `run_probe` requests `synthetic-model`; it reports collection Passed. Thus “both metadata dictionaries are equal” currently proves stability, not that the required initialization evidence was supplied or the selected model was used.

Minimum repair: require the pinned native init's essential fields and types, then compare the two complete metadata objects excluding only event UUID. Bind first `cwd` and `session_id` to the current project/session, `model` to the requested model, and fixed CLI version/permission mode to the launched command. Missing required metadata should be an explicit observation gap; stable contradictory metadata should fail. Extend the fake baseline with realistic fields and add missing-field and initially wrong-model counterexamples. No authentication contents need to be read for this check.

## Confirmed closures and boundaries

- Real stdout lines 5 and 197 contain init dictionaries differing **only** in UUID. Lines 3/4 bind A queued/started to the sent A UUID; 120/121 and 188/189 bind the two successful Writes; 193 is A success. B was sent after stdout sequence 193. Line 194 completes A by A UUID, 195/196 queue/start B by B UUID, then line 197 initializes B. The revised per-request rule correctly addresses the actual first failure without relabeling init as a SessionStart reset.
- The v2 command-state mapping binds late A completion to A even after B is sent. B cannot start before A's native completion. Repeated/reordered command states and missing final completion prevent collection success.
- The revised init checks reject a second init within an active turn, init after that turn's tool activity, and changed metadata between turns. The remaining issue is the first metadata's adequacy, as described above.
- `clean_private_tree()` uses a parent descriptor, non-following root identity check, and symlink-attack-resistant `rmtree`. Tests cover extra nested files, internal links preserving their external target, replacement root, and cleanup permission error. These protect deletion, with the separate export finding above.
- Stderr and debug incomplete tails are now omitted rather than exporting a credential prefix, and the scenario remains Failed. Successful collection continues to mean only `collection_status=Passed`; `status` and reminder deduplication remain Not Run.
- The old real cleanup record states only `OSError`, not errno or a private-tree inventory. Extra CLI child files are a reasonable motivation for robust tree cleanup but were not proven to be the original error's cause.
- Real debug lines 202–205 show matching PostToolUse hooks and a plain-text parse notice for the second Write. They still do not uniquely bind each handler's empty output and model delivery. This review does not promote that diagnostic into a deduplication pass.

## Verification

`python3 -m unittest discover -s tests -p test_claude_reminder_probe.py -v`: **11 tests Passed, 7.043 seconds**.

Additional independent fake-CLI file-symlink export counterexample: **reproduced P1** as above. All its processes and temporary files were removed by the local test context. No product source or original evidence was changed.

## Follow-up: original P1/P2 closed after root fixes

Current scoped source-review status: **Passed for the two findings above**. The initial findings and their actual failing reproductions remain recorded; this follow-up supersedes their open status, not the original real-run Failed result. Real Claude retry and reminder-delivery acceptance remain **Not Run** in this review.

| Revised source | SHA-256 |
| --- | --- |
| `tests/claude_reminder_probe.py` | `5ca9da57d2c8b2d9f99be9c4fd89e9d15567a47e217e88b9eeb4183e6aa8c75b` |
| `tests/test_claude_reminder_probe.py` | `1812b290a43b21ca58d56adfe88c9b323de93739e31b8c8ed479817b806fd8b7` |

**P1 closed:** the collector holds its created directory/file descriptors. Before measuring or exporting, it checks root identity, the non-followed named entry, and the held regular-file identity. Export duplicates the held descriptor rather than opening a mutable source path. I reran the exact earlier fake-CLI attack after normal two-turn completion, replacing `native-debug.log` with a sibling-file symlink. Current actual result:

```json
{"exit":1,"collection":"Failed","foreign_exported":false,"target_unchanged":true,"private_removed":true,"error":"OSError: Private debug file identity changed","debug_error":"OSError: Private debug file identity changed"}
```

The appended output contains no foreign sentinel; the external file remains unchanged. Source file replacement is also covered by the new checked-in test. The safe recursive deletion still removes only the verified owned private root, independently of the decision to reject debug export.

**P2 closed:** first init now requires typed cwd/model/permission/version/tools/MCP/plugins/skills fields and validates them against invocation context and the packaged plugin version. Full metadata equality excluding UUID remains enforced across A/B. I reran the exact former minimal fake init and a stable but wrong initial model:

```json
{"case":"old-minimal-init","exit":1,"collection":"Not Run","private_removed":true,"error":"ObservationGap: Native initialization metadata is incomplete"}
{"case":"wrong-initial-model","exit":1,"collection":"Failed","private_removed":true,"error":"ValueError: Native initial model, scope or capabilities differ"}
```

Independent rerun: `python3 -m unittest discover -s tests -p test_claude_reminder_probe.py -v` — **12 tests Passed, 7.718 seconds**, including source-link/replaced-inode tests, missing metadata, wrong initial model/version/permission, command lifecycle ordering, redaction and cleanup failures. The extra three counterexample runs above used only temporary fake processes and synthetic files; their temporary resources were removed.

This closure validates the local collector repairs. It does not prove that the real pinned CLI retains its original debug file inode, nor that the still-unknown PostToolUse empty-output semantics establish reminder deduplication. Those remain obligations for the subsequent accurately bound native collection and independent interpretation.
