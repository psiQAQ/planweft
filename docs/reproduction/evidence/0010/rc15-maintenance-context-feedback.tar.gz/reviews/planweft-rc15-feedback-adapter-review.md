# RC15 OpenCode owner-feedback adapter independent review

当前实际 RC15 原始 after 输入符合边界；新增 OpenCode choices + `.opencode` 排除复用了已有 owner → cold 流程。最初发现的两处 P2 已最小修复并独立复核关闭；下文保留原始反例与关闭过程。

## 已完成只读核查

- 独立运行 `python3 -m unittest discover -s tests -p test_review_feedback.py -q`：14 tests Passed，0.121 秒；无 Docker、认证或真实模型调用。
- 原 `/var/tmp/planweft-040/rc15-three-host-maintenance/opencode/maintenance/after.json` 完整 12 项：6 个保护文件、guide/work、.planning 的三文件与 active_plan；没有 `.opencode`、`.planweft`、root opencode.json 或会话缓存。没有选择性遗漏原项目文档。
- 参数/四类 SHA/原 review 主机及版本/准确包/原代码验收通过条件先于 resource/auth/Docker。源码不接受把首次语义 Failed 改成 Passed；原自动 Passed 与语义 Failed 分开保存，原输入最终重新校验摘要。
- 允许修改仅已有 notes/work.md 或 .planning 下三记录；新文件、实现、测试、contract、用户文件、README/AGENTS 不可进入 allowed_documents。前后要求集合完全相同，保护内容逐字一致。Snapshot 不覆盖安装缓存、pycache、执行位等，报告明确仍需要独立原生工具语义 review。
- owner 提示有原始范围与简明事实反馈；cold 使用独立固定提示和 owner 最终项目 snapshot。review.json、owner transcript、原聊天、插件缓存没有挂到 cold 项目。两个独立容器/HOME/session；只有运行器必需认证临时传入，非项目文件。
- owner 自动失败或清理不成功时不继续 cold；清理只匹配此次 run label，保留历史失败与记录。

## P2-1：根 OpenCode 配置未在 auth/Docker 前拒绝（Closed；保留原始发现）

独立离线复现：在带准确重算 after/review SHA 的 OpenCode fixture 添加 `opencode.json`，`validate_inputs(args)` 返回成功。新增 DENIED_PARTS 只排除 `.opencode`；原生也允许根 opencode.json。后续共享 project_snapshot 显式排除 opencode.json，于是 materialize 后 before!=files 才失败，此时 main 已读取认证、查询镜像并创建输出。它不会悄悄成为成功 cold，但不满足所有不安全项目输入先于 auth/Docker 拒绝的边界。

最小修复：safe_project_path 对根原生 opencode.json（及同类 opencode.jsonc）明确拒绝；不要删除输入、不要悄悄过滤原 after。新增正确 provenance/SHA 的反例，要求 initial validation/parse 就失败且无认证/Docker/输出。实际当前 after 没有这些配置，不宣称已经发生污染。

## P2-2：默认 outer timeout 大于单场景 600 秒（Closed；保留原始发现）

`subprocess.run(... timeout=args.timeout+240)` 在默认 timeout=600 时允许一个阶段运行 840 秒。模型内部 600 秒不等于整个独立容器最多 600 秒。本轮既定资源约束要求单场景总上限。

最小修复：outer 上限不超过 600 秒，例如 `min(600,args.timeout+240)`；同时报告真实使用的值，并离线断言默认 timeout 和小 timeout 都不越界。超时后沿现有 finally 清理所属容器，失败证据继续保留。不必改提示、包或模型。

## 审查时源码摘要

- `tests/run-review-feedback.py`: `be61b0112a9feaefe07614404c0f1daebd2d13dcf689aaead949fdaf28b3d1f5`
- `tests/test_review_feedback.py`: `c048375f86ae7b09de031b2d1c136eae0c12c04fe4fd0f95ddcf7db817b7b2e7`

原实际 OpenCode after SHA-256：`fcd94780c7d91eff431842bd801ec4d827131d2d15f7a832a8c8f1fce78ef0f8`。本审查不重新判断其他 reviewer 的原文档语义结果，也不执行修正文档场景。

## 最终修复复核

- safe_project_path 已在最前面拒绝根 opencode.json/opencode.jsonc，`.opencode` 目录排除保留。独立重做两种正确重算 after/review SHA 的反例，并调用 main：均在 load_module/auth/Docker/输出创建之前报错；不是因 stale provenance 提前拒绝。
- feedback outer 实际调用为 `min(600,args.timeout+240)`，timeout 记录使用相同实际 cap。独立重跑 14 tests Passed（0.099s）；mock owner/cold 链 timeout=600 时实际传给 subprocess 的值断言为 600。小 timeout 公式保留初始化余量而不突破 600。
- 主 run-five-agent-release.py 的旧 timeout+540 同样改为 min(600,...)，静态确认实际 Docker 调用受到该上限；不改已有冻结执行器与原失败记录。这个额外窄修改未在本次发起真实场景。
- 实际 owner-feedback JSON 已通过 validate_inputs：准确 archive、原 after、原 assessment、review 的四个 SHA 匹配；两 finding 严格限定同一既有 task_plan.md 与 notes/work.md。内容只修复已完成 Phase5 与过时 Next Step 的矛盾、旧入口第二动态状态源；明确保留 Windows Not Run、旧历史以及原流程/范围失败，不授权重跑测试、改代码或重写首次结果。
- 原始实际 after 12 项完整传入，未隐去项目记录；cold 仍仅继承 owner 最终项目文件而不继承反馈 JSON 或 owner 聊天。实际反馈执行效果保持 Not Run，需要执行后独立语义 review。

最终绑定（取代旧源码绑定）：
- `tests/run-review-feedback.py`: `83ececa327bd052aed023c7cd6567ffbb406dd30fcbffcef1ac17f0291c18f9e`
- `tests/test_review_feedback.py`: `45242c7dc824c253e57cc594f26cfb88c75f50660574f3c586f234d0a7b0cb9e`
- `tests/run-five-agent-release.py`: `cb830848adfd4b8096f6aba0ed746982a8816ce11c5110591e230b4255ccf901`
- 实际反馈 `/tmp/planweft-rc15-opencode-owner-feedback.json`: `773141d84627bbc029964d8ea3388680e114e5d0a4b0c34cfac0a85877c99308`
