# RC15 Codex Stop 事件顺序与 pending 诊断独立审查

结论：相对 f0a6429 的 Stop 顺序 / bootstrap 修改未发现阻塞问题；新增未完成调用诊断保持 fail-closed。审查仅包含源码、离线反例和原始脱敏协议重放，没有运行容器、模型、认证或修改源代码及原始证据。

## Stop 顺序与输入边界

固定 0.149.1 本地源码 bespoke_event_handling.rs 的 ItemCompleted 与 RawResponseItem 分别处理；实际保留协议的 high completion 先于 raw completion。修改取消的是没有依据的两者先后假设；相同 item ID、role、phase、完整 STOP_PROBE 文本仍必须一致，两事件都在该 item start 与对应 rawResponse completed 之间。下一响应的 item start 必须晚于前一 response completed，不能借放宽顺序跨响应重用答案。

bootstrap 仅允许一个原生 user-role 上下文，早于原始用户 raw prompt、所有 hook start 和 reasoning/answer start；仍要求新建固定版本 ephemeral thread、相同 turn metadata、精确 cwd / workspace root、限定 shell/timezone/date 和本实验文件系统结构。可选推荐列表有精确框架、条数、唯一行及字符结构限制；XML 不接收声明、实体、注释、嵌套额外节点、属性或非空尾文本。内容摘要保留。

此识别是受信任本机原生事件中的受限结构，不是推荐插件名称真实性认证：列表中的名称与来源未逐个向市场验证，日期亦只校验合法格式。本次证明不依赖推荐名称真实性；不得升级为“所有模型输入均来自项目文件”或通用任意宿主上下文认证。collector 的单次 thread/start、turn/start 和隔离 fresh-thread 输入仍是调用者前提。

bootstrap 从额外 user 列表中排除，不计为第二响应或续跑；gated-continuation 仍要求真实 first Stop blocked、唯一 feedback、同 hookRunId 的 high hookPrompt + raw XML、二者处于 block 后第二响应前，再 normal Stop。bootstrap 不能代替这一链。

独立验证：Stop 13 项测试 Passed；原 context 12 项测试 Passed；另 12 个定向反例全拒绝，涵盖 hook 后 / Stop 后 bootstrap、额外尾文本 / 属性 / 嵌套节点 / XML 注释、无效日期、foreign turn、raw 跨响应、high 在 start 前和用 bootstrap 代替反馈。测试仅使用临时合成目录与假宿主，已自动回收。首次尝试 `python` 因本机无该别名 Not Run，随后实际用 python3 完成上述测试。

## 原三份流重算

独立逐字核对协议 SHA，提取原收到事件及唯一送出 turn/start 的原 prompt，再调用当前 assess；三份结果与已提供补评逐字段相等。原 stop-observation JSON 摘要和 status=Failed 均复核保留。

| case | 离线解析 | 原结果 | 响应 / 实际续跑 |
| --- | --- | --- | --- |
| stopping | Passed | Failed: Unbound raw answer | 1 / false |
| gate-cap-disabled | Passed | Failed: Unbound raw answer | 1 / false |
| gate-cap | Passed | Failed: Unbound raw answer | 1 / false |

这三份流仅证明修复后的原生消息解析成立；不补造缺失的计数器 / 脚本进程归因，也不表示 gated-continuation 实际通过。原私有 trace 删除后的 pending 细节不能由新诊断倒推；原汇总、失败与完整发布门槛均不改写。

## 单独增量：gate_process_trace pending 诊断

当前 dirty diff 只为 `_events` / `_replay` 添加 `unfinished_syscalls` 数量和至多 32 个样本。字段为数字 pid/start_event/可选 descriptor/later_exit_event，加白名单 operation 或 unknown；不输出原 comm、argv、路径、参数或 buffer。原 unfinished-at-EOF、unmatched resume、缺退出等 errors 仍存在并决定 trace_complete。later_exit_event 是 PID 文本轨迹中的较晚退出位置，仅作诊断；不是缺失返回值已解决、代次归因已完成或可放行的证明。

独立 gate_process_trace 30 项测试 Passed；额外未知 syscall / 含 SECRET 参数、数字 FD + 私密参数、未匹配 resume 三反例均维持 trace_complete=false 且公开结果不含 SECRET。已有 40 条 pending 场景确认数量保留但仅导出 32 样本。没有发现把诊断状态参与 gate 放行的修改。

## 摘要绑定

- `/home/USER/workspace/program-design/tests/codex_stop_probe.py`: `08a530bf58269d697cbff110cdae323acd89727400bc4e7a272bd0a4acb7afc7`
- `/home/USER/workspace/program-design/tests/test_codex_stop_probe.py`: `52005660a8f1bb05d9ef5a9bc44ed861680e04ab3c8e1d1e24d6826c0a21b3b3`
- `/home/USER/workspace/program-design/tests/test_codex_context_probe.py`: `9fa8c208f7777abe53f62dac6805a2f3517cb1723459e137938885dc6d8b9ebf`
- `/home/USER/workspace/program-design/tests/codex_context_probe.py`: `21f8737f1af47c2c54e55a0ab39e494fdc97e758cef38ad76d43f08e72ee607e`
- `/home/USER/workspace/program-design/tests/gate_process_trace.py`: `2c31ce67cbd03b464f8d4f83d32adf256e7810a63dda242b2517013738004d04`
- `/home/USER/workspace/program-design/tests/test_gate_process_trace.py`: `52be861380de3c5fb4b435df94d7d7071aebb57b8a87ff1b967f34391bae079f`
- `/tmp/planweft-codex149-source/codex-rs/app-server/src/bespoke_event_handling.rs`: `42e46071529deee6a38789319f641ed46d39f7aab260b0c973f74341f6d74f31`
- `/tmp/planweft-rc15-codex-stop-parser-reassessment.json`: `b23087ece7b2574f3476d2d647a438b14856222e21c241d701982c196414b22a`
- `/tmp/review-stop-order-adversaries.py`: `7de105c22893342c09242976b3fdf4cdd021008b4de27ff899822b245a10c3a5`
- `/tmp/planweft-rc15-stop-order-independent-results.json`: `794a508ec63d6e1decc34bb0a34533194b35c6a896baf8fb053cda19dcf372ea`
- `/tmp/planweft-rc15-gate-diagnostics-independent-results.json`: `2c0a5fe8e7af18409d75882caacc2780d292396228aec0b4935ae9e4c5d0909f`
- `/var/tmp/planweft-040/rc15-codex-native-stopping/codex/stopping/raw/stop-observation.json`: `bc185bcad9f9239e22cd57674b9dfa8fe2a4b3c6210e6d6366201d202235f7cc`
- `/var/tmp/planweft-040/rc15-codex-native-stopping/codex/gate-cap-disabled/raw/stop-observation.json`: `5d492475253eb99e7ac41cfa1937e3569016d49a45ddfc2a14af8b3090aea265`
- `/var/tmp/planweft-040/rc15-codex-native-stopping/codex/gate-cap/raw/stop-observation.json`: `613d72c6894ce0dec5cb1c7d57eeab77b02f477956d91cb3adf8d3c4084aabb8`
- 原 `stopping/raw/stop-protocol.jsonl`: `87eeb164388ba1b9cf035a7c1b3bed6249552e78af21c41d4debb8f382f565b2`
- 原 `gate-cap-disabled/raw/stop-protocol.jsonl`: `f88ad16bb24f0f3da7f6b164a8dc6e96c4c2409548afa9da042f68123aa1e456`
- 原 `gate-cap/raw/stop-protocol.jsonl`: `45c09bb47062ffdb450922f866384e1e09331e8ee43502fb5aa61b43ad951dca`
