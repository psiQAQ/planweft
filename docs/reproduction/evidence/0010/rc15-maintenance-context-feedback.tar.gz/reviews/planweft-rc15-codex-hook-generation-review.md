# RC15 Codex hook 执行代次独立审查

结论：相对 3007567 的两文件修复未发现阻塞问题。固定原生流无需重跑模型即可支持有界的真实 hook 触发续跑结论；原 controller / assessment Failed、未执行卸载及原 gate-cap 未完成 syscall 缺口均保留。本次只读源码、官方固定版本公开源码与脱敏原始流，未运行 Docker、模型或读取认证。

## 依据与边界

固定 0.149.1 的 [ConfiguredHandler::run_id](https://raw.githubusercontent.com/openai/codex/rust-v0.149.1/codex-rs/hooks/src/engine/mod.rs#L92-L99) 由事件、配置排序及来源路径构成；不是每次执行的新 ID。[dispatcher](https://raw.githubusercontent.com/openai/codex/rust-v0.149.1/codex-rs/hooks/src/engine/dispatcher.rs#L68-L86) 使用该配置 ID，并以秒精度记录 startedAt。此次在线只读核对前者，后者核对已保存固定源码。因此同一 ID 再次执行合法，startedAt 也不能充当唯一代次键。

实现按当前 active ID 串行配对 start/completed，每个已完成后再次启动递增 generation，所有执行记录均保留；同 ID 尚未完成时重入被拒绝。再次执行仅允许 Stop 且来源/类型/scope 保持一致。完成事件必须绑定当前 active generation，字段仍逐项一致。每一代 Stop 又绑定自己的响应区间，反馈限定在第一代 blocked 完成后、第二响应开始前；同配置 ID 不会替代这些因果约束。相同秒 timestamp 的串行生命周期被接受，但重叠、未完成、额外执行及重复 startup 不会因此放行。

## 独立验证

- `python3 -m unittest discover -s tests -p 'test_codex_*probe.py' -q`：51 项 Passed（7.030 秒）。
- 另 8 个离线反例全部拒绝：第三对执行、turn 后 completion、第二完成早于开始、缺少最终完成、同代 startedAt 不匹配、第二代外来源、用 startup ID 冒充 Stop、反馈早于 blocked 完成。
- 原 57 行 journal 含 53 个收到事件，送出消息仅 initialize / initialized / thread/start / turn/start。独立提取原 prompt 重算，与提供的补评逐字段相等。
- 原始 Stop 通知行 40/41 与 54/55 复用配置 ID，分别是 generation 1 running→blocked、generation 2 running→completed。第一代反馈与 high hookPrompt、raw user XML 同 ID/文本绑定，之后出现第二个 STOP_PROBE，第二代 Stop 正常完成。整段只有一个 turn，native exit=0、双 EOF，无模型工具调用；这比“两条回答”提供了实际原生续跑链证据。

## 保留限制

本次补评只修复采集器的 ID 假设，不修改原始失败。原 controller/container 因旧 parser 返回失败而为 Failed/exit1，未到卸载步骤，故 uninstall 仍 Not Run。准确 RC15 归档、项目保持、原生 TUI 信任与完整 counter 投影沿用前一份独立附件审查，不能混用作稳定版验收；原 gate-cap 的 unfinished syscall 仍 Incomplete。此前 remaining 现状报告不覆盖，本报告是新补充。没有据此声明整个发布门槛 Passed。

## SHA-256 绑定

- `/home/USER/workspace/program-design/tests/codex_stop_probe.py`: `ea8a42e908854ea58bd2bb839b3f50a2133f841b6a6b283a7d4e25e3c0e11aa5`
- `/home/USER/workspace/program-design/tests/test_codex_stop_probe.py`: `4b91c287b0df63ae680a5a09cda786e12d82525cbdfe42e582d60aaed869d860`
- `/tmp/planweft-rc15-codex-hook-generation-reassessment.json`: `ec61cfce56ea7b22ccd38559526d708fdd26b14217355827d5fffc15138a36b1`
- `/tmp/planweft-rc15-hook-generation-independent-results.json`: `eb3df42ec465f10700238d402fb29147de3cb36b445a5e7959bbf5165954422a`
- `/tmp/review-hook-generation.py`: `102b51fd179d0dbda817d2c1adbff5484d936a67edb23a02bb4f3419f688d460`
- `/tmp/planweft-rc15-codex-remaining-stop-independent-review.json`: `cbcb070777218a16fe0849b83d1d6b530160ac67ce762ad71897991393c3caef`
- `/var/tmp/planweft-040/rc15-codex-native-stopping-remaining/codex/gated-continuation/raw/stop-protocol.jsonl`: `b4c13f872b1a8f444ca52ce6055fa0a386adc733fd8dba22fb232cc1bbfd5b74`
- `/var/tmp/planweft-040/rc15-codex-native-stopping-remaining/codex/gated-continuation/raw/stop-observation.json`: `9018d1d463b373a1f4132ba1a27a70a13f19f5b2fe301c41faf0f4e58a2bb1ff`
- `/tmp/planweft-codex149-source/codex-rs/hooks/src/engine/dispatcher.rs`: `a23c66e0c7869759c399214799199ebad739cb995c8271d97dc77afc86c47230`
