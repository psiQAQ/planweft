# Native resource path regression evidence

`before.log`: the new contract tests were run against the old source and failed for all eight portable host resource copies plus Kiro's hardcoded path. Codex/Claude compatibility layout already passed.

`after.log`: all three tests passed after source changes. Tests produce package maps in memory, never regenerate repository `dist`. They check eight portable hosts, every language resource file (bytes/mode except intentionally transformed GUIDE and injector), only one discoverable SKILL.md in the standalone copy, unchanged Codex/Claude layouts, and Kiro bootstrap from Chinese/spaced installed and target paths. Bootstrap writes only target project `.kiro/plan` and steering; repeated execution preserves existing records. Windows PowerShell command strings are covered, Windows execution is Not Run.

`opencode-nested-summary.json`: actual isolated OpenCode 1.18.29 `debug skill` discovered an otherwise harmless nested `references/.../SKILL.md`, but did not discover GUIDE.md. No model/auth or personal configuration was used. Its full raw output is retained separately; it includes an unrelated built-in host Skill and must not be treated as current task instructions.

Hermes 9fd44b4dfc44138b9e5d5689acb56c438364ff7b source `agent/skill_utils.py:736` recursively walks Skill roots but prunes the existing Skill's references/templates/assets/scripts at lines 746-751. GUIDE.md keeps these supporting language documents non-discoverable across both platforms. Final resource location: `skills/project-docs/references/language-variants/project-docs-{ar,de,es,zh,zht}/GUIDE.md`, complete adjacent assets/license/provenance preserved.
