#!/usr/bin/env python3
"""Archive selected local test outputs; never includes profiles, auth or dependencies."""
from pathlib import Path
import gzip, hashlib, io, json, re, tarfile
ROOT = Path('/home/USER/workspace/program-design')
OUT = ROOT / 'docs/reproduction/evidence/0006'
OUT.mkdir(parents=True, exist_ok=True)
files = {}
def add_file(path, key):
    if path.is_file() and not path.is_symlink(): files[key] = path.read_bytes()
def collect(path, prefix, skip=()):
    if not path.exists(): return
    for p in sorted(path.rglob('*')):
        rel=p.relative_to(path)
        if not set(rel.parts).intersection(skip): add_file(p, prefix+'/'+rel.as_posix())
for host in ('baseline','migrated'):
    p=Path('/tmp/pd-030-upstream-'+host)
    for name in ('summary.json','pytest.junit.xml'): add_file(p/name,'regression/'+host+'/'+name)
    collect(p/'logs','regression/'+host+'/logs')
for host in ('codex','claude','pi','gemini','opencode','copilot','codebuddy','factory','hermes','codex-hooks','kiro-protocol'):
    collect(Path('/tmp/pd-030-final-'+host+('-03' if host == 'opencode' else '')),'native/'+host,
            skip=('.git','node_modules','home','isolated-home','profile','source','project','cache','npm-cache','npm'))
for host in ('codex','claude','pi','gemini','opencode','copilot','codebuddy','factory'):
    collect(Path('/tmp/pd-030-records-'+host),'project-records/'+host,
            skip=('.git','node_modules','home','isolated-home','profile','source','project','cache','npm-cache','npm'))
for name in ('build-verify.json','compile-check.json','unittest.log','entry-contract.json','release-prepare.log','codex-hooks.log','document-links.json','lifecycle-contract.log'):
    add_file(Path('/tmp/pd-030-final-'+name), 'local/'+name)
add_file(Path('/tmp/pd-030-records-unit.log'), 'local/records-negative-contract.log')
for name in ('manifest.json',): add_file(ROOT/'dist'/name,'delivery/'+name)
add_file(Path('/tmp/pd-030-final-release-scoped/release.json'),'release/scoped-release.json')
add_file(Path('/tmp/pd-030-final-release-scoped/packages/opencode/BUILD.json'),'release/scoped-opencode-BUILD.json')
add_file(Path('/tmp/pd-030-extra-host-evidence/run-extra-host-lifecycle.py'),'runners/run-extra-host-lifecycle.py')
collect(Path('/tmp/pd-030-resource-fix-evidence'),'review/resource-fix')
for name in ('pd-native-independent-review-checks.json','pd-native-independent-review-final-checks.json'):
    add_file(Path('/tmp')/name,'review/'+name)
for name in ('pd-030-codex-hook-probe-01','pd-030-lifecycle-gemini-01','pd-030-lifecycle-gemini-02','pd-030-opencode-native-01','pd-native-lifecycle-evidence-codebuddy-v030','pd-native-lifecycle-evidence-copilot-v030'):
    collect(Path('/tmp')/name,'initial-failures/'+name,
            skip=('.git','node_modules','home','isolated-home','profile','source','project','cache','npm-cache','npm'))
collect(Path('/tmp/pd-030-extra-host-evidence/hermes'), 'initial-failures/hermes',
        skip=('.git','node_modules','home','isolated-home','profile','source','project','cache','npm-cache','npm'))
for p in (ROOT/'tests').glob('run-*.py'): add_file(p,'runners/'+p.name)
add_file(Path(__file__),'collect-evidence.py')
patterns={
 'private_key':rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',
 'github_token':rb'gh[pousr]_[A-Za-z0-9]{25,}',
 'openai_token':rb'sk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{35,}',
 'aws_key':rb'AKIA[0-9A-Z]{16}',
}
findings=[{'path':n,'pattern':k} for n,d in files.items() for k,p in patterns.items() if re.search(p,d)]
if findings: raise SystemExit('Potential credential pattern; inspect before archiving: '+json.dumps(findings))
manifest={'files':{n:{'sha256':hashlib.sha256(d).hexdigest(),'size':len(d)} for n,d in sorted(files.items())}}
buffer=io.BytesIO()
with gzip.GzipFile(fileobj=buffer,mode='wb',mtime=0) as compressed:
 with tarfile.open(fileobj=compressed,mode='w') as archive:
  for name,data in sorted(files.items()):
   info=tarfile.TarInfo(name); info.size=len(data); info.mode=0o644; info.mtime=0
   archive.addfile(info,io.BytesIO(data))
packed=buffer.getvalue(); (OUT/'raw-evidence.tar.gz').write_bytes(packed)
manifest['archive']={'path':'raw-evidence.tar.gz','sha256':hashlib.sha256(packed).hexdigest(),'size':len(packed)}
manifest['audit']={'credential_patterns':list(patterns),'matches':findings,
                   'excluded':'profiles, auth, caches, dependency trees and copied source payloads; local paths retained',
                   'limitations':'Pattern scan is a check, not proof that arbitrary sensitive data is absent.'}
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
print(json.dumps({'files':len(files),'archive_size':len(packed),'archive_sha256':manifest['archive']['sha256']}))
