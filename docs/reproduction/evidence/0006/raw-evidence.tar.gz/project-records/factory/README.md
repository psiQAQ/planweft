# Factory long-term project records lifecycle evidence

The isolated native Droid CLI 0.213.0 completed install A, update B, rollback A, uninstall and marketplace removal. No authentication or model call was made. Product files and CLI were unchanged.

The runner creates seven fixed records, including docs/specs/approved.md, docs/adr/decision.md and docs/reproduction/known.md, and inventories the project recursively. Initial, catalog, installed-a, updated-b, rollback-a, uninstalled, marketplace-removed and final checks all preserve every original record SHA-256. Host-created project metadata is recorded as additional paths, separate from protected records.

See summary.json, logs/project-records-*.json and logs/state-*.json for every comparison and native command logs. run-extra-host-lifecycle.py is the actual executed runner; fixed approved content is present in that runner and retained project files. built-payload-inventory.json captures the unmodified distribution; payload-inventory.json includes the two lifecycle marker files. frozen-payload-comparison.json confirms content identity with the previous final run.

After native uninstall and empty project-scope plugin listing were confirmed, only /tmp/pd-030-records-factory/home was removed. Pre-cleanup file inventory and host state are retained in logs/profile-state-before-cleanup.json. Source, project, runner, logs and all CLI directories remain. Hermes was not rerun.
