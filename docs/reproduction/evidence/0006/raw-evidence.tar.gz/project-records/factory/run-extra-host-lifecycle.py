#!/usr/bin/env python3
"""Isolated native CLI package lifecycle; no auth or model calls.

Only writes --output (must not exist). The input source checkout is read-only.
Invocations and real cache/config snapshots are retained as JSON evidence.
"""
import argparse,hashlib,json,os,shutil,subprocess,time
from pathlib import Path


def digest(path):
 return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
 p=argparse.ArgumentParser()
 p.add_argument('--host',choices=['factory','hermes'],required=True)
 p.add_argument('--cli',required=True)
 p.add_argument('--repo',type=Path,required=True)
 p.add_argument('--output',type=Path,required=True)
 p.add_argument('--stage',choices=['probe','full'],default='probe')
 a=p.parse_args(); out=a.output.resolve(); repo=a.repo.resolve()
 if out.exists(): p.error('--output must be new')
 out.mkdir(parents=True)
 home=out/'home'; project=out/'project'; source=out/'source'
 for q in [home,project,source,out/'logs']:q.mkdir()
 env={'PATH':'/usr/bin:/bin','HOME':str(home),'XDG_CONFIG_HOME':str(home/'config'),'XDG_CACHE_HOME':str(home/'cache'),'XDG_DATA_HOME':str(home/'data'),'LANG':'C.UTF-8','TERM':'dumb','GIT_CONFIG_GLOBAL':'/dev/null','GIT_CONFIG_NOSYSTEM':'1','GIT_TERMINAL_PROMPT':'0','PYTHONDONTWRITEBYTECODE':'1','HERMES_HOME':str(home/'.hermes'),'FACTORY_CONFIG_DIR':str(home/'.factory')}
 records=[]; summary={'host':a.host,'cli':a.cli,'commands':records,'status':'In Progress','scopes':{'home':str(home),'project':str(project)}}
 fixed_records={name:'PRESERVE '+name+'\n' for name in ['task_plan.md','findings.md','progress.md','unrelated.txt']}
 fixed_records.update({
  'docs/specs/approved.md':'# Approved specification\n\nStatus: Approved\nRequirement: Preserve this approved specification during plugin lifecycle changes.\n',
  'docs/adr/decision.md':'# Approved architecture decision\n\nStatus: Accepted\nDecision: Project documentation remains owned by the project.\n',
  'docs/reproduction/known.md':'# Known reproduction record\n\nStatus: Verified\nEvidence: Preserve this established reproduction record unchanged.\n',
 })
 for name,content in fixed_records.items():
  path=project/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_text(content)
 original={str(path.relative_to(project)):digest(path) for path in sorted(project.rglob('*')) if path.is_file()}
 initial_records={name:{'sha256':original[name],'content':content} for name,content in sorted(fixed_records.items())}
 (out/'logs'/'project-records-initial.json').write_text(json.dumps(initial_records,indent=2))
 summary['protected_project_records']=list(original)
 summary['project_records_initial']='logs/project-records-initial.json'
 def project_record_check(stage):
  observed={str(path.relative_to(project)):digest(path) for path in sorted(project.rglob('*')) if path.is_file()}
  missing=[name for name in original if name not in observed]
  changed=[name for name,sha in original.items() if name in observed and observed[name]!=sha]
  check={'preserved':not missing and not changed,'expected':original,'observed_recursive':observed,'missing':missing,'changed':changed,'additional_paths':sorted(set(observed)-set(original))}
  record_path='logs/project-records-'+stage+'.json'
  (out/record_path).write_text(json.dumps(check,indent=2))
  summary.setdefault('project_record_checks',{})[stage]={'preserved':check['preserved'],'record':record_path}
  return check['preserved']
 shutil.copy2(Path(__file__),out/'run-extra-host-lifecycle.py')
 def command(args,cwd=project,input=None):
  start=time.monotonic()
  try:
   r=subprocess.run(args,cwd=cwd,env=env,input=input,stdin=subprocess.DEVNULL if input is None else None,text=True,capture_output=True,timeout=60)
   rec={'args':args,'cwd':str(cwd),'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'seconds':round(time.monotonic()-start,3)}
  except subprocess.TimeoutExpired as error:rec={'args':args,'cwd':str(cwd),'returncode':'Timeout','stdout':str(error.stdout),'stderr':str(error.stderr),'seconds':60}
  records.append(rec); (out/'logs'/f'{len(records):02d}.json').write_text(json.dumps(rec,indent=2)); (out/'summary.json').write_text(json.dumps(summary,indent=2)); print(json.dumps({'command':args[1:],'rc':rec['returncode']},ensure_ascii=False),flush=True)
  return rec
 def snapshot(stage):
  state={}
  for root in [home,project]:
   for f in root.rglob('*'):
    if not f.is_file() or '.git' in f.parts:continue
    rel=str(f.relative_to(out)); info={'sha256':digest(f),'size':f.stat().st_size}
    if f.name in ['installed_plugins.json','known_marketplaces.json','settings.json','.install-metadata.json','config.yaml','runtime-marker.txt','obsolete-marker.txt','added-marker.txt']:
     info['content']=f.read_text(errors='replace')[:60000]
    state[rel]=info
  (out/'logs'/f'state-{stage}.json').write_text(json.dumps(state,indent=2))
  summary.setdefault('snapshots',{})[stage]=f'logs/state-{stage}.json'
  assert project_record_check(stage), 'protected project records changed at '+stage
 def native(*args):return command([a.cli,*args])
 def git(*args):
  r=command(['git',*args],cwd=source)
  if r['returncode']!=0:raise RuntimeError('git fixture failed')
  return r['stdout'].strip()
 try:
  payload=source/'dist'/a.host/'program-design' if a.host=='factory' else source
  if a.host=='factory':
   shutil.copytree(repo/'dist/factory/program-design',payload)
   (source/'.factory-plugin').mkdir()
   shutil.copy2(repo/'.factory-plugin/marketplace.json',source/'.factory-plugin/marketplace.json')
  else:
   for f in (repo/'dist/hermes/program-design').iterdir():
    if f.is_dir():shutil.copytree(f,source/f.name)
    else:shutil.copy2(f,source/f.name)
  built_inventory={str(path.relative_to(payload)):{'sha256':digest(path),'size':path.stat().st_size,'mode':oct(path.stat().st_mode&0o777)} for path in sorted(payload.rglob('*')) if path.is_file()}
  (out/'built-payload-inventory.json').write_text(json.dumps(built_inventory,indent=2))
  (payload/'runtime-marker.txt').write_text('A\n');(payload/'obsolete-marker.txt').write_text('A only\n')
  payload_inventory={str(path.relative_to(payload)):{'sha256':digest(path),'size':path.stat().st_size,'mode':oct(path.stat().st_mode&0o777)} for path in sorted(payload.rglob('*')) if path.is_file()}
  (out/'payload-inventory.json').write_text(json.dumps(payload_inventory,indent=2))
  snapshot('initial')
  git('init','--initial-branch=main');git('add','--all');git('-c','user.name=Lifecycle test','-c','user.email=test@example.invalid','commit','-m','Fixture A')
  summary['revision_a']=git('rev-parse','HEAD')
  if a.host=='factory':
   native('--version');native('plugin','install','--help');native('plugin','update','--help')
   r=native('plugin','marketplace','add',str(source));snapshot('catalog')
   if r['returncode']!=0:raise RuntimeError('marketplace add failed')
   market_name=r['stdout'].strip().split(': ',1)[1]
   summary['registered_marketplace']=market_name
   r=native('plugin','install','program-design@'+market_name,'--scope','project');snapshot('installed-a')
   if r['returncode']!=0:raise RuntimeError('plugin install failed')
   native('plugin','list','--scope','project')
  else:
   native('plugins','--help');native('plugins','install','--help')
   r=native('plugins','install',source.as_uri(),'--ref',summary['revision_a'],'--enable');snapshot('installed-a')
   if r['returncode']!=0:raise RuntimeError('plugin install failed')
   native('plugins','list')
  summary['status']='Probe Passed'
  if a.stage=='full':
   if a.host!='factory':raise RuntimeError('Hermes blocked by host scan; no bypass performed')
   plugin_id='program-design@'+market_name
   def cache_check(stage,expected):
    metadata=[]
    for f in (home/'.factory/plugins/installed_plugins').glob('*.json'):
     info=json.loads(f.read_text())
     if info.get('pluginId')==plugin_id:metadata.append(info)
    assert len(metadata)==1,metadata
    active=Path(metadata[0]['entry']['installPath'])
    assert out in active.parents,active
    observed={name:(active/name).read_text() if (active/name).exists() else None for name in ['runtime-marker.txt','obsolete-marker.txt','added-marker.txt']}
    assert observed==expected,(stage,observed,expected)
    summary.setdefault('active_cache_checks',{})[stage]={'path':str(active),'markers':observed,'metadata':metadata[0]}
   state_a={'runtime-marker.txt':'A\n','obsolete-marker.txt':'A only\n','added-marker.txt':None}
   state_b={'runtime-marker.txt':'B\n','obsolete-marker.txt':None,'added-marker.txt':'B only\n'}
   cache_check('installed-a',state_a)
   (payload/'runtime-marker.txt').write_text('B\n');(payload/'obsolete-marker.txt').unlink();(payload/'added-marker.txt').write_text('B only\n')
   manifest=payload/'.factory-plugin/plugin.json';data=json.loads(manifest.read_text());data['version']='0.3.1';manifest.write_text(json.dumps(data,indent=2)+'\n')
   git('add','--all');git('-c','user.name=Lifecycle test','-c','user.email=test@example.invalid','commit','-m','Fixture B')
   summary['revision_b']=git('rev-parse','HEAD')
   assert native('plugin','marketplace','update',market_name)['returncode']==0
   assert native('plugin','update',plugin_id,'--scope','project')['returncode']==0
   snapshot('updated-b');cache_check('updated-b',state_b)
   assert native('plugin','list','--scope','project')['returncode']==0
   git('checkout',summary['revision_a'])
   assert native('plugin','marketplace','update',market_name)['returncode']==0
   assert native('plugin','update',plugin_id,'--scope','project')['returncode']==0
   snapshot('rollback-a');cache_check('rollback-a',state_a)
   assert native('plugin','uninstall',plugin_id,'--scope','project')['returncode']==0
   snapshot('uninstalled')
   remaining=[]
   for f in (home/'.factory/plugins/installed_plugins').glob('*.json'):
    if json.loads(f.read_text()).get('pluginId')==plugin_id:remaining.append(str(f))
   assert not remaining,remaining
   listed=native('plugin','list','--scope','project')
   assert listed['returncode']==0 and plugin_id not in listed['stdout'],listed
   assert native('plugin','marketplace','remove',market_name)['returncode']==0
   snapshot('marketplace-removed')
   summary['status']='Passed'
   summary['not_run']=['authenticated agent session','model Skill consumption','Windows/macOS','remote Git transport']
 except Exception as error:summary['status']='Failed';summary['error']=str(error)
 finally:
  summary['project_preserved']=project_record_check('final') and all(check['preserved'] for check in summary['project_record_checks'].values())
  if not summary['project_preserved']:
   summary['status']='Failed';summary['error']='protected project records changed during lifecycle'
  (out/'summary.json').write_text(json.dumps(summary,indent=2)); print(json.dumps({'status':summary['status'],'output':str(out),'error':summary.get('error')},ensure_ascii=False))

if __name__=='__main__':main()
