from pathlib import Path
from dataclasses import asdict
import json
from tools.plugin_guard import scan_plugin
r=scan_plugin(Path('/tmp/pd-030-hermes-probe/source'), source="isolated current Program Design 0.3.0 package")
print(json.dumps(asdict(r),indent=2))
