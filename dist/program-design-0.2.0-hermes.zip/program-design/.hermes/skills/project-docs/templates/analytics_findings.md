# Findings & Decisions

Use this file to record data sources, hypotheses, queries, statistical results, decisions, issues, resources, and visual observations.

## Data Sources

Record each data source with its location, size, key fields, and quality limitations.

| Source | Location | Size | Key Fields | Quality Notes |
|--------|----------|------|------------|---------------|
|        |          |      |            |               |

## Hypothesis Log

Record each hypothesis, test method, result, and confidence so the reasoning remains auditable.

| Hypothesis | Test Method | Result | Confidence |
|------------|-------------|--------|------------|
|            |             |        |            |

## Query Results

For each significant query, record the query or reference, result summary, and interpretation.

## Statistical Findings

Record formal test results with p-values, effect sizes, and conclusions.

| Test | p-value | Effect Size | Conclusion |
|------|---------|-------------|------------|
|      |         |             |            |

## Technical Decisions

Record analytical method choices and their rationale.

| Decision | Rationale |
|----------|-----------|
|          |           |

## Issues Encountered

Record analysis problems and their resolutions.

| Issue | Resolution |
|-------|------------|
|       |            |

## Resources

List useful URLs, file paths, and documentation links.

-

## Visual/Browser Findings

Capture relevant facts from charts, dashboards, and browser results as text while the evidence is available.

-

---

*Update this file after significant analytical discoveries so evidence remains available.*

## Evidence and design boundaries

Retain discoveries and candidate decisions here. Put current phase and next action only in the selected `task_plan.md`. Add stable project records only when the task needs them.

| Design or observation | Exact requirement or source | Fact, inference or candidate | Local difference and verification gap |
| --- | --- | --- | --- |

## Precedent search

For a new mechanism, record actual search date, queries, scope, close matches and what remains unsupported. If unavailable, state Not Run with the reason; "not found in this search" is not a claim of originality. Omit this section when no substantive mechanism requires a search.

## Approved requirement conflicts

Record any discrepancy between approved behavior and current implementation, with its exact source and the needed correction or scope decision. Preserve approved acceptance criteria and distinguish proposed decisions from accepted ones.
