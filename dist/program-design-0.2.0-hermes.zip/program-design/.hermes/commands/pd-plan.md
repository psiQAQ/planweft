---
description: "Start Hermes program-design workflow in the current project."
disable-model-invocation: true
---

Follow project-docs scope rules: read-only requests and host plan mode do not initialize or update project files. Resolve the task-owned plan first; never create a competing root plan.

Load the `program-design` skill and follow it.

1. Determine the actual project root for the current task.
2. Run `program_design_init` with `cwd` set to that project root.
3. Read `task_plan.md`, `findings.md`, and `progress.md` from that same directory.
4. Begin or continue the planning workflow.
