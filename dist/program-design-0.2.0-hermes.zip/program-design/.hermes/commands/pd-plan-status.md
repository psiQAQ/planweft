---
description: "Show Hermes program-design status for the current project."
disable-model-invocation: true
---

Follow project-docs scope rules: read-only requests and host plan mode do not initialize or update project files. Resolve the task-owned plan first; never create a competing root plan.

Run `program_design_status` in the current project directory and present the result as a compact status summary.
