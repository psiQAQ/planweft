// Local package: run npm ci --ignore-scripts and npm run build in its directory.
export { PlanningWithFiles } from "../packages/opencode-program-design/dist/index.js"
