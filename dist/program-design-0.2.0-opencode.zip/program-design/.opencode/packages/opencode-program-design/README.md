# opencode-program-design

Native [OpenCode](https://opencode.ai) plugin for Program Design, derived from [planning-with-files](https://github.com/OthmanAdi/planning-with-files): persistent file-based planning for AI coding agents. The plan lives on disk in `task_plan.md`, `findings.md` and `progress.md`; this plugin keeps it in the model's context on every turn and can hold the session open until the plan reports complete.

## Install

Use the **OpenCode** ZIP from this repository's `dist/`. It contains a local
source package; `opencode-program-design` has not been published to npm.

1. Copy `.opencode/packages/opencode-program-design/`,
   `.opencode/plugins/program-design.ts`, and `.opencode/skills/project-docs/`
   from the ZIP to the same paths under your target project. Keep existing
   unrelated configuration and plugins. Optionally copy `.opencode/commands/pd-*.md`.
2. In the copied `.opencode/packages/opencode-program-design/` directory, run:

   ```bash
   npm ci --ignore-scripts
   npm run build
   ```

3. Keep `node_modules/` in that local package and restart OpenCode. The shipped
   loader imports `../packages/opencode-program-design/dist/index.js`; no npm
   `plugin` registration or manually written loader is needed. Verify that
   `project-docs` and `pd_init` / `pd_status` / `pd_check` are available.

For user scope, put the same `packages/`, `plugins/`, `skills/` and optional
`commands/` directories under `~/.config/opencode/`, preserving relative paths.
Uninstall only these plugin-owned paths; keep your project plans and evidence.


## What the plugin does

| Hook | Behavior |
|---|---|
| `chat.message` | Appends the active plan to every user message: the framed head of `task_plan.md`, the normalized tail of `progress.md`, a pointer to `findings.md`. Resolves `PLAN_ID`, then `.planning/.active_plan`, then the newest `.planning/<slug>/task_plan.md`, then the legacy root file |
| `tool.execute.after` | Appends a progress reminder to the output of `write`, `edit`, `patch` and `multiedit` while a plan exists |
| `experimental.session.compacting` | Keeps the plan pointer and its attestation hash in the compaction summary |
| `event` (`session.idle`) | Completion gate in gated mode: while an `in_progress` phase remains, the plugin re-prompts the session with the gate reason. Block cap `PWF_GATE_CAP` (default 20) and ledger stall detection release the session; child sessions are never re-prompted |
| tools | `pd_init` (root or `.planning/<date>-<slug>/`, `mode: autonomous` or `gated` with attestation), `pd_status`, `pd_check` |

Autonomous and gated plans inject only when `.attestation` (slug) or `.plan-attestation` (root) matches the SHA-256 of `task_plan.md`. `PLANNING_DISABLED=1` silences every hook; `PWF_PLAN_ROOT=<absolute path>` pins the project root and fails closed when it does not resolve. A live plan in a direct child project makes a cwd guess ambiguous and nothing is injected, with a one-line notice.

## Commands

Copy `pd-pwf.md` and `pd-pwf-status.md` from the unpacked OpenCode ZIP's `.opencode/commands/` into `~/.config/opencode/commands/` (or your project's `.opencode/commands/`) to get `/pd-pwf [--gated] [plan name]` and `/pd-pwf-status`.

Upstream implementation reference: [docs/opencode.md](https://github.com/OthmanAdi/planning-with-files/blob/master/docs/opencode.md).

## License

MIT
